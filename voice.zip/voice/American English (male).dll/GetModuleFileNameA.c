// 函数: GetModuleFileNameA
// 地址: 0x405870
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

return GetModuleFileNameA(hModule, lpFilename, nSize) __tailcall
