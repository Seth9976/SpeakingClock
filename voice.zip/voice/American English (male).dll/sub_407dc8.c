// 函数: sub_407dc8
// 地址: 0x407dc8
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

long double var_14
int16_t x87control
long double x87_r0
char result = sub_407c0c(sub_403e88(arg1), &var_14, x87control, x87_r0)

if (result != 0)
    *arg2 = fconvert.s(var_14)

return result
