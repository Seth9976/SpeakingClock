// 函数: GetThreadLocale
// 地址: 0x405898
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

return GetThreadLocale() __tailcall
