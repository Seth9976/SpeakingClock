// 函数: sub_403170
// 地址: 0x403170
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

if (data_413024 u> 1)
    data_414014(0xeedfadf, 0, 0, 0)
