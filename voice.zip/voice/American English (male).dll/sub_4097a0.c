// 函数: sub_4097a0
// 地址: 0x4097a0
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

int32_t var_8 = arg1
void** result = sub_40972c(nullptr, arg3, *(arg5 - 4), arg4)

if (*arg4 != 0)
    return result

return sub_4053d8(*(arg1 + (arg2 << 2)), arg4)
