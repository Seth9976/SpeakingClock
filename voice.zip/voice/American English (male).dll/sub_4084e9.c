// 函数: sub_4084e9
// 地址: 0x4084e9
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

*arg1
