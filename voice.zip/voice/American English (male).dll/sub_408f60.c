// 函数: sub_408f60
// 地址: 0x408f60
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

int32_t entry_result
return entry_result
