// 函数: sub_40780b
// 地址: 0x40780b
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

if (*(arg1 - 0x2a) != 0)
    int32_t eax
    eax.b = 0x2d
    *arg2 = 0x2d
