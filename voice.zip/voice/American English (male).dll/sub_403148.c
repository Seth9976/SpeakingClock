// 函数: sub_403148
// 地址: 0x403148
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

return (*(*arg1 - 8))()
