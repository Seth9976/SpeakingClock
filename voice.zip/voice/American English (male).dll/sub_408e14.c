// 函数: sub_408e14
// 地址: 0x408e14
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

int32_t var_8 = arg2
int32_t var_c = arg1
void** eax
sub_408db8(eax, nullptr)
