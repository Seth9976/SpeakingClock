// 函数: sub_40318c
// 地址: 0x40318c
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

if (data_413024 == 0)
    return 

int32_t eax
int32_t var_4_1 = eax
int32_t var_8_1 = eax
int32_t var_c = arg2
data_414014(0xeedfae4, 0, 2, &var_c)
