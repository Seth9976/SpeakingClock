// 函数: sub_406864
// 地址: 0x406864
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

uint16_t edx_1 = (arg3 u>> 0x10).w
uint16_t temp1 = modu.dp.w(edx_1:(arg3.w), arg2)
arg3.w = divu.dp.w(edx_1:(arg3.w), arg2)
*arg1 = arg3.w
*arg4 = temp1
return arg3
