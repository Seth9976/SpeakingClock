// 函数: sub_409620
// 地址: 0x409620
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

int32_t var_c = arg3
var_c = 1

if (sub_40942c(arg1, &var_c, arg2) != 0 && sub_403c88(arg1) s< var_c)
    int32_t result
    result.b = 1
    return result

return 0
