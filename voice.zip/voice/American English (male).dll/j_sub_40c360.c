// 函数: j_sub_40c360
// 地址: 0x40c366
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

return sub_40c360() __tailcall
