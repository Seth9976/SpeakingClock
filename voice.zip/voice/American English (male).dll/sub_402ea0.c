// 函数: sub_402ea0
// 地址: 0x402ea0
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

int32_t* eax
sub_403160(eax, arg2)

if (arg2.b s> 0)
    sub_403148(eax)
