// 函数: GetCPInfo
// 地址: 0x405830
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

return GetCPInfo(CodePage, lpCPInfo) __tailcall
