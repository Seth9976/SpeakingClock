// 函数: sub_408e0d
// 地址: 0x408e0d
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

*arg1 += arg1.b
char* entry_ebx
*entry_ebx += arg1.b
*arg1 += arg1.b
return sub_408e14() __tailcall
