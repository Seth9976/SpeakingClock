// 函数: sub_403fec
// 地址: 0x403fec
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

BSTR bstrString = *arg1
*arg1 = arg2

if (bstrString != 0)
    SysFreeString(bstrString)
