// 函数: sub_404de4
// 地址: 0x404de4
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

int32_t eax
return sub_404df4(eax)
