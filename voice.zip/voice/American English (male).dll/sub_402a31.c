// 函数: sub_402a31
// 地址: 0x402a31
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

return 
