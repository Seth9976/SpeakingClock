// 函数: sub_404fb0
// 地址: 0x404fb0
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

void* eax
int32_t* result = sub_402e48(eax)
result[1] = 1
return result
