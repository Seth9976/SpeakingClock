// 函数: sub_404158
// 地址: 0x404158
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

return 
