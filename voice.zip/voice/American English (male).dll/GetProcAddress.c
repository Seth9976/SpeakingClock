// 函数: GetProcAddress
// 地址: 0x405880
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

return GetProcAddress(hModule, lpProcName) __tailcall
