// 函数: RtlUnwind
// 地址: 0x401170
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

return RtlUnwind(TargetFrame, TargetIp, ExceptionRecord, ReturnValue) __tailcall
