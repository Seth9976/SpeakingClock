// 函数: GetDateFormatA
// 地址: 0x405840
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

return GetDateFormatA(Locale, dwFlags, lpDate, lpFormat, lpDateStr, cchDate) __tailcall
