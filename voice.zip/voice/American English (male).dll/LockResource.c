// 函数: LockResource
// 地址: 0x4058c0
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

return LockResource(hResData) __tailcall
