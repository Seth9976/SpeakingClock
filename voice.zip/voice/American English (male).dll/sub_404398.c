// 函数: sub_404398
// 地址: 0x404398
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

if (arg3 == 0)
    return 

int32_t* var_4_1 = arg1
int32_t* ebx_1 = arg1
int32_t i_5 = arg3
arg1.b = *arg2
int32_t edx
edx.b = arg2[1]
int32_t ebp

switch (arg1.b)
    case 0xa
        if (arg3 s> 1)
            sub_403a10(ebx_1, arg3)
        else
            sub_4039ec(ebx_1)
    case 0xb
        if (arg3 s> 1)
            sub_404014(ebx_1, arg3)
        else
            sub_403ffc(ebx_1)
    case 0xc
        int32_t i_1
        
        do
            ebx_1 = &ebx_1[4]
            sub_404380()
            i_1 = i_5
            i_5 -= 1
        while (i_1 s> 1)
    case 0xd
        int32_t var_14_1 = ebp
        int32_t i_2
        
        do
            ebx_1 += *(arg2 + edx + 2)
            *(arg2 + edx + 6)
            **(arg2 + edx + 0xa)
            sub_404398()
            i_2 = i_5
            i_5 -= 1
        while (i_2 s> 1)
    case 0xe
        int32_t var_14_2 = ebp
        int32_t i_3
        
        do
            int32_t* eax_4 = ebx_1
            ebx_1 += *(arg2 + edx + 2)
            sub_40434c(eax_4, arg2)
            i_3 = i_5
            i_5 -= 1
        while (i_3 s> 1)
    case 0xf
        int32_t i_4
        
        do
            int32_t* eax_5 = ebx_1
            ebx_1 = &ebx_1[1]
            sub_404f50(eax_5)
            i_4 = i_5
            i_5 -= 1
        while (i_4 s> 1)
    default
        if (arg1.b != 0x11)
            int32_t* eax_7
            eax_7.b = 2
            noreturn sub_402710(eax_7) __tailcall
        
        int32_t i
        
        do
            int32_t* eax_6 = ebx_1
            ebx_1 = &ebx_1[1]
            sub_4048ac(eax_6, arg2)
            i = i_5
            i_5 -= 1
        while (i s> 1)
