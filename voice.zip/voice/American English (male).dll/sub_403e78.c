// 函数: sub_403e78
// 地址: 0x403e78
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

if (arg1 != 0 && *(arg1 - 8) s> 0xffffffff)
    *(arg1 - 8) += 1
