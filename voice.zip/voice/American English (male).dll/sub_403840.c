// 函数: sub_403840
// 地址: 0x403840
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

int32_t temp0 = data_413000
data_413000 = 0
int32_t eax_1 = neg.d(temp0)
data_414648
int32_t* ebp = data_414644
int32_t var_4 = data_41464c
int32_t var_8 = data_414650
__builtin_memcpy(&data_414630, data_414630, 0x2c)
*ebp
return sbb.d(eax_1, eax_1, temp0 != 0) + 1
