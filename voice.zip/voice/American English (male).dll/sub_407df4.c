// 函数: sub_407df4
// 地址: 0x407df4
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

int32_t ecx
ecx.b = 1
int16_t x87control
long double x87_r0
return sub_407c0c(sub_403e88(arg1), arg2, x87control, x87_r0)
