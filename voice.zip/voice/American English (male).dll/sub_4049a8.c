// 函数: sub_4049a8
// 地址: 0x4049a8
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

while (true)
    char edx = *arg1
    
    if (edx == 0 || edx == 0x5c)
        return 
    
    arg1 = CharNextA(arg1)
