// 函数: SafeArrayGetUBound
// 地址: 0x40bff4
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

return SafeArrayGetUBound(psa, nDim, plUbound) __tailcall
