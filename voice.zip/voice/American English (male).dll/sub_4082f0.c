// 函数: sub_4082f0
// 地址: 0x4082f0
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

int32_t edx = *(arg1 - 4)

while (true)
    char* ecx_1
    ecx_1.b = **(arg1 - 4)
    
    if (ecx_1.b != *(arg1 - 5))
        break
    
    *(arg1 - 4) += 1

int32_t result = *(arg1 - 4) - edx + 1
*(arg1 - 0xc) = result
return result
