// 函数: sub_402eb0
// 地址: 0x402eb0
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

if (arg1 != 0)
    int32_t edx
    edx.b = 1
    (*(*arg1 - 4))()
