// 函数: GetCurrentThreadId
// 地址: 0x405838
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

return GetCurrentThreadId() __tailcall
