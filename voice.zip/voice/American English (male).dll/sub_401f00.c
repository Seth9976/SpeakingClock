// 函数: sub_401f00
// 地址: 0x401f00
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

int32_t var_10
sub_4017b8(arg1, arg2 + 4, &var_10)

if (var_10 != 0 && sub_401e48(&var_10) != 0)
    return 1

return 0
