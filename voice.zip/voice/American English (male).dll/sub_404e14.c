// 函数: sub_404e14
// 地址: 0x404e14
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

int32_t* i_1 = data_413034

if (i_1 != 0 && i_1[1] == arg1)
    data_413034 = *data_413034
    sub_402648(i_1)
    return 

for (int32_t* i = i_1; i != 0; i = *i)
    int32_t* ecx_1 = *i
    
    if (ecx_1 != 0 && ecx_1[1] == arg1)
        *i = *ecx_1
        sub_402648(ecx_1)
        break
