// 函数: sub_402854
// 地址: 0x402854
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

return sub_40280c(arg1, *(arg1 + 0x1c))
