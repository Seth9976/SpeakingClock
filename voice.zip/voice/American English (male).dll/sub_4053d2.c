// 函数: sub_4053d2
// 地址: 0x4053d2
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

return 
