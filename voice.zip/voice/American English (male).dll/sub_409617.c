// 函数: sub_409617
// 地址: 0x409617
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

*arg2 += 1
*arg1 += arg1.b
arg1[0x4d] += arg2.b
*arg1 += arg1.b
int32_t ecx
return sub_409620(arg1, arg2, ecx) __tailcall
