// 函数: sub_401bf4
// 地址: 0x401bf4
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

if (arg2 s>= 0xc)
    *arg1 = arg2 | 2
    return sub_401bd0(&arg1[1])

if (arg2 s>= 4)
    *arg1 = arg2 | 0x80000002

void* result = arg1 + arg2
*result &= 0xfffffffe
return result
