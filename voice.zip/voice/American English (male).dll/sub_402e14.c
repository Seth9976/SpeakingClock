// 函数: sub_402e14
// 地址: 0x402e14
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

int16_t x87control
int16_t x87status
x87control, x87status = __fldcw_memmem16(data_413020)
