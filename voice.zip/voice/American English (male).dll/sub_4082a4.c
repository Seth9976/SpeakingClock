// 函数: sub_4082a4
// 地址: 0x4082a4
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

int32_t var_30 = arg3
int32_t var_34 = 4
int32_t var_24 = arg2
char var_20 = 0
int32_t var_1c = arg1
char var_18 = 0
int32_t* var_38 = &var_24
char var_14[0x10]
void* eax_2
void* ecx
int32_t edi
eax_2, ecx = sub_40723c("%.*d`[@", 0x10, &var_14, arg2, edi, 1)
return sub_408240(&var_14, eax_2, ecx)
