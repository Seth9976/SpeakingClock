// 函数: sub_405718
// 地址: 0x405718
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

if (*(arg1 + 0xc) == 1)
    data_41465c = 1
    int32_t ecx_1 = *(arg1 + 8)
    data_414660 = ecx_1
    data_4130a0 = ecx_1
    data_4130a4 = 0
    data_4130a8 = 0
    sub_40570c()

int32_t* eax
int32_t esi
int32_t edi
int16_t x87control
return sub_4036d0(&data_4130b4, 0x41309c, eax, arg1, esi, edi, x87control, data_414664)
