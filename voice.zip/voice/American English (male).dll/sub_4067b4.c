// 函数: sub_4067b4
// 地址: 0x4067b4
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

void* entry_ebx
*(arg5 - 0x56ffbf99) += entry_ebx.b
*(arg1 + 0x67) += arg2:1.b
*(arg1 + 0x67) += entry_ebx:1.b
*(arg1 - 0x72ffbf99) += (arg4 + 4).b
*arg3 += (arg4 + 5).b
*(arg4 + 5) += (arg4 + 5).b
char temp1 = *(arg2 - 0x74)
*(arg2 - 0x74) += arg2.b
bool c = temp1 + arg2.b u< temp1
char temp2 = *(entry_ebx - 0x71)
*(entry_ebx - 0x71) = adc.b(temp2, entry_ebx:1.b, c)
bool c_1 = adc.b(temp2, entry_ebx:1.b, c) u< temp2 || (c && adc.b(temp2, entry_ebx:1.b, c) == temp2)
uint16_t* eax_5 = sbb.d(arg4 + 5, 0xdf9c4cdb, c_1)
bool c_2 = unimplemented  {sbb eax, 0xdf9c4cdb}
void* var_4 = arg5
void** esp_1 = &var_4
void* ecx = arg3 - 1
int32_t eflags
uint16_t* esi_2

if (sbb.d(arg4 + 5, 0xdf9c4cdb, c_1) != 0 && ecx != 0)
    *(arg1 + 0x53)
    esi_2 = *(arg1 + 0x53) * 0x68636e79
    bool c_4 = unimplemented  {imul esi, dword [ebp+0x53], 0x68636e79}
    
    if (c_4)
        goto label_4068cb
else
    *0x4067b43f = sbb.d(*0x4067b43f, arg5, c_2)
    *(eax_5 * 2) += ecx:1.b
    *eax_5 += eax_5.b
    *eax_5 += eax_5.b
    *eax_5 += eax_5.b
    void* eax_6
    eax_6.b = (eax_5 + 1).b + arg2.b
    *(eax_6 + 1) += (eax_6 + 1).b
    *(eax_6 + 1) += (eax_6 + 1).b
    *(eax_6 + 1) += (eax_6 + 1).b
    *(eax_6 + 1) += (eax_6 + 1).b
    *(eax_6 + 1) += (eax_6 + 1).b
    *(eax_6 + 1) += (eax_6 + 1).b
    *(eax_6 + 1) += (eax_6 + 1).b
    *(eax_6 + 1) += (eax_6 + 1).b
    *(eax_6 + 1) += (eax_6 + 1).b
    *(eax_6 + 1) += (eax_6 + 1).b
    *(eax_6 + 1) += (eax_6 + 1).b
    *(eax_6 + 1) += (eax_6 + 1).b
    *(eax_6 + 1 + (arg1 << 1)) += entry_ebx:1.b
    *(eax_6 + 2) += arg2:1.b
    *(eax_6 + 2) += (eax_6 + 2).b
    char temp5_1 = *(eax_6 + 2)
    *(eax_6 + 2) += (eax_6 + 2).b
    *(eax_6 + 2) = adc.d(*(eax_6 + 2), eax_6 + 2, temp5_1 + (eax_6 + 2).b u< temp5_1)
    esp_1 = 0x94004030
    *(eax_6 - 0x2fffbfae) += (eax_6 + 3):1.b
    *(eax_6 + 3) ^= (eax_6 + 3).b
    int32_t esi
    int16_t es_1
    esi, es_1 = __les_gprz_memp(*(eax_6 + 3))
    *(eax_6 + 0x64004053) += arg2:1.b
    eax_5 = eax_6 + 5
    *((esi << 2) + 0x94004070) += arg2.b
    *(0x94004030 + (arg2 << 1)) += eax_5:1.b
    
    if (arg1 != 1)
    label_4068ad:
        int32_t eflags_1
        char temp0_2
        temp0_2, eflags_1 = __das(eax_5.b, eflags)
        eax_5.b = temp0_2
        int32_t eflags_2
        char temp0_3
        char temp1_1
        temp0_3, temp1_1, eflags_2 = __aaa(eax_5.b, eax_5:1.b, eflags_1)
        eax_5.b = temp0_3
        eax_5:1.b = temp1_1
        *eax_5 += eax_5.b
    label_4068b1:
        int32_t eax_12 = sub_4033c4(eax_5)
        *esp_1
        esp_1[1]
        esp_1[2]
        return eax_12
    
    if (arg1 == 1)
        eax_5 = sub_409fe0(eax_5, arg2, ecx)
        goto label_4068b1
    
    *0x9400402c = arg2
    void* esi_1 = *0x94004030
    void* ebp_1 = *0x94004034
    entry_ebx = *0x9400403c
    arg2 = *0x94004040
    ecx = *0x94004044
    eax_5 = *0x94004048
    esp_1 = 0x9400404c
    
    if (ebp_1 + 1 s< 0)
        goto label_4068ad
    
    uint8_t* edi_2
    uint8_t temp0
    temp0, edi_2 = __insb(*0x9400402c, arg2.w, eflags)
    *edi_2 = temp0
    
    if (ebp_1 != 0xffffffff)
        esi_2 = sub_402628(entry_ebx)
        eax_5 = esi_2
    label_4068cb:
        ecx = nullptr
    label_4068cf:
        sub_4028b8(eax_5, entry_ebx, ecx)
        *esp_1
        esp_1[1]
        return esi_2
    
    esi_2 = *(esi_1 + 0x65) * 0x74697257
    *0x94004048 = entry_ebx
    
    if (ebp_1 + 1 s>= 0)
        *(entry_ebx + 0x33c68bf0) -= 1
        *(ebp_1 + 1)
        esp_1 = ebp_1 + 5
        goto label_4068cf
    
    int16_t temp0_1
    temp0_1, eflags = __arpl_memw_gpr16(eax_5[0x39], (ebp_1 + 1).w)
    eax_5[0x39] = temp0_1
    esi_2 = __outsd(arg2.w, *esi_2, esi_2, eflags)

__outsb(arg2.w, *esi_2, esi_2, eflags)
*(arg2 + 0x65)
return sub_406864(ecx, arg2, eax_5) __tailcall
