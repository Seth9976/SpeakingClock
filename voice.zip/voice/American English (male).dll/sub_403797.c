// 函数: sub_403797
// 地址: 0x403797
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

return 
