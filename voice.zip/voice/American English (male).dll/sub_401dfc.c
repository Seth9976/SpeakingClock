// 函数: sub_401dfc
// 地址: 0x401dfc
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

if (data_414614 s<= 0)
    return 

if (data_414614 s< 0xc)
    data_4145c0 = 7
    return 

*data_414618 = data_414614 | 2
sub_401bd0(data_414618 + 4)
data_414618 = 0
data_414614 = 0
