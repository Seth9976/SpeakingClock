// 函数: ExitProcess
// 地址: 0x401190
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

noreturn ExitProcess(uExitCode) __tailcall
