// 函数: EnterCriticalSection
// 地址: 0x405800
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

return EnterCriticalSection(lpCriticalSection) __tailcall
