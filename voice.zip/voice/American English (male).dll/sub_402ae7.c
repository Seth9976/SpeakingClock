// 函数: sub_402ae7
// 地址: 0x402ae7
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

*arg1 += arg1.b
*arg1 += arg1.b
*arg1 += arg1.b
arg1[0x3fff] += arg1.b
*arg1 += arg1.b
*arg1 += arg1.b
arg1[0x4002] += arg1:1.b
*arg1 += arg1.b
*arg1 += arg1.b
arg1.b += arg3
arg1[0x40] += (&arg1[0x40]).b
arg1[0x40] += (&arg1[0x40]).b
int32_t eflags
__cli(eflags)
arg1[0x40] |= (&arg1[0x40]).b
arg1[0x40] += (&arg1[0x40]).b
arg1[0x40] += (&arg1[0x40]).b
arg1[0xffffffdc] += (&arg1[0x40]).b
void* result
result.b = (&arg1[0x40]).b | 0x40
*result += result.b
*result += result.b
*result += result.b
void* result_1 = result
return result
