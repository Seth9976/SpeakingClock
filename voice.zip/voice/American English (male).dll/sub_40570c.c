// 函数: sub_40570c
// 地址: 0x40570c
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

sub_404ed0(0x41309c)
return 0x41309c
