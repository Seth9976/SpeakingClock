// 函数: ?__abi_AddRef@RuntimeClassNameAttribute@Metadata@Platform@@U$AAGKXZ
// 地址: 0x404fe8
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

return InterlockedIncrement(arg1 + 4)
