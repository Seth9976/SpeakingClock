// 函数: sub_408284
// 地址: 0x408284
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

int32_t var_c = arg2
void* ecx
return sub_408240(arg1, sub_403c88(arg1), ecx)
