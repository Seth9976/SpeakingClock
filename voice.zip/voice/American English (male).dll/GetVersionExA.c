// 函数: GetVersionExA
// 地址: 0x4058a0
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

return GetVersionExA(lpVersionInformation) __tailcall
