// 函数: sub_406e94
// 地址: 0x406e94
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

int32_t eax
return sub_406e70(eax)
