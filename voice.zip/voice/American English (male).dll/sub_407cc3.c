// 函数: sub_407cc3
// 地址: 0x407cc3
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

char i

do
    i = *arg1
    arg1 = &arg1[1]
    
    if (i == 0)
        break
while (i == 0x20)

return i
