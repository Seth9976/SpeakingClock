// 函数: sub_4046b6
// 地址: 0x4046b6
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

return 
