// 函数: sub_406af0
// 地址: 0x406af0
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

int32_t __saved_esi
uint32_t eax
sub_403adc(arg2, &__saved_esi, sub_406aa4(eax, 0, 0, &__saved_esi))
return arg2
