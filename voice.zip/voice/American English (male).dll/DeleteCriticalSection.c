// 函数: DeleteCriticalSection
// 地址: 0x4057f8
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

return DeleteCriticalSection(lpCriticalSection) __tailcall
