// 函数: sub_4031fc
// 地址: 0x4031fc
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

if (data_413024 u<= 1)
    return 

int32_t __saved_eax_2
int32_t __saved_eax_1 = __saved_eax_2
char* ecx
char* var_c_1 = ecx
int32_t var_10 = sub_4031dc(ecx)
data_414014(0xeedfae1, 0, 1, &var_10)
