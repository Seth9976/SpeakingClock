// 函数: sub_4048a0
// 地址: 0x4048a0
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

int32_t* eax
int32_t ecx
void* edx
sub_404714(ecx, edx, eax, &(&__return_addr)[1])
