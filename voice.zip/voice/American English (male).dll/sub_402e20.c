// 函数: sub_402e20
// 地址: 0x402e20
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

return *arg1
