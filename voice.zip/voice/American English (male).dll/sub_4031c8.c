// 函数: sub_4031c8
// 地址: 0x4031c8
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

if (data_413024 u<= 1)
    return 

int32_t __saved_eax_1
int32_t __saved_eax = __saved_eax_1
int32_t ebx
int32_t var_8 = ebx
data_414014(0xeedfae0, 0, 1, &var_8)
