// 函数: sub_406dcc
// 地址: 0x406dcc
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

if (arg2 == 0)
    int32_t edx_4
    edx_4.b = arg1
    return sub_403a40(arg3, (&data_41313c)[edx_4])

sub_406c64()

if (arg1 == 0)
    return sub_403a40(arg3, *data_41478c)

return sub_403a40(arg3, *data_414788)
