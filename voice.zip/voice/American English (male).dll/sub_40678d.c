// 函数: sub_40678d
// 地址: 0x40678d
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

void* ecx
int32_t edx
return sub_40b57c(arg1 - 0x2c, edx, ecx) __tailcall
