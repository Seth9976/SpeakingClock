// 函数: sub_40831c
// 地址: 0x40831c
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

void* result = arg1

if (*(result - 0x13) == 0)
    void* eax_1 = *(arg1 + 8)
    sub_4081b0(arg1 - 0x12, arg1 - 0xe, *(eax_1 + 8), *(eax_1 + 0xc))
    result = arg1
    *(result - 0x13) = 1

return result
