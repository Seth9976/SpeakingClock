// 函数: sub_403e94
// 地址: 0x403e94
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

void* result = *arg1

if (result == 0 || *(result - 8) == 1)
    return result

void* eax_1 = sub_403ab0(*(result - 4))
void* eax_2 = *arg1
*arg1 = eax_1
sub_4027b0(eax_2, eax_1, *(eax_2 - 4))

if (*(eax_2 - 8) s>= 1)
    int32_t temp2_1 = *(eax_2 - 8)
    *(eax_2 - 8) -= 1
    
    if (temp2_1 == 1)
        sub_402648(eax_2 - 8)

return *arg1
