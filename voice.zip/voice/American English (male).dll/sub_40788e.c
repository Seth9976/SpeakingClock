// 函数: sub_40788e
// 地址: 0x40788e
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

int32_t ecx = *(arg1 + 8)

if (ecx u> 4)
    ecx = 0

int32_t eax
eax.b = 0x45
int32_t ebx
ebx.b = *(arg1 - 0x29)
char* edi
return sub_4076c8(eax, sx.d(*(arg1 - 0x2c)) - 1, ecx, edi)
