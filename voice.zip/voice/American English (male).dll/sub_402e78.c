// 函数: sub_402e78
// 地址: 0x402e78
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

return *(arg1 - 0x28)
