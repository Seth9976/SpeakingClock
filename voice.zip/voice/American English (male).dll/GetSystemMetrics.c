// 函数: GetSystemMetrics
// 地址: 0x405930
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

return GetSystemMetrics(nIndex) __tailcall
