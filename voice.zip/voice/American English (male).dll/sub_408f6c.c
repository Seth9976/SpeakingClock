// 函数: sub_408f6c
// 地址: 0x408f6c
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

int32_t var_10 = arg3
var_10.b = arg3.b
int32_t result = 0
sub_408e28(arg1, arg2)

if (sub_403c88(arg1) s>= *arg2)
    int32_t eax_3
    eax_3.b = *(arg1 + *arg2 - 1)
    
    if (eax_3.b == var_10.b)
        *arg2 += 1
        result.b = 1

return result
