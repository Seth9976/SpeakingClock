// 函数: sub_409a52
// 地址: 0x409a52
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

return 
