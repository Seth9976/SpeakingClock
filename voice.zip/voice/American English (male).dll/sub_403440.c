// 函数: sub_403440
// 地址: 0x403440
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

int32_t* eax_3 = sub_4056cc()
int32_t* edx = *eax_3
*eax_3 = *edx
sub_402eb0(edx[2])
TEB* fsbase
fsbase->NtTib.ExceptionList = *arg1
arg1[1]
arg1[2]
return sub_403224()
