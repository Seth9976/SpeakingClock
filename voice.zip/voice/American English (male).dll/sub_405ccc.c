// 函数: sub_405ccc
// 地址: 0x405ccc
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

*arg1 += arg1.b
*arg1 += arg1.b
*arg1 += arg1.b
char temp1 = *arg1
*arg1 += arg1.b
arg1.b = adc.b(arg1.b, 0x5d, temp1 + arg1.b u< temp1)
arg1[1] += (&arg1[1]).b
arg1[1] += (&arg1[1]).b
arg1[1] += (&arg1[1]).b
arg1[1] += (&arg1[1]).b
arg1[1] += (&arg1[1]).b
arg1[1] += (&arg1[1]).b
arg1[1] += (&arg1[1]).b
arg1[1] += (&arg1[1]).b
*arg4 += (&arg1[1]):1.b
int32_t* arg_4
int32_t* esp = &arg_4
*(&arg1[2] * 2) += arg3.b
arg1[2] += (&arg1[2]).b
void* eax_1
eax_1.b = (&arg1[2]).b | 0x10
void* entry_ebx
*(eax_1 + 1 + arg4 + 0x30c80040) += entry_ebx:1.b
void* eax_3
eax_3:1.b = (eax_1 + 2):1.b + arg3.b
*eax_3 ^= eax_3.b
*eax_3 <<= 1
void* eax_4
eax_4:1.b = (eax_3 + 1):1.b + (eax_3 + 1).b
*eax_4 ^= eax_4.b
*(arg4 + __return_addr + 0x40) += eax_4:1.b
*(eax_4 + 0xe00402e) += eax_4:1.b
*eax_4 += eax_4.b
*eax_4 += eax_4.b
*arg3 += eax_4.b
*eax_4 += eax_4.b
char temp2 = *eax_4
*eax_4 += eax_4.b
*eax_4 = adc.b(*eax_4, eax_4.b, temp2 + eax_4.b u< temp2)
void* eax_6
eax_6.b = eax_4.b
*eax_6 += eax_6.b
int32_t temp3 = *(__return_addr + 0x78) | eax_6
*(__return_addr + 0x78) = temp3
int32_t eflags
int16_t temp0
temp0, eflags = __arpl_memw_gpr16(*(__return_addr + 0x70), &arg_4)
*(__return_addr + 0x70) = temp0
void* eax_19
void* ebp_1

if (temp3 != 0)
    uint16_t* esi = __outsd(arg2, *arg4, arg4, eflags)
    arg4 = __outsb(arg2, *esi, esi, eflags)
    
    if (temp3 s>= 0)
        *(eax_6 + 1) += (eax_6 + 1).b
        *(eax_6 + 1) += (eax_6 + 1).b
        *(eax_6 + 1) += (eax_6 + 1).b
        *(eax_6 + 1) += (eax_6 + 1).b
        *(eax_6 + 1) += (eax_6 + 1).b
        *(eax_6 + 1) += (eax_6 + 1).b
        *(eax_6 + 1) += (eax_6 + 1).b
        *(eax_6 + 1) += (eax_6 + 1).b
        *(eax_6 + 1) += (eax_6 + 1).b
        *(eax_6 + 1) += (eax_6 + 1).b
        *(eax_6 + 1) += (eax_6 + 1).b
        *(eax_6 + 1) += (eax_6 + 1).b
        *(eax_6 + 1) += (eax_6 + 1).b
        *(eax_6 + 1) += (eax_6 + 1).b
        *(__return_addr + (entry_ebx << 1) + 0x40) += entry_ebx:1.b
        *(eax_6 + 1) += arg2.b
        *(eax_6 + 1) += (eax_6 + 1).b
        void* eax_7
        eax_7.b = (eax_6 + 1).b + arg3.b
        int32_t* esp_1 = arg_4
        *(eax_7 + 1 + arg4 + 0x30c80040) += entry_ebx:1.b
        void* eax_9
        eax_9:1.b = (eax_7 + 2):1.b + arg3.b
        *eax_9 ^= eax_9.b
        *eax_9 <<= 1
        void* eax_10
        eax_10:1.b = (eax_9 + 1):1.b + (eax_9 + 1).b
        *eax_10 ^= eax_10.b
        *(eax_10 + 0x40) += arg2:1.b
        *(eax_10 + 0xe00402e) += eax_10:1.b
        bool o_1 = add_overflow(eax_10, 0xffffffff)
        arg5 = *esp_1
        arg4 = esp_1[1]
        ebp_1 = esp_1[2]
        entry_ebx = esp_1[4]
        arg2 = (esp_1[5]).w
        arg3 = esp_1[6]
        eax_6 = esp_1[7]
        esp = &esp_1[8]
        
        if (o_1)
            int16_t es_1
            arg4, es_1 = __les_gprz_memp(*eax_6)
            *(eax_6 + 0x2f) += arg3.b
            eax_19 = eax_6 + 2
            goto label_405dcf
        
        if (eax_10 - 1 s< 0)
            goto label_405de8
        
        if (o_1)
            *eax_6 += eax_6.b
            *eax_6 += eax_6.b
            *eax_6 += eax_6.b
            *eax_6 += eax_6.b
            *eax_6 += eax_6.b
            *eax_6 += eax_6.b
            eax_6.b ^= 0x5e
            goto label_405e0b
        
        *(arg5 + 0x6e)
    
    *eax_6 += eax_6.b
    *eax_6 += eax_6.b
    *eax_6 += eax_6.b
    *eax_6 += eax_6.b

*eax_6 += eax_6.b
*eax_6 += eax_6.b
*eax_6 += eax_6.b
*eax_6 += eax_6.b
*eax_6 += eax_6.b
*eax_6 += eax_6.b
*eax_6 += eax_6.b
*eax_6 += eax_6.b
*eax_6 += eax_6.b
*eax_6 += eax_6.b
eax_6.b += entry_ebx.b
*(eax_6 + 1) += arg2.b
*(eax_6 + 1) += (eax_6 + 1).b
*(eax_6 + 1) += arg2:1.b
ebp_1 = esp[1]
esp = &esp[2]
*(eax_6 + 2 + arg4 + 0x30c80040) += entry_ebx:1.b
void* eax_15
eax_15:1.b = (eax_6 + 3):1.b + arg3.b
*eax_15 ^= eax_15.b
*eax_15 <<= 1
void* eax_16
eax_16:1.b = (eax_15 + 1):1.b + (eax_15 + 1).b
*eax_16 ^= eax_16.b
void* eax_18 = eax_16 - 1

while (true)
    eax_19 = eax_18 + 1
label_405dcf:
    *(eax_19 + 0x40) += arg2:1.b
    char temp5_1 = *(eax_19 + 0xc00402e)
    *(eax_19 + 0xc00402e) += eax_19:1.b
    ebp_1 += 1
    
    if (arg5 != 1)
        break
    
    ebp_1.w -= 1
    int16_t temp0_1
    temp0_1, arg5 = __insd(arg5 - 2, arg2, eflags)
    *arg5 = temp0_1
    arg4 = __outsd(arg2, *arg4, arg4, eflags)
    char* eax_29
    void* ebp_5
    
    if (temp5_1 + eax_19:1.b u< temp5_1)
        *eax_19 += eax_19.b
        int16_t ds
        *(arg4 + 0x40) = ds
        *eax_19 += arg2.b
        *eax_19 += eax_19.b
        eax_19.b += arg3.b
        esp = *esp
        *(eax_19 + 1 + arg4 + 0x30c80040) += entry_ebx:1.b
        void* eax_26
        eax_26:1.b = (eax_19 + 2):1.b + arg3.b
        *eax_26 ^= eax_26.b
        *eax_26 <<= 1
        void* eax_27
        eax_27:1.b = (eax_26 + 1):1.b + (eax_26 + 1).b
        *eax_27 ^= eax_27.b
        eax_29 = eax_27
        *(arg4 + ebp_1 + 0x40) += eax_29:1.b
        char temp7_1 = eax_29[0x900402e]
        eax_29[0x900402e] += eax_29:1.b
        ebp_5 = ebp_1 + 2
        
        if (ebp_1 + 2 s< 0)
            goto label_405f05
        
        if (temp7_1 + eax_29:1.b u< temp7_1)
            *eax_29 += eax_29.b
            *eax_29 += eax_29.b
            *eax_29 += eax_29.b
            *eax_29 += eax_29.b
            *eax_29 += eax_29.b
            *eax_29 += eax_29.b
            *eax_29 += eax_29.b
            *eax_29 += eax_29.b
            *eax_29 += eax_29.b
            *eax_29 += eax_29.b
            *eax_29 += eax_29.b
            arg5 = *(esp + 1)
            esp += 5
            eax_29 = &eax_29[1]
            goto label_405f1b
        
        int32_t edi_2 = *esp
        esp[1]
        ebp_1 = esp[2]
        entry_ebx = esp[4]
        arg2 = (esp[5]).w
        arg3 = esp[6]
        esp[7]
        esp = &esp[8]
        uint8_t temp0_2
        temp0_2, arg5 = __insb(edi_2, arg2, eflags)
        *arg5 = temp0_2
        void* eax_31
        eax_31.b = __in_al_immb(0x5e, eflags)
        eax_18 = eax_31 + 1
        *eax_18 += eax_18.b
        *eax_18 += eax_18.b
        *eax_18 += eax_18.b
        *eax_18 += eax_18.b
        *eax_18 += eax_18.b
        *eax_18 += eax_18.b
        *eax_18 += eax_18.b
        *eax_18 += eax_18.b
        *eax_18 += eax_18.b
        *eax_18 += eax_18.b
        goto label_405eaf
    
    eax_6 = eax_19
label_405de8:
    eax_6.b ^= 0x5e
    eax_6 += 1
    *eax_6 += eax_6.b
    *eax_6 += eax_6.b
    *eax_6 += eax_6.b
    *eax_6 += eax_6.b
    *eax_6 += eax_6.b
    *eax_6 += eax_6.b
    *eax_6 += eax_6.b
    *eax_6 += eax_6.b
    *eax_6 += eax_6.b
    *eax_6 += eax_6.b
    *eax_6 += eax_6.b
    *eax_6 += eax_6.b
    *eax_6 += eax_6.b
    *eax_6 += eax_6.b
    arg4[entry_ebx << 1] += arg2:1.b
label_405e0b:
    *(eax_6 + 1) += arg2.b
    *(eax_6 + 1) += (eax_6 + 1).b
    void* eax_20
    eax_20.b = (eax_6 + 1).b + arg3.b
    esp = *esp
    *(eax_20 + 1 + arg4 + 0x30c80040) += entry_ebx:1.b
    void* eax_22
    eax_22:1.b = (eax_20 + 2):1.b + arg3.b
    *eax_22 ^= eax_22.b
    *eax_22 <<= 1
    void* eax_23
    eax_23:1.b = (eax_22 + 1):1.b + (eax_22 + 1).b
    *eax_23 ^= eax_23.b
    eax_18 = eax_23
    *(arg4 + ebp_1 + 0x40) += eax_18:1.b
    char temp9_1 = *(eax_18 + 0xb00402e)
    *(eax_18 + 0xb00402e) += eax_18:1.b
    bool c_3 = temp9_1 + eax_18:1.b u< temp9_1
    ebp_1 += 1
    arg3 -= 1
    uint16_t* esi_1 = __outsb(arg2, *arg4, arg4, eflags)
    char* temp10_1 = arg5
    arg5 -= 1
    
    if (temp10_1 != 1)
    label_405eaf:
        *eax_18 += eax_18.b
        *eax_18 += eax_18.b
        *eax_18 += eax_18.b
        *eax_18 += eax_18.b
        eax_18:1.b *= 2
        esi_1 = *esp
        esp = &esp[1]
    else
        ebp_1 += 1
        
        if (c_3)
            *eax_18 += eax_18.b
            *eax_18 += eax_18.b
            *eax_18 += eax_18.b
            *eax_18 += eax_18.b
            eax_18.b = __in_al_immb(0x5e, eflags)
        else
            arg4 = __outsd(arg2, *esi_1, esi_1, eflags)
            
            if (c_3)
                continue
            
            arg4 = *esp
            esp = &esp[1]
            eax_19 = eax_18 + 1
            *eax_19 += eax_19.b
            *eax_19 += eax_19.b
            *eax_19 += eax_19.b
            *eax_19 += eax_19.b
            *eax_19 += eax_19.b
            *eax_19 += eax_19.b
            *eax_19 += eax_19.b
        label_405e51:
            *eax_19 += eax_19.b
            *eax_19 += eax_19.b
            *eax_19 += eax_19.b
            *eax_19 += eax_19.b
            *eax_19 += eax_19.b
            *eax_19 += eax_19.b
            *eax_19 += eax_19.b
            arg4[(entry_ebx << 1) + 0x100040] += arg3.b
            *eax_19 += eax_19.b
            *(esp - 4) = ebp_1
            *eax_19 ^= eax_19.b
            breakpoint
    
    *(eax_18 + 1) += arg2.b
    *(eax_18 + 1) += (eax_18 + 1).b
    *(eax_18 + 0x5f) += (eax_18 + 1).b
    *(eax_18 + 2 + esi_1 + 0x30c80040) += entry_ebx:1.b
    void* eax_34
    eax_34:1.b = (eax_18 + 3):1.b + arg3.b
    *eax_34 ^= eax_34.b
    *eax_34 <<= 1
    void* eax_35
    eax_35:1.b = (eax_34 + 1):1.b + (eax_34 + 1).b
    *eax_35 ^= eax_35.b
    eax_29 = eax_35
    
    while (true)
        *(esi_1 + ebp_1 + 0x40) += eax_29:1.b
        char temp13_1 = eax_29[0x1200402e]
        eax_29[0x1200402e] += eax_29:1.b
        void* ebp_6 = ebp_1 + 1
        ebp_1 = ebp_6 + 1
        void* eax_45
        uint16_t* esi_3
        
        if (ebp_6 + 1 s< 0)
        label_405f5d:
            *eax_29 += eax_29.b
            *eax_29 += eax_29.b
            *eax_29 += eax_29.b
            *eax_29 += eax_29.b
            *eax_29 += eax_29.b
            *eax_29 += eax_29.b
            *eax_29 += eax_29.b
            *eax_29 += eax_29.b
            *eax_29 += eax_29.b
            arg5[(entry_ebx << 1) + 0x100040] += entry_ebx.b
            *eax_29 += eax_29.b
        else
            if (temp13_1 + eax_29:1.b u< temp13_1)
                goto label_405f5a
            
            int32_t edi_3 = *esp
            arg4 = esp[1]
            void* ebp_7 = esp[2]
            entry_ebx = esp[4]
            arg2 = (esp[5]).w
            arg3 = esp[6]
            eax_29 = esp[7]
            esp = &esp[8]
            uint8_t temp0_5
            temp0_5, arg5 = __insb(edi_3, arg2, eflags)
            *arg5 = temp0_5
            ebp_1 = ebp_7 + 1
            
            if (ebp_7 + 1 s< 0)
                *eax_29 += eax_29.b
                *eax_29 += eax_29.b
                *eax_29 += eax_29.b
            label_405f5a:
                *eax_29 += eax_29.b
                *eax_29 += eax_29.b
                *eax_29 += eax_29.b
                *eax_29 += eax_29.b
                *eax_29 += eax_29.b
                *eax_29 += eax_29.b
                *eax_29 += eax_29.b
            else if (not(add_overflow(ebp_7, 1)))
                ebp_5 = *(arg5 + 0x6e) * 0x405f4490
                *eax_29 += eax_29.b
                *eax_29 += eax_29.b
                *eax_29 += eax_29.b
                *eax_29 += eax_29.b
                *eax_29 += eax_29.b
            label_405f05:
                *eax_29 += eax_29.b
                *eax_29 += eax_29.b
                *eax_29 += eax_29.b
                *eax_29 += eax_29.b
                *eax_29 += eax_29.b
                *eax_29 += eax_29.b
                *eax_29 += eax_29.b
                *eax_29 += eax_29.b
                *eax_29 += eax_29.b
                arg5[(entry_ebx << 1) + 0x40] += eax_29.b
            label_405f1b:
                *eax_29 += arg2.b
                *eax_29 += eax_29.b
                eax_29[0x5e] += eax_29.b
                *(&eax_29[1] + arg4 + 0x30c80040) += entry_ebx:1.b
                void* eax_38
                eax_38:1.b = (&eax_29[2]):1.b + arg3.b
                *eax_38 ^= eax_38.b
                *eax_38 <<= 1
                void* eax_39
                eax_39:1.b = (eax_38 + 1):1.b + (eax_38 + 1).b
                *eax_39 ^= eax_39.b
                eax_29 = eax_39
                *(arg4 + ebp_5 + 0x40) += eax_29:1.b
                char temp11_1 = eax_29[0x900402e]
                eax_29[0x900402e] += eax_29:1.b
                bool c_6 = temp11_1 + eax_29:1.b u< temp11_1
                ebp_1 = ebp_5 + 1
                char* temp12_1 = arg3
                arg3 -= 1
                esi_3 = __outsb(arg2, *arg4, arg4, eflags)
                
                if (temp12_1 == 1)
                    eax_29[0x2e] += arg3.b
                    eax_45 = &eax_29[1]
                    break
                
                if (c_6)
                    *eax_29 += eax_29.b
                    *eax_29 += eax_29.b
                    *eax_29 += eax_29.b
                    *eax_29 += eax_29.b
                    *eax_29 += eax_29.b
                    trap(0xd)
                
                esi_1 = __outsd(arg2, *esi_3, esi_3, eflags)
                
                if (c_6)
                    eax_29 = &eax_29[1]
                    continue
                else
                    arg5[(entry_ebx << 1) + 0x40] = rrc.b(arg5[(entry_ebx << 1) + 0x40], 0, c_6)
                    *eax_29 += eax_29.b
                    *eax_29 += eax_29.b
                    *eax_29 += eax_29.b
                
                goto label_405f5d
            
            *eax_29 += eax_29.b
            *eax_29 += eax_29.b
            *eax_29 += eax_29.b
            char temp16_1 = *eax_29
            *eax_29 += eax_29.b
            bool p_1 = unimplemented  {add byte [eax], al}
            bool a_1 = unimplemented  {add byte [eax], al}
            bool d
            *(esp - 4) = (add_overflow(temp16_1, eax_29.b) ? 1 : 0) << 0xb | (d ? 1 : 0) << 0xa
                | (temp16_1 + eax_29.b s< 0 ? 1 : 0) << 7
                | (temp16_1 == neg.b(eax_29.b) ? 1 : 0) << 6 | (a_1 ? 1 : 0) << 4
                | (p_1 ? 1 : 0) << 2 | (temp16_1 + eax_29.b u< temp16_1 ? 1 : 0)
            *(esp - 4)
            eax_29[1] += arg2.b
            eax_29[1] += (&eax_29[1]).b
            eax_29.b = (&eax_29[1]).b + entry_ebx:1.b
        
        esi_3 = *esp
        *(&eax_29[1] + esi_3 + 0x30c80040) += entry_ebx:1.b
        void* eax_42
        eax_42:1.b = (&eax_29[2]):1.b + arg3.b
        *eax_42 ^= eax_42.b
        *eax_42 <<= 1
        void* eax_43
        eax_43:1.b = (eax_42 + 1):1.b + (eax_42 + 1).b
        *eax_43 ^= eax_43.b
        eax_45 = eax_43
    label_405f93:
        *(esi_3 + ebp_1 + 0x40) += eax_45:1.b
        *(eax_45 + 0xa00402e) += eax_45:1.b
        uint16_t* esi_4 = *(esi_3 + 0x42) * 0x72655a79
        __outsd(arg2, *esi_4, esi_4, eflags)
        trap(0xd)
    
    goto label_405f93

goto label_405e51
