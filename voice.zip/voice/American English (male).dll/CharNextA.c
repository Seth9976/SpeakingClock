// 函数: CharNextA
// 地址: 0x405920
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

return CharNextA(lpsz) __tailcall
