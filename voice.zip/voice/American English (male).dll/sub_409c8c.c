// 函数: sub_409c8c
// 地址: 0x409c8c
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

return 
