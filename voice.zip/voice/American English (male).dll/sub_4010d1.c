// 函数: sub_4010d1
// 地址: 0x4010d1
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

int32_t ecx
ecx.b = 0x10
void* entry_ebx
char temp0 = *(entry_ebx - 0x3affbff0)
*(entry_ebx - 0x3affbff0) += entry_ebx:1.b
*(arg1 + 1) = adc.b(*(arg1 + 1), (arg1 + 1).b, temp0 + entry_ebx:1.b u< temp0)
*(arg1 + 1) = &(arg1 + 1)[*(arg1 + 1)]
*(arg1 + 1) += (arg1 + 1).b
*(arg1 + 1) += (arg1 + 1).b
*(arg1 + 1) += (arg1 + 1).b
*(arg1 + 1) += (arg1 + 1).b
*(arg1 + 1) += (arg1 + 1).b
*(arg1 + 1) = rol.b(*(arg1 + 1), 0)
*(arg1 + 1) += (arg1 + 1).b
char temp1 = *(arg1 + 1)
*(arg1 + 1) += (arg1 + 1).b
*(arg1 + 1) = rlc.d(*(arg1 + 1), 1, temp1 + (arg1 + 1).b u< temp1)
*(arg1 + 2) += 0x10
*(arg1 + 2) += (arg1 + 2).b
*(arg1 + 2) += (arg1 + 2).b
*(arg1 + 2) += (arg1 + 2).b
*(arg3 + 0x114c0040) += 0x10
char temp2 = ecx:1.b
ecx:1.b += entry_ebx.b
*(arg1 + 3) = adc.b(*(arg1 + 3), (arg1 + 3).b, temp2 + entry_ebx.b u< temp2)
*(arg1 + 3) += (arg1 + 3).b
*(arg1 + 3) += (arg1 + 3).b
*(arg1 + 3) += (arg1 + 3).b
*(arg1 + 3) += (arg1 + 3).b
*(arg1 + 3) += (arg1 + 3).b
*(arg1 + 3) += (arg1 + 3).b
*(arg1 + 3) += (arg1 + 3).b
*(arg1 + 3) += (arg1 + 3).b
*(arg1 + 3) += (arg1 + 3).b
*(arg1 + 3) += (arg1 + 3).b
*(arg1 + 3) += (arg1 + 3).b
char temp3 = *(arg1 + 3)
*(arg1 + 3) += (arg1 + 3).b
*(arg1 + 3) = adc.d(*(arg1 + 3), arg1 + 3, temp3 + (arg1 + 3).b u< temp3)
void* eax_2
eax_2.b = (arg1 + 3).b
*eax_2 += eax_2.b
eax_2.b |= 0x10
*(eax_2 + 1 + arg4 + 1 + 0x4f940040) += entry_ebx:1.b
*(eax_2 - 0x2fffbfaf) += (eax_2 + 2):1.b
*(eax_2 + 2) ^= (eax_2 + 2).b
uint16_t* esi_1
int16_t es
esi_1, es = __les_gprz_memp(*(eax_2 + 2))
*(eax_2 + 0x64004052) += arg2:1.b
*(eax_2 + 0x11004032) += (eax_2 + 4):1.b
void var_1
void* var_5 = &var_1
int32_t eflags
__outsb(arg2, *esi_1, esi_1, eflags)

if (ecx != 1)
    jump(0x401152)

entry_ebx:1.b s>>= 0x25
void* var_9 = eax_2 + 4
int32_t var_d = ecx - 1
*(entry_ebx + 0x4c25ffc0) += ecx.b
int32_t var_11 = ecx
*(entry_ebx + 0x4825ffc0) += (ecx + 1).b
int32_t var_15 = ecx + 1
*(entry_ebx + 0x4425ffc0) += (ecx + 2).b
int32_t var_19 = ecx + 2
*(entry_ebx + 0x4025ffc0) += (ecx + 3).b
int32_t var_1d = ecx + 3
*(entry_ebx + 0x3c25ffc0) += (ecx + 4).b
int32_t var_21 = ecx + 4
*(entry_ebx + 0x3825ffc0) += (ecx + 5).b
int32_t var_25 = ecx + 5
*(entry_ebx + 0x3425ffc0) += (ecx + 6).b
int32_t var_29 = ecx + 6
*(entry_ebx - 0x7fda0040) += (ecx + 7).b
int32_t var_2d = ecx + 7
*(entry_ebx + 0x3025ffc0) += (ecx + 8).b
int32_t var_31 = ecx + 8
*(entry_ebx + 0x2c25ffc0) += (ecx + 9).b
int32_t var_35 = ecx + 9
*(entry_ebx + 0x2825ffc0) += (ecx + 0xa).b
int32_t var_39 = ecx + 0xa
*(entry_ebx - 0x67da0040) += (ecx + 0xb).b
int32_t var_3d = ecx + 0xb
*(entry_ebx - 0x6bda0040) += (ecx + 0xc).b
int32_t var_41 = ecx + 0xc
*(entry_ebx - 0x6fda0040) += (ecx + 0xd).b
int32_t var_45 = ecx + 0xd
*(entry_ebx + 0x2425ffc0) += (ecx + 0xe).b
int32_t var_49 = ecx + 0xe
*(entry_ebx + 0x2025ffc0) += (ecx + 0xf).b
int32_t var_4d = ecx + 0xf
*(entry_ebx - 0x57da0040) += (ecx + 0x10).b
int32_t var_51 = ecx + 0x10
*(entry_ebx - 0x5bda0040) += (ecx + 0x11).b
int32_t var_55 = ecx + 0x11
*(entry_ebx - 0x5fda0040) += (ecx + 0x12).b
int32_t var_59 = ecx + 0x12
*(entry_ebx + 0x1c25ffc0) += (ecx + 0x13).b
int32_t var_5d = ecx + 0x13
*(entry_ebx + 0x1825ffc0) += (ecx + 0x14).b
int32_t var_61 = ecx + 0x14
*(entry_ebx + 0x1425ffc0) += (ecx + 0x15).b
int32_t var_65 = ecx + 0x15
*(entry_ebx + 0x1025ffc0) += (ecx + 0x16).b
int32_t var_69 = ecx + 0x16
*(entry_ebx - 0x3b7cac40) += (ecx + 0x16).b + 1
*(eax_2 + 4 + (arg3 << 3) + 0x59) += arg2.b
undefined
