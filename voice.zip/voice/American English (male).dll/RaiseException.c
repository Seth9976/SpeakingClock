// 函数: RaiseException
// 地址: 0x401168
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

noreturn RaiseException(dwExceptionCode, dwExceptionFlags, nNumberOfArguments, lpArguments)
    __tailcall
