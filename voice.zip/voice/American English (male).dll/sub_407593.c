// 函数: sub_407593
// 地址: 0x407593
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

*(arg2 - 4)
sub_4039ec(arg2 - 0x14)
return arg1
