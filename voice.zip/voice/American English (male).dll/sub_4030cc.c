// 函数: sub_4030cc
// 地址: 0x4030cc
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

return 
