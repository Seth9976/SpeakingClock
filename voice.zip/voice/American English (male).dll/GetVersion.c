// 函数: GetVersion
// 地址: 0x401270
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

return GetVersion() __tailcall
