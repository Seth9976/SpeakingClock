// 函数: sub_4048ac
// 地址: 0x4048ac
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

int32_t* ecx_2 = *arg1

if (ecx_2 == 0)
    return 

*arg1 = 0
int32_t temp0_1 = ecx_2[-2]
ecx_2[-2] -= 1

if (temp0_1 != 1)
    return 

int32_t* var_4_1 = arg1
int32_t ecx
ecx.b = *(arg2 + 1)
char** edx = *(ecx + arg2 + 6)

if (edx != 0)
    int32_t ecx_1 = ecx_2[-1]
    
    if (ecx_1 != 0)
        sub_404398(ecx_2, *edx, ecx_1)

sub_402648(ecx_2 - 8)
