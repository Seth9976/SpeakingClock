// 函数: MultiByteToWideChar
// 地址: 0x401210
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

return MultiByteToWideChar(CodePage, dwFlags, lpMultiByteStr, cbMultiByte, lpWideCharStr, 
    cchWideChar) __tailcall
