// 函数: sub_404380
// 地址: 0x404380
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

if (data_41300c != 0)
    return data_41300c()

int32_t eax
eax.b = 0x10
sub_402710(eax)
noreturn
