// 函数: sub_4081b0
// 地址: 0x4081b0
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

int16_t* var_8 = arg1
int16_t* edx
return sub_408064(arg1, edx, arg2, &var_8:2, arg3, arg4)
