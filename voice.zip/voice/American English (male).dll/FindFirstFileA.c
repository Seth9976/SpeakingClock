// 函数: FindFirstFileA
// 地址: 0x4011a8
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

return FindFirstFileA(lpFileName, lpFindFileData) __tailcall
