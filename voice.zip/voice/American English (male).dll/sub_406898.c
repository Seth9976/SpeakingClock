// 函数: sub_406898
// 地址: 0x406898
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

int32_t var_10 = arg2
arg2.b = 1
return sub_4033c4(sub_409fe0(0x406318, arg2, arg1, arg3, var_10))
