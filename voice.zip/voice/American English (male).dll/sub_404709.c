// 函数: sub_404709
// 地址: 0x404709
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

return 
