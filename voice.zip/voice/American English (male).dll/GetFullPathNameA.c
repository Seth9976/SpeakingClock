// 函数: GetFullPathNameA
// 地址: 0x405850
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

return GetFullPathNameA(lpFileName, nBufferLength, lpBuffer, lpFilePart) __tailcall
