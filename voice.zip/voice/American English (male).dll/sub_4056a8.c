// 函数: sub_4056a8
// 地址: 0x4056a8
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

HLOCAL result = sub_405680()

if (data_413098 == 0xffffffff)
    return result

return TlsFree(data_413098)
