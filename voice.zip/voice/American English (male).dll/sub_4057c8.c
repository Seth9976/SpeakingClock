// 函数: sub_4057c8
// 地址: 0x4057c8
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

data_414670 -= 1
