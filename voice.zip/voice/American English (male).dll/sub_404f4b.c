// 函数: sub_404f4b
// 地址: 0x404f4b
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

return 
