// 函数: sub_402e64
// 地址: 0x402e64
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

sub_402f14(arg1)
return sub_402648(arg1)
