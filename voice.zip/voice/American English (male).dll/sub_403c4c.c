// 函数: sub_403c4c
// 地址: 0x403c4c
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

return 
