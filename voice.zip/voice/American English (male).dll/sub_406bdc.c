// 函数: sub_406bdc
// 地址: 0x406bdc
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

int32_t __saved_esi
void arg_4
sub_403adc(arg1, &__saved_esi, sub_406b10(&arg_4, 0, 0, &__saved_esi))
return arg1
