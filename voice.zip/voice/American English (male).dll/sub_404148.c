// 函数: sub_404148
// 地址: 0x404148
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

int32_t ecx = 0

if (arg2 != 0)
    ecx = *(arg2 - 4)

OLECHAR** eax
return sub_40405c(eax, arg2, ecx) __tailcall
