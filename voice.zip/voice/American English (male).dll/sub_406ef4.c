// 函数: sub_406ef4
// 地址: 0x406ef4
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

int32_t distanceToMoveHigh = arg5
return SetFilePointer(arg3, arg4, &distanceToMoveHigh, arg2)
