// 函数: FreeResource
// 地址: 0x405820
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

return FreeResource(hResData) __tailcall
