// 函数: sub_40273c
// 地址: 0x40273c
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

void* result = sub_4056cc()
*(result + 4) = arg1
return result
