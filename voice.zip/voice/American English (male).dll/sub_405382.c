// 函数: sub_405382
// 地址: 0x405382
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

return 
