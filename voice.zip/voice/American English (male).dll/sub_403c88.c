// 函数: sub_403c88
// 地址: 0x403c88
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

if (arg1 != 0)
    *(arg1 - 4)
