// 函数: sub_403f1f
// 地址: 0x403f1f
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

return 
