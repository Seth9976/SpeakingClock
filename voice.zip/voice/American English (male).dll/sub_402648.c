// 函数: sub_402648
// 地址: 0x402648
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

if (arg1 == 0)
    return 0

int32_t result = data_41303c()

if (result == 0)
    return result

int32_t eax
eax.b = 2
sub_402710(eax)
noreturn
