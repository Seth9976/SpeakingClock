// 函数: sub_403798
// 地址: 0x403798
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

int32_t i_1 = *arg1
void* esi = arg1 + 4
int32_t result
int32_t i

do
    result = sub_4053d8(**(esi + 4), *esi)
    esi += 8
    i = i_1
    i_1 -= 1
while (i != 1)
return result
