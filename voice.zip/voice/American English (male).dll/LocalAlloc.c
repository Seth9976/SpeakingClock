// 函数: LocalAlloc
// 地址: 0x4055cc
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

return LocalAlloc(uFlags, uBytes) __tailcall
