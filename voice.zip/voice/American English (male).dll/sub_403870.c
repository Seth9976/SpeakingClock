// 函数: sub_403870
// 地址: 0x403870
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

uint32_t numberOfBytesWritten = arg1

if (data_414044 == 0)
    if (data_41302c == 0)
        MessageBoxA(nullptr, "Runtime error     at 00000000", "Error", MB_OK)
    
    return 

if (data_414218 == 0xd7b2 && data_414220 u> 0)
    data_414230()

WriteFile(GetStdHandle(STD_OUTPUT_HANDLE), "Runtime error     at 00000000", 0x1e, 
    &numberOfBytesWritten, nullptr)
WriteFile(GetStdHandle(STD_OUTPUT_HANDLE), 0x4038f8, 2, &numberOfBytesWritten, nullptr)
