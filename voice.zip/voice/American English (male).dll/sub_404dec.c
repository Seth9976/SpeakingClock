// 函数: sub_404dec
// 地址: 0x404dec
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

int32_t eax
return sub_404e14(eax)
