// 函数: sub_4039ec
// 地址: 0x4039ec
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

void* edx = *arg1

if (edx == 0)
    return 

*arg1 = 0

if (*(edx - 8) s< 1)
    return 

int32_t temp1_1 = *(edx - 8)
*(edx - 8) -= 1

if (temp1_1 == 1)
    int32_t* var_4_1 = arg1
    sub_402648(edx - 8)
