// 函数: sub_407cce
// 地址: 0x407cce
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

int32_t edx = 0

while (true)
    int32_t eax
    eax.b = *arg2
    arg2 = &arg2[1]
    eax.b -= 0x3a
    char temp0_1 = eax.b
    eax.b += 0xa
    
    if (temp0_1 u< 0xf6)
        break
    
    long double x87_r0 = arg3 * float.t(data_413178)
    *(arg1 - 0xc) = eax
    arg3 = x87_r0 + float.t(*(arg1 - 0xc))
    edx += 1
