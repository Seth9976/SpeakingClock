// 函数: MessageBoxA
// 地址: 0x405940
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

return MessageBoxA(hWnd, lpText, lpCaption, uType) __tailcall
