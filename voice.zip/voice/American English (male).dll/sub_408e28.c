// 函数: sub_408e28
// 地址: 0x408e28
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

int32_t ebx = *arg2

while (true)
    int32_t result = sub_403c88(arg1)
    
    if (ebx s> result || *(arg1 + ebx - 1) != 0x20)
        *arg2 = ebx
        return result
    
    ebx += 1
