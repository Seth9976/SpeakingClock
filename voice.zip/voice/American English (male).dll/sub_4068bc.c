// 函数: sub_4068bc
// 地址: 0x4068bc
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

int32_t result = sub_402628(arg1)
sub_4028b8(result, arg1, 0)
return result
