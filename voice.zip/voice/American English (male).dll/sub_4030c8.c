// 函数: sub_4030c8
// 地址: 0x4030c8
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

return 
