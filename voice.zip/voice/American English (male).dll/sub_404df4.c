// 函数: sub_404df4
// 地址: 0x404df4
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

int32_t* result = sub_402628(8)
*result = data_413034
result[1] = arg1
data_413034 = result
return result
