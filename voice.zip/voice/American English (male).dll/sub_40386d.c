// 函数: sub_40386d
// 地址: 0x40386d
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

return 
