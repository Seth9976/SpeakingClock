// 函数: sub_402e48
// 地址: 0x402e48
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

return sub_402ebc(arg1, sub_402628(sub_402e78(arg1)))
