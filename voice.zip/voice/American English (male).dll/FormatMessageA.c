// 函数: FormatMessageA
// 地址: 0x405818
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

return FormatMessageA(dwFlags, lpSource, dwMessageId, dwLanguageId, lpBuffer, nSize, Arguments)
    __tailcall
