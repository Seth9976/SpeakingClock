// 函数: sub_403470
// 地址: 0x403470
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

TEB* fsbase
fsbase->NtTib.ExceptionList = arg1
return (arg2 + 5)()
