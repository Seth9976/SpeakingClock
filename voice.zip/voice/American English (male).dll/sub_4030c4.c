// 函数: sub_4030c4
// 地址: 0x4030c4
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

return 
