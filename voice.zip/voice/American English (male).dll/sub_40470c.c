// 函数: sub_40470c
// 地址: 0x40470c
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

int32_t* eax
void* edx
sub_4048ac(eax, edx)
