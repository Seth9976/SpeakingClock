// 函数: sub_408354
// 地址: 0x408354
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

void* result = arg1

if (*(result - 0x1d) == 0)
    void* eax_1 = *(arg1 + 8)
    sub_407f04(arg1 - 0x1a, arg1 - 0x18, arg1 - 0x16, arg1 - 0x1c, *(eax_1 + 8), *(eax_1 + 0xc))
    result = arg1
    *(result - 0x1d) = 1

return result
