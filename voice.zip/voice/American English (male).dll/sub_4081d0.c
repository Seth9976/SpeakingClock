// 函数: sub_4081d0
// 地址: 0x4081d0
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

int32_t var_10 = arg2
uint32_t var_c
sub_407e10(&var_c, arg1)
int32_t var_8
return mods.dp.d(sx.q(var_8), 7) + 1
