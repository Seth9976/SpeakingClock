// 函数: sub_403bd4
// 地址: 0x403bd4
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

int32_t __saved_edx
void** eax
sub_403adc(eax, &__saved_edx, 1)
