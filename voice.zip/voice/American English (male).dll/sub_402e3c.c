// 函数: sub_402e3c
// 地址: 0x402e3c
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

int32_t* result = *(arg1 - 0x24)

if (result == 0)
    return result

return *result
