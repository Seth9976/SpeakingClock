// 函数: sub_404f94
// 地址: 0x404f94
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

return InterlockedDecrement(arg1 + 4)
