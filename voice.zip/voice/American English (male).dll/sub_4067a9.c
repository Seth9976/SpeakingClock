// 函数: sub_4067a9
// 地址: 0x4067a9
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

return sub_404ffc(&arg1[-0xb]) __tailcall
