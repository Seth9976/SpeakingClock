// 函数: sub_408d92
// 地址: 0x408d92
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

*arg1 += arg1.b
int32_t eflags
int32_t eflags_1
char temp0
temp0, eflags_1 = __das(arg1.b, eflags)
arg1.b = temp0
char* var_4 = arg1
*arg1 += arg1.b
*(arg3 + 0x30) += arg1.b
char* var_8 = arg1
*(arg3 + 0x4e) += arg1.b
char* var_c = arg1
*arg1 += arg1.b
*arg1 += arg1.b
*arg1 += arg1.b
*arg1 += arg1.b
*arg1 += arg1:1.b
*arg1 += arg1.b
*(arg4 - 0x78) += arg2.b
arg1.b = __in_al_dx(arg2.w, eflags_1)
*(arg4 - 0x107) = 0
*(arg4 - 0x10b) = 0

if (arg2 == 0)
    int32_t* var_120_1 = arg4 - 3
    sub_408604(sub_408e0d+3, arg2)
else
    int32_t* var_120 = arg4 - 3
    sub_408604(arg2, arg2)

sub_403adc(arg1, arg4 - 0x103, *(arg4 - 0x107))
*(arg4 - 3)
return arg1
