// 函数: sub_4026c4
// 地址: 0x4026c4
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

int32_t ebx
ebx.b = arg1.b & 0x7f
int32_t ecx

if (data_414008 != 0)
    ecx = data_414008()

if (ebx.b == 0)
    void* eax_1
    eax_1, ecx = sub_4056cc()
    ebx = *(eax_1 + 4)
else if (ebx.b u<= 0x18)
    void* eax_2
    eax_2.b = ebx.b
    ebx.b = *(eax_2 + 0x413044)

int32_t eax_3
eax_3.b = ebx.b
sub_4026b8(ecx, arg2)
noreturn
