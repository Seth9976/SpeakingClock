// 函数: sub_406c2c
// 地址: 0x406c2c
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

int32_t var_8 = arg1
char* eax
int32_t eax_1 = sub_402944(eax, &var_8)

if (var_8 == 0)
    return eax_1

return arg2
