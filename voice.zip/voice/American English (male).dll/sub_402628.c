// 函数: sub_402628
// 地址: 0x402628
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

if (arg1 s<= 0)
    return 0

int32_t result = data_413038()

if (result != 0)
    return result

int32_t eax
eax.b = 1
sub_402710(eax)
noreturn
