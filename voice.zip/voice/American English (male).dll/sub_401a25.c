// 函数: sub_401a25
// 地址: 0x401a25
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

int32_t result
result.b = data_4145bc
return result
