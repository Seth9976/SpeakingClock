// 函数: EnumCalendarInfoA
// 地址: 0x405808
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

return EnumCalendarInfoA(lpCalInfoEnumProc, Locale, Calendar, CalType) __tailcall
