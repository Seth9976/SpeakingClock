// 函数: FreeLibrary
// 地址: 0x4011b0
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

return FreeLibrary(hLibModule) __tailcall
