// 函数: sub_404484
// 地址: 0x404484
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

int32_t* eax
char* edx
return sub_404398(eax, edx, 1) __tailcall
