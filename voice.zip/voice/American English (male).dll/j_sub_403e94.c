// 函数: j_sub_403e94
// 地址: 0x403ed8
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

return sub_403e94(arg1) __tailcall
