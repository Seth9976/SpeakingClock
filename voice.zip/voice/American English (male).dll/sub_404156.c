// 函数: sub_404156
// 地址: 0x404156
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

return 
