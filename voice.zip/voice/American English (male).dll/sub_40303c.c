// 函数: sub_40303c
// 地址: 0x40303c
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

if (arg1 != 0 && sub_4030a8(*arg1, arg2) != 0)
    return 1

return 0
