// 函数: sub_407f04
// 地址: 0x407f04
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

int32_t var_24 = arg6
uint32_t var_10
sub_407e10(&var_10, arg5)
uint16_t var_8
int16_t var_6
sub_406864(&var_6, 0xea60, var_10, &var_8)
sub_406864(arg3, 0x3c, zx.d(var_6), arg2)
return sub_406864(arg1, 0x3e8, zx.d(var_8), arg4)
