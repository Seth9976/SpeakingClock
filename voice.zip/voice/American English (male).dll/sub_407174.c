// 函数: sub_407174
// 地址: 0x407174
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

int32_t* eax_1 = sub_402628(arg1 + 4)
*eax_1 = arg1 + 4
return &eax_1[1]
