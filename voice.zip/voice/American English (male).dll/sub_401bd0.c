// 函数: sub_401bd0
// 地址: 0x401bd0
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

data_4145ac += 1
data_4145b0 += (*(arg1 - 4) & 0x7ffffffc) - 4
return sub_4021e4(arg1)
