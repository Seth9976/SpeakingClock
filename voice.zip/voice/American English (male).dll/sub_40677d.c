// 函数: sub_40677d
// 地址: 0x40677d
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

BOOL ecx
int32_t edx
return sub_40b638(arg1 - 0x2c, edx, ecx) __tailcall
