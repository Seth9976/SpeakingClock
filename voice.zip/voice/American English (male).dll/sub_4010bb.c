// 函数: sub_4010bb
// 地址: 0x4010bb
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

return ?__abi_AddRef@RuntimeClassNameAttribute@Metadata@Platform@@U$AAGKXZ(arg1 - 8) __tailcall
