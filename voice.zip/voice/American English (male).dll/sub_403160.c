// 函数: sub_403160
// 地址: 0x403160
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

if (arg2.b s<= 0)
    return 

(*(*arg1 - 0x18))(arg2, arg1)
