// 函数: sub_40720c
// 地址: 0x40720c
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

if (*data_41356c != 0)
    return (*data_41356c)()

int32_t eax
eax.b = 0x10
sub_402710(eax)
noreturn
