// 函数: sub_4039cf
// 地址: 0x4039cf
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

return 
