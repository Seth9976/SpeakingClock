// 函数: sub_403b0c
// 地址: 0x403b0c
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

return WideCharToMultiByte(data_4145b8, 0, arg1, arg4, arg3, arg2, nullptr, nullptr)
