// 函数: RegQueryValueExA
// 地址: 0x401228
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

return RegQueryValueExA(hKey, lpValueName, lpReserved, lpType, lpData, lpcbData) __tailcall
