// 函数: sub_403ffc
// 地址: 0x403ffc
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

BSTR bstrString = *arg1

if (bstrString == 0)
    return 

*arg1 = 0
int32_t* var_4_1 = arg1
SysFreeString(bstrString)
