// 函数: sub_40338c
// 地址: 0x40338c
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

if ((*(arg1 + 4) & 6) != 0)
    int32_t ecx_1 = *(arg2 + 4)
    *(arg2 + 4) = 0x4033bc
    *(arg2 + 8)
    sub_4031fc()
    (ecx_1 + 5)()

return 1
