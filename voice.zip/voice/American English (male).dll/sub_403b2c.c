// 函数: sub_403b2c
// 地址: 0x403b2c
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

return MultiByteToWideChar(data_4145b8, 0, arg1, arg4, arg3, arg2)
