// 函数: sub_402e28
// 地址: 0x402e28
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

char* esi = *(arg1 - 0x2c)
int32_t ecx
ecx.b = *esi
__builtin_memcpy(arg2, esi, ecx + 1)
