// 函数: InterlockedIncrement
// 地址: 0x401258
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

return InterlockedIncrement() __tailcall
