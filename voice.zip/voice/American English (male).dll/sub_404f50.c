// 函数: sub_404f50
// 地址: 0x404f50
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

int32_t* edx = *arg1

if (edx == 0)
    return 

*arg1 = 0
int32_t* var_4_1 = arg1
(*(*edx + 8))(edx)
