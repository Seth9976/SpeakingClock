// 函数: sub_403c74
// 地址: 0x403c74
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

uint32_t ecx_1 = 0

if (arg2 != 0)
    ecx_1 = *(arg2 - 4) u>> 1

int32_t* eax
return sub_403b48(eax, arg2, ecx_1) __tailcall
