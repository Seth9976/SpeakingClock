// 函数: sub_40731e
// 地址: 0x40731e
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

int32_t ebx = 0

if (arg1.b != 0x2a)
    while (true)
        if (arg1.b u< 0x30)
            return 
        
        if (arg1.b u> 0x39)
            return 
        
        arg1.b -= 0x30
        ebx = ebx * 0xa + zx.d(arg1.b)
        
        if (arg5 == arg3)
            break
        
        arg1.b = *arg5
        arg5 = &arg5[1]
    
    goto label_4075a3

arg1 = arg4[-3]

if (arg1 s<= arg4[2])
    arg4[-3] += 1
    int32_t ebx_2 = arg4[3]
    *(ebx_2 + (arg1 << 3))
    *(ebx_2 + (arg1 << 3) + 4)

if (arg5 != arg3)
    arg1.b = *arg5
    return 

label_4075a3:
sub_407593(arg6 - arg4[-2], arg4)
*arg4
