// 函数: sub_407230
// 地址: 0x407230
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

sub_4039ec(arg1)
return arg1
