// 函数: sub_407084
// 地址: 0x407084
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

int32_t ecx
sub_4027b0(arg2, arg1, ecx)
return arg1
