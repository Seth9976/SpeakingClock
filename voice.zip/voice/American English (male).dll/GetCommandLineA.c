// 函数: GetCommandLineA
// 地址: 0x4011b8
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

return GetCommandLineA() __tailcall
