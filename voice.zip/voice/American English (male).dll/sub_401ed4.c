// 函数: sub_401ed4
// 地址: 0x401ed4
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

int32_t var_c
sub_401728(arg1 + 4, &var_c)

if (var_c != 0 && sub_401e48(&var_c) != 0)
    return 1

return 0
