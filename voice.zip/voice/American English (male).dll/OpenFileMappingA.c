// 函数: OpenFileMappingA
// 地址: 0x4058d0
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

return OpenFileMappingA(dwDesiredAccess, bInheritHandle, lpName) __tailcall
