// 函数: sub_4075b4
// 地址: 0x4075b4
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

if (arg3 == 0 || arg1 == 0)
    return nullptr

int32_t var_14_1 = sub_40706c(arg1)
int32_t var_18_1 = arg5
*(arg3 + sub_40723c(arg1, arg2, arg3, arg1, arg2, arg4)) = 0
return arg3
