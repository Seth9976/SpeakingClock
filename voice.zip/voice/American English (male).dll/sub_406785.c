// 函数: sub_406785
// 地址: 0x406785
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

int32_t* ecx
int32_t edx
return sub_40b4e0(arg1 - 0x2c, edx, ecx) __tailcall
