// 函数: sub_401b70
// 地址: 0x401b70
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

for (void** i = data_414620; i != &data_414620; i = *i)
    int32_t ecx_1 = i[2]
    
    if (arg1 u>= ecx_1 && arg1 u< ecx_1 + i[3])
        return i

data_4145c0 = 3
return nullptr
