// 函数: Sleep
// 地址: 0x40b158
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

return Sleep(dwMilliseconds) __tailcall
