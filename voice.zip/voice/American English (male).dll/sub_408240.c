// 函数: sub_408240
// 地址: 0x408240
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

int32_t ebx = 0x100 - *(arg3 - 0x104)

if (arg2 s< ebx)
    ebx = arg2

if (ebx != 0)
    sub_4027b0(arg1, arg3 + *(arg3 - 0x104) - 0x100, ebx)

*(arg3 - 0x104) += ebx
return arg3
