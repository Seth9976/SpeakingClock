// 函数: sub_4026b8
// 地址: 0x4026b8
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

data_413004 = arg2
int32_t eax
sub_4039d4(eax)
noreturn
