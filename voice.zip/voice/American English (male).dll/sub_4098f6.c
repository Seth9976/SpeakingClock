// 函数: sub_4098f6
// 地址: 0x4098f6
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

*arg1
