// 函数: sub_403edd
// 地址: 0x403edd
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

return 
