// 函数: sub_405654
// 地址: 0x405654
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

data_413098 = TlsAlloc()
sub_405610()
int32_t result = TlsGetValue(data_413098)
data_41466c = result
return result
