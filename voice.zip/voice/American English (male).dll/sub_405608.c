// 函数: sub_405608
// 地址: 0x405608
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

return 0xc
