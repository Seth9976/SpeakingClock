// 函数: _start
// 地址: 0x4127e4
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

int32_t ebp
int32_t var_4 = ebp
sub_405718(&var_4)
sub_4038fc()
noreturn
