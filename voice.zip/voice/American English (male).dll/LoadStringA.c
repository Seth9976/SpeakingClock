// 函数: LoadStringA
// 地址: 0x405938
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

return LoadStringA(hInstance, uID, lpBuffer, cchBufferMax) __tailcall
