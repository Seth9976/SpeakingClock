// 函数: sub_406775
// 地址: 0x406775
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

int32_t* ecx
int32_t edx
return sub_40b5cc(arg1 - 0x2c, edx, ecx) __tailcall
