// 函数: sub_405cc0
// 地址: 0x405cc0
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

data_41467c -= 1
