// 函数: sub_401ba0
// 地址: 0x401ba0
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

int32_t* ebx = arg2 - 4 + arg1

if (arg2 s>= 0x10)
    *ebx = 0x80000007
    sub_401d74(arg1, arg2 - 4)
    return 

if (arg2 s< 4)
    return 

void* ecx_3 = arg2 | 0x80000002
*arg1 = ecx_3
*ebx = ecx_3
