// 函数: sub_4039e0
// 地址: 0x4039e0
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

data_413004 = __return_addr
int32_t eax
noreturn sub_4039d4(eax) __tailcall
