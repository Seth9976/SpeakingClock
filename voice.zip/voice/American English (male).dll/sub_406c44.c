// 函数: sub_406c44
// 地址: 0x406c44
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

int32_t var_c = arg3
*arg2 = sub_402944(arg1, &var_c)
int32_t result
result.b = var_c == 0
return result
