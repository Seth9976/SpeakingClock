// 函数: sub_40710c
// 地址: 0x40710c
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

while (true)
    char ecx = *arg1
    
    if (arg2 == ecx)
        return 
    
    if (ecx == 0)
        break
    
    arg1 = &arg1[1]
