// 函数: SetEndOfFile
// 地址: 0x4058e8
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

return SetEndOfFile(hFile) __tailcall
