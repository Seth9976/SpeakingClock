// 函数: sub_403485
// 地址: 0x403485
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

return 
