// 函数: sub_40346f
// 地址: 0x40346f
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

return 
