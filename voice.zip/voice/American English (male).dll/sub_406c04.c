// 函数: sub_406c04
// 地址: 0x406c04
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

if (arg2 u> 0x20)
    arg2 = 0

int32_t __saved_esi
uint32_t eax
sub_403adc(arg1, &__saved_esi, sub_406aa4(eax, arg2, 0x10, &__saved_esi))
return arg1
