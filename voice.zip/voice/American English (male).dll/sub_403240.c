// 函数: sub_403240
// 地址: 0x403240
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

int32_t __saved_edx

if (data_413024 u> 1)
    data_414014(0xeedfae3, 0, 2, &__saved_edx)
return arg1
