// 函数: sub_407802
// 地址: 0x407802
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

char result = *arg1

if (result == 0)
    result = 0x30

return result
