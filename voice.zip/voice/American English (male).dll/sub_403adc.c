// 函数: sub_403adc
// 地址: 0x403adc
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

void* eax_1 = sub_403ab0(arg3)

if (arg2 != 0)
    sub_4027b0(arg2, eax_1, arg3)

sub_4039ec(arg1)
*arg1 = eax_1
return arg1
