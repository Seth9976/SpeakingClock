// 函数: sub_4062d0
// 地址: 0x4062d0
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

*arg1 += arg1.b
*arg1 += arg1.b
*arg1 += arg1.b
*arg1 += arg1.b
*arg1 += arg1.b
*arg1 += arg1.b
*arg1 += arg1.b
*arg1 += arg1.b
*arg1 += arg1.b
*arg1 += arg1.b
*arg1 += arg1.b
*arg1 += arg1.b
*arg1 += arg1.b
char temp0 = *arg1
*arg1 += arg1.b
void* entry_ebx
*(entry_ebx + 0x40) = sbb.b(*(entry_ebx + 0x40), arg1:1.b, temp0 + arg1.b u< temp0)
*(arg1 * 2) += arg3
*arg1 += arg1.b
*arg1 ^= arg1.b
breakpoint
