// 函数: sub_40a074
// 地址: 0x40a074
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

if (arg1[3].b != 0)
    sub_402e64(arg1)
