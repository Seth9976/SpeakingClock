// 函数: RegCloseKey
// 地址: 0x401218
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

return RegCloseKey(hKey) __tailcall
