// 函数: CreateFileA
// 地址: 0x4057f0
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

return CreateFileA(lpFileName, dwDesiredAccess, dwShareMode, lpSecurityAttributes, 
    dwCreationDisposition, dwFlagsAndAttributes, hTemplateFile) __tailcall
