// 函数: sub_406f84
// 地址: 0x406f84
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

return sub_403ee0(0x7fffffff, sub_406f34(0x406fb8, arg1) + 1, arg1, arg2)
