// 函数: GetKeyboardType
// 地址: 0x402d18
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

return GetKeyboardType(nTypeFlag) __tailcall
