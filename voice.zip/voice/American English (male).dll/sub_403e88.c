// 函数: sub_403e88
// 地址: 0x403e88
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

return 
