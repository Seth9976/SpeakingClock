// 函数: sub_4046c0
// 地址: 0x4046c0
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

int32_t result
int32_t edx
edx:result = mulu.dp.d(arg3, arg4)
return result
