// 函数: lstrcpynA
// 地址: 0x401200
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

return lstrcpynA(lpString1, lpString2, iMaxLength) __tailcall
