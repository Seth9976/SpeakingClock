// 函数: j_sub_40338c
// 地址: 0x41275b
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

return sub_40338c(arg1, arg2) __tailcall
