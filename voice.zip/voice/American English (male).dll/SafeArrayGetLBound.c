// 函数: SafeArrayGetLBound
// 地址: 0x40bfec
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

return SafeArrayGetLBound(psa, nDim, plLbound) __tailcall
