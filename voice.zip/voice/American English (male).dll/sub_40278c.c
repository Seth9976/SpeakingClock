// 函数: sub_40278c
// 地址: 0x40278c
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

return 
