// 函数: sub_4053d8
// 地址: 0x4053d8
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

int32_t* ebx = arg1

if (ebx == 0)
    return 

int32_t ecx
void buffer

if (ebx[1] s>= 0x10000)
    sub_403be4(ecx, ebx[1])
else
    sub_403adc(arg2, &buffer, LoadStringA(sub_404980(**ebx), ebx[1], &buffer, 0x400))
