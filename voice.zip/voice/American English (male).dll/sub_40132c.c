// 函数: sub_40132c
// 地址: 0x40132c
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

*arg1 = arg1
arg1[1] = arg1
