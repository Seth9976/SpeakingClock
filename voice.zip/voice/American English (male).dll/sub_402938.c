// 函数: sub_402938
// 地址: 0x402938
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

int32_t eax
return sub_4028d8(eax, 0, arg2)
