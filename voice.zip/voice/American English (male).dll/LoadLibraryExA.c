// 函数: LoadLibraryExA
// 地址: 0x4011f0
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

return LoadLibraryExA(lpLibFileName, hFile, dwFlags) __tailcall
