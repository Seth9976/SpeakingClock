// 函数: sub_404ffc
// 地址: 0x404ffc
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

int32_t result
int32_t edx
result, edx = InterlockedDecrement(&arg1[1])

if (result == 0)
    edx.b = 1
    (*(*arg1 - 4))()

return result
