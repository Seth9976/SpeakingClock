// 函数: sub_407d20
// 地址: 0x407d20
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

void var_44
sub_403adc(arg1, &var_44, sub_40770c(0, &var_44, 0, 0xf, 0))
return arg1
