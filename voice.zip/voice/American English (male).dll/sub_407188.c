// 函数: sub_407188
// 地址: 0x407188
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

if (arg1 == 0)
    return 0

void* result = sub_407174(sub_40706c(arg1) + 1)
sub_407084(result, arg1)
return result
