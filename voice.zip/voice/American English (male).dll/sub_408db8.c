// 函数: sub_408db8
// 地址: 0x408db8
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

int32_t var_10c = 0
int32_t __saved_ebp

if (arg2 == 0)
    int32_t* var_118_1 = &__saved_ebp
    sub_408604(sub_408e0d+3, arg2)
else
    int32_t* var_118 = &__saved_ebp
    sub_408604(arg2, arg2)
void var_104
sub_403adc(arg1, &var_104, 0)
return arg1
