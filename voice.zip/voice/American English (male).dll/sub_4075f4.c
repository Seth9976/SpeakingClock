// 函数: sub_4075f4
// 地址: 0x4075f4
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

return sub_407608(arg2, arg3, arg4, arg1)
