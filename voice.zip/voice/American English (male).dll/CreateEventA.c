// 函数: CreateEventA
// 地址: 0x4057e8
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

return CreateEventA(lpEventAttributes, bManualReset, bInitialState, lpName) __tailcall
