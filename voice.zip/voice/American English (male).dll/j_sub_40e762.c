// 函数: j_sub_40e762
// 地址: 0x40e772
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

return sub_40e762() __tailcall
