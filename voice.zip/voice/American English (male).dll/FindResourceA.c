// 函数: FindResourceA
// 地址: 0x405810
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

return FindResourceA(hModule, lpName, lpType) __tailcall
