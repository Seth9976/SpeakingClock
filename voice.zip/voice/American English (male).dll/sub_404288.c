// 函数: sub_404288
// 地址: 0x404288
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

int32_t ecx
ecx.b = *(arg2 + 1)
void* esi = ecx + arg2 + 0xa
int32_t i_1 = *(ecx + arg2 + 6)
int32_t result
int32_t i

do
    result = sub_4042b8(*(esi + 4) + arg1, **esi, 1)
    esi += 8
    i = i_1
    i_1 -= 1
while (i s> 1)
return result
