// 函数: sub_4069cc
// 地址: 0x4069cc
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

int32_t cchCount2 = sub_403c88(arg2)
char* lpString2 = sub_403e88(arg2)
int32_t cchCount1 = sub_403c88(arg1)
return CompareStringA(0x400, 0, sub_403e88(arg1), cchCount1, lpString2, cchCount2) - 2
