// 函数: j_sub_402a34
// 地址: 0x402a2c
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

return sub_402a34(arg1, arg2) __tailcall
