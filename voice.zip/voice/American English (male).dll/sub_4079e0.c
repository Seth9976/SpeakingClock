// 函数: sub_4079e0
// 地址: 0x4079e0
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

int32_t __saved_ebp
int32_t* ebp = &__saved_ebp
int32_t var_8 = 0

if (arg1 == 0)
    return sub_407a0d(ebp, arg2)

return sub_407b2f(ebp, arg2)
