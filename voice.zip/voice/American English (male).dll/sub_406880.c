// 函数: sub_406880
// 地址: 0x406880
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

int32_t edx
edx.b = 1
return sub_4033c4(sub_409fa4(0x406318, edx, arg1))
