// 函数: GetDiskFreeSpaceA
// 地址: 0x405848
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

return GetDiskFreeSpaceA(lpRootPathName, lpSectorsPerCluster, lpBytesPerSector, 
    lpNumberOfFreeClusters, lpTotalNumberOfClusters) __tailcall
