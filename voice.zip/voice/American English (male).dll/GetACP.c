// 函数: GetACP
// 地址: 0x405828
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

return GetACP() __tailcall
