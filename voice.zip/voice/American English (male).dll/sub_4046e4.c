// 函数: sub_4046e4
// 地址: 0x4046e4
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

if (arg1 != 0)
    *(arg1 - 4)
