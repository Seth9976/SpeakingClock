// 函数: lstrlenA
// 地址: 0x401208
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

return lstrlenA(lpString) __tailcall
