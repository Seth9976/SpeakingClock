// 函数: sub_403126
// 地址: 0x403126
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

int32_t* eax = *(arg1 + 0xc)

if (eax != 0)
    int32_t edx
    edx.b = 0x81
    (*(*eax - 4))(eax)
    sub_403148(eax)

sub_4033ec()
return 1
