// 函数: sub_402f14
// 地址: 0x402f14
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

int32_t* ebx = arg1
int32_t* i = arg1

do
    void* esi = *i
    void* edx_1 = *(esi - 0x40)
    i = *(esi - 0x24)
    
    if (edx_1 != 0)
        sub_40434c(arg1, edx_1)
        arg1 = ebx
while (i != 0)
