// 函数: sub_407966
// 地址: 0x407966
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

void* esi = *(arg1 - 0xc)
int32_t edi

if (esi != 0)
    __builtin_memcpy(edi, esi, *(esi - 4))
