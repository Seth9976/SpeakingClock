// 函数: sub_4055fc
// 地址: 0x4055fc
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

return LocalAlloc(LMEM_ZEROINIT, arg1)
