// 函数: sub_408d8c
// 地址: 0x408d8c
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

*arg1
