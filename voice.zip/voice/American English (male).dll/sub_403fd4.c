// 函数: sub_403fd4
// 地址: 0x403fd4
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

if (arg1 != 0 && SysAllocStringLen(nullptr, arg1) == 0)
    arg1.b = 1
    noreturn sub_402710(arg1) __tailcall
