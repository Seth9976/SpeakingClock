// 函数: sub_403150
// 地址: 0x403150
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

(*(*arg1 - 0x1c))()
return arg1
