// 函数: RegOpenKeyExA
// 地址: 0x401220
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

return RegOpenKeyExA(hKey, lpSubKey, ulOptions, samDesired, phkResult) __tailcall
