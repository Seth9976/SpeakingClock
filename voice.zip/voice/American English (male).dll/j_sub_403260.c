// 函数: j_sub_403260
// 地址: 0x404eaf
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

return sub_403260() __tailcall
