// 函数: sub_409e17
// 地址: 0x409e17
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

*arg1 += arg1.b
*arg1 += arg1.b
*arg4 += arg3:1.b
*arg1 += arg1.b
*(arg3 - 0x4433c) += arg1.b
undefined
