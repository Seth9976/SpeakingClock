// 函数: LoadResource
// 地址: 0x4058b8
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

return LoadResource(hModule, hResInfo) __tailcall
