// 函数: sub_4078a8
// 地址: 0x4078a8
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

void* ebp
char* edi
sub_40780b(ebp, edi)
return sub_4078ad(ebp, edi) __tailcall
