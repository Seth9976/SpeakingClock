// 函数: sub_4046e3
// 地址: 0x4046e3
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

return 
