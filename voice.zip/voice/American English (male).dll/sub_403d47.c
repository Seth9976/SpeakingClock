// 函数: sub_403d47
// 地址: 0x403d47
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

return 
