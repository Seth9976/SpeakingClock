// 函数: sub_402790
// 地址: 0x402790
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

int32_t result = *(sub_4056cc() + 4)
*(sub_4056cc() + 4) = 0
return result
