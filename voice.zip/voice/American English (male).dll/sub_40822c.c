// 函数: sub_40822c
// 地址: 0x40822c
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

SYSTEMTIME systemTime
GetLocalTime(&systemTime)
int32_t result
result.w = systemTime.wYear
return result
