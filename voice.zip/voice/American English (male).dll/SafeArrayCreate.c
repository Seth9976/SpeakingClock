// 函数: SafeArrayCreate
// 地址: 0x40bfe4
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

return SafeArrayCreate(vt, cDims, rgsabound) __tailcall
