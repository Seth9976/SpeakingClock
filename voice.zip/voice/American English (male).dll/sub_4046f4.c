// 函数: sub_4046f4
// 地址: 0x4046f4
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

int32_t* eax
char* ecx
void** edx
return sub_4045c4(ecx, edx, eax, arg1)
