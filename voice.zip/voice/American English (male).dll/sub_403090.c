// 函数: sub_403090
// 地址: 0x403090
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

int32_t* var_4 = arg1
sub_403060(*arg1, arg2.w)
bool z

if (not(z))
    jump(arg2)

if (data_414028 != 0)
    data_414028()

noreturn sub_4039e0() __tailcall
