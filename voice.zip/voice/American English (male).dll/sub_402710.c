// 函数: sub_402710
// 地址: 0x402710
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

noreturn sub_4026c4(arg1 & 0x7f, __return_addr) __tailcall
