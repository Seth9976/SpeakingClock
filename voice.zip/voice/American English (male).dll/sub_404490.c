// 函数: sub_404490
// 地址: 0x404490
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

if (data_413014 != 0)
    return data_413014()

int32_t eax
eax.b = 0x10
sub_402710(eax)
noreturn
