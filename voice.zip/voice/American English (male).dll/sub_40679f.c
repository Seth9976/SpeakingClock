// 函数: sub_40679f
// 地址: 0x40679f
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

return ?__abi_AddRef@RuntimeClassNameAttribute@Metadata@Platform@@U$AAGKXZ(arg1 - 0x2c) __tailcall
