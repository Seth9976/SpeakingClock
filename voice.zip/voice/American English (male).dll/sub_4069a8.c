// 函数: sub_4069a8
// 地址: 0x4069a8
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

if (arg1 == arg2)
    arg1.b = 1
else if (arg1 != 0)
    if (arg2 == 0 || *(arg1 - 4) != *(arg2 - 4))
        return 0
    
    if (sub_406954(arg1, arg2) != 0)
        return 0
    
    arg1.b = 1

return arg1
