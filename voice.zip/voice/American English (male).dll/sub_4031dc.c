// 函数: sub_4031dc
// 地址: 0x4031dc
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

if (arg1 != 0)
    *(arg1 + 1)
    *arg1 != 0xe9 && *arg1 == 0xeb
