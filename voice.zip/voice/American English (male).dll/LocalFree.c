// 函数: LocalFree
// 地址: 0x4055d4
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

return LocalFree(hMem) __tailcall
