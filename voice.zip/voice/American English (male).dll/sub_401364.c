// 函数: sub_401364
// 地址: 0x401364
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

int32_t* edx_1 = arg1[1]
void* ecx = *arg1
*edx_1 = ecx
*(ecx + 4) = edx_1
*arg1 = data_4145e0
data_4145e0 = arg1
