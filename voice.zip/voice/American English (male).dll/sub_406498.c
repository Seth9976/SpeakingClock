// 函数: sub_406498
// 地址: 0x406498
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

*arg1 += arg1.b
*arg1 += arg1.b
*arg1 += arg1.b
*arg1 += arg1.b
*arg1 += arg1.b
*arg1 += arg1.b
*arg1 += arg1.b
*arg1 += arg1.b
*arg1 += arg1.b
*arg1 += arg1.b
*arg1 += arg1.b
*arg1 += arg1.b
*arg1 += arg1.b
char temp0 = *arg1
*arg1 += arg1.b

if (temp0 == neg.b(arg1.b) || arg3 == 1)
    *(&arg1[1] * 2) += (arg3 - 1).b
    arg1[1] += (&arg1[1]).b
    int32_t var_4 = arg4
    arg1[1] ^= (&arg1[1]).b
    breakpoint

int16_t entry_ebx
arg1[arg5 + 0x30c80041] += entry_ebx:1.b
void* eax_2
eax_2:1.b = (&arg1[2]):1.b + (arg3 - 1).b
*eax_2 ^= eax_2.b
*eax_2 <<= 1
void* eax_3
eax_3:1.b = (eax_2 + 1):1.b + (eax_2 + 1).b
*eax_3 ^= eax_3.b
*(arg5 + arg4 + 0x40) += eax_3:1.b
char temp1 = *(eax_3 + 0x1000402e)
*(eax_3 + 0x1000402e) += eax_3:1.b
bool c = temp1 + eax_3:1.b u< temp1
bool p = unimplemented  {inc ecx}
bool a = unimplemented  {inc ecx}

if (not(c))
    *eax_3 += eax_3.b
    *eax_3 += eax_3.b
else if (not(c))
    *(arg6 + 0x6e)
    void* ebp_1 = *(arg6 + 0x6e) * 0x6c696146
    bool c_1 = unimplemented  {imul ebp, dword [edi+0x6e], 0x6c696146}
    bool o = unimplemented  {imul ebp, dword [edi+0x6e], 0x6c696146}
    bool d
    int32_t var_4_1 = (o ? 1 : 0) << 0xb | (d ? 1 : 0) << 0xa | (arg3 s< 0 ? 1 : 0) << 7
        | (arg3 == 0 ? 1 : 0) << 6 | (a ? 1 : 0) << 4 | (p ? 1 : 0) << 2 | (c_1 ? 1 : 0)
    *(eax_3 + 1) += (eax_3 + 1).b
    *(eax_3 + 1) += (eax_3 + 1).b
    *(eax_3 + 1) += (eax_3 + 1).b
    *(eax_3 + 1) += (eax_3 + 1).b
    *(eax_3 + 1) += (eax_3 + 1).b
    *(eax_3 + 1) += (eax_3 + 1).b
    *(eax_3 + 1) += (eax_3 + 1).b
    *(eax_3 + 1) += (eax_3 + 1).b
    *(eax_3 + 1) += (eax_3 + 1).b
    *(eax_3 + 1) += (eax_3 + 1).b
    *(eax_3 + 1) += (eax_3 + 1).b
    *(eax_3 + 1) += (eax_3 + 1).b
    *(eax_3 + 1) += (eax_3 + 1).b
    *(eax_3 + 1) += (eax_3 + 1).b
    *(ebp_1 + 0xc0040) += entry_ebx.b
    *(eax_3 + 1) += (eax_3 + 1).b
    void* var_8 = ebp_1
    *(eax_3 + 1) ^= (eax_3 + 1).b
    breakpoint

*eax_3 += eax_3.b
*eax_3 += eax_3.b
*eax_3 += eax_3.b
*eax_3 += eax_3.b
*eax_3 += eax_3.b
*eax_3 += eax_3.b
*eax_3 += eax_3.b
*eax_3 += eax_3.b
*eax_3 += eax_3.b
*eax_3 += eax_3.b
*((eax_3 + 1) * 2) += (arg3 - 1).b + 1
*(eax_3 + 1) += (eax_3 + 1).b
int32_t var_4_2 = arg4 + 1
*(eax_3 + 1) ^= (eax_3 + 1).b
breakpoint
