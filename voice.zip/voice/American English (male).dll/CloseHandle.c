// 函数: CloseHandle
// 地址: 0x4057d8
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

return CloseHandle(hObject) __tailcall
