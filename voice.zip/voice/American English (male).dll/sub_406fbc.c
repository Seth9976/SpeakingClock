// 函数: sub_406fbc
// 地址: 0x406fbc
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

PSTR filePart
uint8_t buffer[0x104]
sub_403adc(arg2, &buffer, GetFullPathNameA(sub_403e88(arg1), 0x104, &buffer, &filePart))
return arg2
