// 函数: SetFilePointer
// 地址: 0x4058f8
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

return SetFilePointer(hFile, lDistanceToMove, lpDistanceToMoveHigh, dwMoveMethod) __tailcall
