// 函数: GetModuleHandleA
// 地址: 0x405878
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

return GetModuleHandleA(lpModuleName) __tailcall
