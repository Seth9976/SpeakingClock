// 函数: sub_406e70
// 地址: 0x406e70
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

return CreateFileA(sub_403e88(arg1), 0xc0000000, FILE_SHARE_NONE, nullptr, CREATE_ALWAYS, 
    FILE_ATTRIBUTE_NORMAL, nullptr)
