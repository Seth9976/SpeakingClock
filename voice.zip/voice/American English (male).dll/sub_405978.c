// 函数: sub_405978
// 地址: 0x405978
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

data_414674 -= 1
