// 函数: sub_406a3c
// 地址: 0x406a3c
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

int32_t result
result.b = sub_406a04(arg1, arg2) == 0
return result
