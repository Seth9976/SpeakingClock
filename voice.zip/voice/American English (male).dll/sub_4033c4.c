// 函数: sub_4033c4
// 地址: 0x4033c4
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

if (arg1 == 0)
    sub_4039e0()
    noreturn

void* const __return_addr_1 = __return_addr
void arg_4
__return_addr = &arg_4
int32_t var_14 = arg1
void* const __return_addr_3 = __return_addr_1
void* const* var_1c = &__return_addr_3
int32_t var_20 = 7
int32_t var_24 = 1
int32_t var_28 = 0xeedfade
void* const __return_addr_2 = __return_addr_1
jump(data_414014)
