// 函数: sub_403c50
// 地址: 0x403c50
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

int32_t ecx
ecx.b = *arg2
void** eax
return sub_403adc(eax, &arg2[1], ecx) __tailcall
