// 函数: sub_404f68
// 地址: 0x404f68
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

if (arg2 == 0)
    int32_t* ecx_1 = *arg1
    *arg1 = arg2
    
    if (ecx_1 != 0)
        (*(*ecx_1 + 8))(ecx_1)
    
    return 

(*(*arg2 + 4))(arg2)
int32_t* ecx = *arg1
*arg1 = arg2

if (ecx == 0)
    return 

(*(*ecx + 8))(ecx)
