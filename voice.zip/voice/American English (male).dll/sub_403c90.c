// 函数: sub_403c90
// 地址: 0x403c90
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

if (arg2 == 0)
    return 

void* ecx = *arg1

if (ecx == 0)
    return sub_403a40(arg1, arg2) __tailcall

int32_t edi = *(ecx - 4)
char* edx_2 = *(arg2 - 4) + edi
void* eax_1
int32_t ecx_2

if (arg2 == ecx)
    sub_403f68(arg1, edx_2)
    eax_1 = *arg1
    ecx_2 = edi
else
    sub_403f68(arg1, edx_2)
    eax_1 = arg2
    ecx_2 = *(arg2 - 4)

sub_4027b0(eax_1, *arg1 + edi, ecx_2)
