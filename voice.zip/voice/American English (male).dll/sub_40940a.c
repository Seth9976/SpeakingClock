// 函数: sub_40940a
// 地址: 0x40940a
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

int32_t result
result.b = *(arg1 - 9)
*arg1
return result
