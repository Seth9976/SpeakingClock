// 函数: sub_407ec4
// 地址: 0x407ec4
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

double* ebx = arg3
arg3.w = arg4
double var_c

if (sub_407e54(arg1, arg2, ebx, &var_c, arg3.w) == 0)
    sub_406880(data_413488)

return fconvert.t(var_c)
