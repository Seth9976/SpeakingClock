// 函数: GetStringTypeExA
// 地址: 0x405890
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

return GetStringTypeExA(Locale, dwInfoType, lpSrcStr, cchSrc, lpCharType) __tailcall
