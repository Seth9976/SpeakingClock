// 函数: sub_4059b0
// 地址: 0x4059b0
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

data_414678 -= 1
