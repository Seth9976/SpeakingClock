// 函数: sub_40908c
// 地址: 0x40908c
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

int32_t ebx = arg1

if (data_414744 != 0x12)
    *(arg2 - 4) -= 1
else
    if (ebx s<= 0x63)
        uint32_t ecx_1 = zx.d(sub_40822c())
        int32_t eax_3
        int32_t edx_1
        edx_1:eax_3 = sx.q(*(arg2 - 4))
        ebx += divs.dp.d(sx.q(ecx_1 + (eax_3 ^ edx_1) - edx_1), 0x64) * 0x64
    
    if (*(arg2 - 4) s> 0)
        *(arg2 - 4) = neg.d(*(arg2 - 4))

return *(arg2 - 4) + ebx
