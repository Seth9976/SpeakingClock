// 函数: sub_4046b8
// 地址: 0x4046b8
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

int32_t eax
eax.b = 0x11
noreturn sub_402710(eax) __tailcall
