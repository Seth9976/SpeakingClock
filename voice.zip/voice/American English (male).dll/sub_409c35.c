// 函数: sub_409c35
// 地址: 0x409c35
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

*arg1
