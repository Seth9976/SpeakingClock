// 函数: MapViewOfFile
// 地址: 0x4058c8
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

return MapViewOfFile(hFileMappingObject, dwDesiredAccess, dwFileOffsetHigh, dwFileOffsetLow, 
    dwNumberOfBytesToMap) __tailcall
