// 函数: CompareStringA
// 地址: 0x4057e0
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

return CompareStringA(Locale, dwCmpFlags, lpString1, cchCount1, lpString2, cchCount2) __tailcall
