// 函数: sub_403a84
// 地址: 0x403a84
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

if (arg2 != 0 && *(arg2 - 8) s> 0xffffffff)
    *(arg2 - 8) += 1

void* temp0 = *arg1
*arg1 = arg2

if (temp0 == 0 || *(temp0 - 8) s< 1)
    return 

int32_t temp3_1 = *(temp0 - 8)
*(temp0 - 8) -= 1

if (temp3_1 == 1)
    sub_402648(temp0 - 8)
