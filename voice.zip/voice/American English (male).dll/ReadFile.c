// 函数: ReadFile
// 地址: 0x4058d8
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

return ReadFile(hFile, lpBuffer, nNumberOfBytesToRead, lpNumberOfBytesRead, lpOverlapped) __tailcall
