// 函数: sub_404144
// 地址: 0x404144
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

return 
