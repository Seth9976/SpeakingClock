// 函数: sub_409c83
// 地址: 0x409c83
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

*arg3 += 1
*arg1 += arg1.b
*arg4 += arg1:1.b
*arg1 += arg1.b
return sub_409c8c(arg1) __tailcall
