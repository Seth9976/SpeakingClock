// 函数: sub_401334
// 地址: 0x401334
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

int32_t* result = sub_4012dc()

if (result == 0)
    return 0

result[2] = *arg2
result[3] = arg2[1]
int32_t* edx_2 = *arg1
*result = edx_2
result[1] = arg1
edx_2[1] = result
*arg1 = result
result.b = 1
return result
