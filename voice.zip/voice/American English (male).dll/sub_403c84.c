// 函数: sub_403c84
// 地址: 0x403c84
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

return 
