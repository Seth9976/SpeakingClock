// 函数: sub_403224
// 地址: 0x403224
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

int32_t __saved_edx

if (data_413024 u> 1)
    data_414014(0xeedfae2, 0, 1, &__saved_edx)
