// 函数: sub_4039d4
// 地址: 0x4039d4
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

data_413000 = arg1
sub_4038fc()
noreturn
