// 函数: sub_404980
// 地址: 0x404980
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

void** edx = data_413030

if (edx == 0)
    return 

while (true)
    if (arg1 == edx[1] || arg1 == edx[2] || arg1 == edx[3])
        sub_404938(edx)
        return 
    
    edx = *edx
    
    if (edx == 0)
        break
    
    continue
