// 函数: FindClose
// 地址: 0x4011a0
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

return FindClose(hFindFile) __tailcall
