// 函数: sub_4046ec
// 地址: 0x4046ec
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

void* eax
return sub_4046e4(eax) - 1
