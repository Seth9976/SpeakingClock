// 函数: sub_409900
// 地址: 0x409900
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

int32_t ebx = 1

while (true)
    if (*((ebx << 2) + &data_41474c) == 0)
        int32_t ecx
        sub_403be4(ecx, arg1)
        return 1
    
    if (ebx == 7)
        break
    
    ebx += 1

return 0
