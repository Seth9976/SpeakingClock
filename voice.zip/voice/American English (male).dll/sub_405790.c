// 函数: sub_405790
// 地址: 0x405790
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

data_414668 -= 1
