// 函数: SetEvent
// 地址: 0x4058f0
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

return SetEvent(hEvent) __tailcall
