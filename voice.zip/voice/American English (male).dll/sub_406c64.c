// 函数: sub_406c64
// 地址: 0x406c64
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

if (sub_4046e4(data_414788) == 0)
    int32_t var_4_1 = 1
    sub_4048a0()
    sub_403a40(data_414788, "True")

int32_t result = sub_4046e4(data_41478c)

if (result != 0)
    return result

int32_t var_4_2 = 1
sub_4048a0()
return sub_403a40(data_41478c, sub_406ce7+5)
