// 函数: GetStdHandle
// 地址: 0x405888
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

return GetStdHandle(nStdHandle) __tailcall
