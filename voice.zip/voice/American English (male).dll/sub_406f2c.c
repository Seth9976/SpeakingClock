// 函数: sub_406f2c
// 地址: 0x406f2c
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

return CloseHandle(arg1)
