// 函数: sub_4052de
// 地址: 0x4052de
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

return 
