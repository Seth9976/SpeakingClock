// 函数: sub_40271c
// 地址: 0x40271c
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

if (*(sub_4056cc() + 4) != 0)
    noreturn sub_402710(0) __tailcall

return arg1
