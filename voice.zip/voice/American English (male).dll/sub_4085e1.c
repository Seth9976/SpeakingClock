// 函数: sub_4085e1
// 地址: 0x4085e1
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

*arg1
