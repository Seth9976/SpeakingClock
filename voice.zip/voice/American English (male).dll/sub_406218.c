// 函数: sub_406218
// 地址: 0x406218
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

*arg1 += arg1.b
*arg1 += arg1.b
*arg1 += arg1.b
*arg1 += arg1.b
*arg1 += arg1.b
*arg1 += arg1.b
*arg1 += arg1.b
*arg1 += arg1.b
*arg1 += arg1.b
*arg1 += arg1.b
*arg1 += arg1.b
*arg1 += arg1.b
*arg1 += arg1.b
char temp1 = *arg1
*arg1 += arg1.b
char* var_4 = arg1
int32_t var_8 = arg3
int32_t var_c = arg2
void* entry_ebx
void* var_10 = entry_ebx
int32_t* var_14 = &var_10
void* var_18 = arg4
uint16_t* var_1c = arg5
uint8_t* var_20 = arg6
int32_t* esp = &var_20
__bound_gprv_mema32(arg1, *arg1)
*arg1 = adc.b(*arg1, arg1.b, temp1 + arg1.b u< temp1)
*arg1 += arg1.b
*(arg4 + 0x40) ^= entry_ebx.b
void* eax_9
void* eax_22
void* ebp

while (true)
    *(arg1 + arg5 + 0x30c80040) += entry_ebx:1.b
    void* eax_1
    eax_1:1.b = (&arg1[1]):1.b + arg3.b
    *eax_1 ^= eax_1.b
    *eax_1 <<= 1
    void* eax_2
    eax_2:1.b = (eax_1 + 1):1.b + (eax_1 + 1).b
    *eax_2 ^= eax_2.b
    void* eax_4 = eax_2
    *(eax_4 + 0x40) += arg2:1.b
    char temp2_1 = *(eax_4 + 0xf00402e)
    *(eax_4 + 0xf00402e) += eax_4:1.b
    bool c_1 = temp2_1 + eax_4:1.b u< temp2_1
    ebp = arg4 + 1
    int32_t temp3_1 = arg3
    arg3 -= 1
    int32_t eflags
    arg5 = __outsb(arg2.w, *arg5, arg5, eflags)
    
    if (temp3_1 == 1 || c_1)
        if (c_1)
            char* eax_10 = eax_4
            *(entry_ebx + 0x40) = sbb.b(*(entry_ebx + 0x40), eax_10:1.b, c_1)
            *eax_10 += eax_10.b
            *eax_10 += eax_10.b
            *eax_10 += eax_10.b
            *eax_10 += eax_10.b
            *eax_10 += eax_10.b
            *eax_10 += eax_10.b
            *eax_10 += eax_10.b
            *eax_10 += eax_10.b
            *eax_10 += eax_10.b
            *eax_10 += eax_10.b
            *eax_10 += eax_10.b
            *eax_10 += eax_10.b
            *eax_10 += eax_10.b
            *eax_10 += eax_10.b
            *eax_10 += entry_ebx.b
            int32_t eflags_2
            int16_t temp0_4
            temp0_4, eflags_2 = __arpl_memw_gpr16(*eax_10, eax_10.w)
            *eax_10 = temp0_4
            eax_10.b = eax_10.b
            *eax_10 += eax_10.b
            *(esp - 4) = ebp
            *eax_10 ^= eax_10.b
            breakpoint
        
        *eax_4 += eax_4.b
        *eax_4 += eax_4.b
        *eax_4 += eax_4.b
        *eax_4 += eax_4.b
        *eax_4 += eax_4.b
        *(entry_ebx + 0x40) += arg2:1.b
    else
        uint8_t temp0_1
        temp0_1, arg6 = __insb(arg6, arg2.w, eflags)
        *arg6 = temp0_1
        *(eax_4 + (arg2 << 1) + 0x6f)
        void** esp_1 = *(eax_4 + (arg2 << 1) + 0x6f) * 0x65746e69
        bool c_2 = unimplemented  {imul esp, dword [eax+edx*2+0x6f], 0x65746e69}
        
        if (c_2)
            *eax_4 += eax_4.b
            *eax_4 += eax_4.b
            *eax_4 += eax_4.b
            *(eax_4 + 0x62) += eax_4:1.b
            *(eax_4 + 1) += arg2.b
            *(eax_4 + 1) += (eax_4 + 1).b
            *(eax_4 + 1) += arg2:1.b
            arg4 = *esp_1
            esp = &esp_1[1]
            arg1 = eax_4 + 2
            continue
        else
            __bound_gprv_mema32(eax_4, *eax_4)
            *eax_4 += eax_4.b
            *eax_4 += eax_4.b
            *eax_4 += eax_4.b
            *eax_4 += eax_4.b
            *eax_4 += eax_4.b
            *eax_4 += eax_4.b
            *eax_4 += eax_4.b
            *eax_4 += eax_4.b
            *eax_4 += eax_4.b
            *eax_4 += eax_4.b
            *eax_4 += eax_4.b
            *eax_4 += eax_4.b
            *eax_4 += eax_4.b
            *eax_4 += eax_4.b
            *eax_4 += eax_4.b
            eax_4.b += arg3.b
            esp = *0xc004062
            *(eax_4 + 1 + arg5 + 0x30c80040) += entry_ebx:1.b
            void* eax_6
            eax_6:1.b = (eax_4 + 2):1.b + arg3.b
            *eax_6 ^= eax_6.b
            *eax_6 <<= 1
            void* eax_7
            eax_7:1.b = (eax_6 + 1):1.b + (eax_6 + 1).b
            *eax_7 ^= eax_7.b
            eax_9 = eax_7
            
            while (true)
                *(arg5 + ebp + 0x40) += eax_9:1.b
                char temp6_1 = *(eax_9 + 0xc00402e)
                *(eax_9 + 0xc00402e) += eax_9:1.b
                bool c_3 = temp6_1 + eax_9:1.b u< temp6_1
                ebp += 1
                int32_t temp7_1 = arg3
                arg3 -= 1
                arg5 = __outsb(arg2.w, *arg5, arg5, eflags)
                
                if (temp7_1 != 1 && not(c_3))
                    uint8_t* edi
                    uint8_t temp0_2
                    temp0_2, edi = __insb(arg6, arg2.w, eflags)
                    *edi = temp0_2
                    *eax_9 += entry_ebx.b
                    int32_t eflags_1
                    int16_t temp0_3
                    temp0_3, eflags_1 = __arpl_memw_gpr16(*eax_9, eax_9.w)
                    *eax_9 = temp0_3
                    noreturn sub_4062d0(eax_9, arg2, arg3.b) __tailcall
                
                if (c_3)
                    *eax_9 += eax_9.b
                    *eax_9 += eax_9.b
                    *eax_9 += eax_9.b
                    *eax_9 += eax_9.b
                    *eax_9 += eax_9.b
                    *eax_9 += eax_9.b
                    *eax_9 += eax_9.b
                    *eax_9 += eax_9.b
                    *eax_9 += eax_9.b
                    *eax_9 += eax_9.b
                    char temp0_7
                    char temp1_2
                    temp0_7, temp1_2, eflags = __aam_immb(0x63, eax_9.b)
                    eax_9.b = temp0_7
                    eax_9:1.b = temp1_2
                    eax_9 += 1
                    *eax_9 += arg2.b
                    goto label_4063ad
                
                if (not(c_3))
                    break
                
                eax_9 += 1
            
            *(entry_ebx + 0x40) = *(entry_ebx + 0x40)
            *eax_9 += eax_9.b
            *eax_9 += eax_9.b
            *eax_9 += eax_9.b
            *eax_9 += eax_9.b
            *eax_9 += eax_9.b
            *eax_9 += eax_9.b
            *eax_9 += eax_9.b
            *eax_9 += eax_9.b
            *eax_9 += eax_9.b
            *eax_9 += eax_9.b
            *eax_9 += eax_9.b
            *eax_9 += eax_9.b
            *eax_9 += eax_9.b
            char temp13_1 = *eax_9
            *eax_9 += eax_9.b
            
            if (temp13_1 == neg.b(eax_9.b))
            label_4063ad:
                *eax_9 += eax_9.b
                *(eax_9 + 0x5e) += eax_9.b
                break
            
            eax_4 = eax_9 + 1
    
    *eax_4 += arg2.b
    *eax_4 += eax_4.b
    *(eax_4 + 0x5e) += eax_4.b
    *(eax_4 + 1 + arg5 + 0x30c80040) += entry_ebx:1.b
    void* eax_12
    eax_12:1.b = (eax_4 + 2):1.b + arg3.b
    *eax_12 ^= eax_12.b
    *eax_12 <<= 1
    void* eax_13
    eax_13:1.b = (eax_12 + 1):1.b + (eax_12 + 1).b
    *eax_13 ^= eax_13.b
    void* eax_15 = eax_13
    *(arg5 + ebp + 0x40) += eax_15:1.b
    char temp5_1 = *(eax_15 + 0x1000402e)
    *(eax_15 + 0x1000402e) += eax_15:1.b
    ebp += 1
    arg3 += 1
    int32_t eflags_3
    int16_t temp0_5
    temp0_5, eflags_3 = __arpl_memw_gpr16(*(entry_ebx + 0x65), esp.w)
    *(entry_ebx + 0x65) = temp0_5
    
    if (temp5_1 + eax_15:1.b u< temp5_1)
        *(esp - 4) = arg5
        ebp = *(arg6 + 0x6c) * 0x6f697461
        __outsb(arg2.w, *arg5, arg5, eflags_3)
        int32_t eflags_4
        char temp0_6
        char temp1_1
        temp0_6, temp1_1, eflags_4 = __aam_immb(0x63, eax_15.b)
        void* eax_16
        eax_16.b = temp0_6
        eax_16:1.b = temp1_1
        *(eax_16 + 1) += (eax_16 + 1).b
        *(eax_16 + 1) += (eax_16 + 1).b
        *(eax_16 + 1) += (eax_16 + 1).b
        *(eax_16 + 1) += (eax_16 + 1).b
        *(eax_16 + 1) += (eax_16 + 1).b
        *(eax_16 + 1) += (eax_16 + 1).b
        *(eax_16 + 1) += (eax_16 + 1).b
        *(eax_16 + 1) += (eax_16 + 1).b
        *(eax_16 + 1) += (eax_16 + 1).b
        *(eax_16 + 1) += (eax_16 + 1).b
        *(eax_16 + 1) += (eax_16 + 1).b
        *(eax_16 + 1) += (eax_16 + 1).b
        *(eax_16 + 1) += (eax_16 + 1).b
        *(eax_16 + 1) += (eax_16 + 1).b
        char temp10_1 = (eax_16 + 1):1.b
        void* eax_17
        eax_17:1.b = (eax_16 + 1):1.b + arg2.b
        int16_t temp0_8
        temp0_8, eflags = __arpl_memw_gpr16(*eax_17, eax_17.w)
        *eax_17 = temp0_8
        *eax_17 = adc.b(*eax_17, eax_17.b, temp10_1 + arg2.b u< temp10_1)
        *eax_17 += eax_17.b
        eax_9 = eax_17 + 1
        arg5 = *(esp - 4)
        break
    
    while (true)
        *eax_15 += eax_15.b
        *eax_15 += eax_15.b
        *eax_15 += eax_15.b
        *eax_15 += eax_15.b
        *eax_15 += eax_15.b
        *eax_15 += eax_15.b
        *eax_15 += eax_15.b
        *eax_15 += eax_15.b
        *esp += arg3:1.b
        *(eax_15 + 1) += arg2.b
        *(eax_15 + 1) += (eax_15 + 1).b
        *(eax_15 + 0x5f) += (eax_15 + 1).b
        *(eax_15 + 2 + arg5 + 0x30c80040) += entry_ebx:1.b
        void* eax_25
        eax_25:1.b = (eax_15 + 3):1.b + arg3.b
        *eax_25 ^= eax_25.b
        *eax_25 <<= 1
        void* eax_26
        eax_26:1.b = (eax_25 + 1):1.b + (eax_25 + 1).b
        *eax_26 ^= eax_26.b
        eax_22 = eax_26
        *(arg5 + ebp + 0x40) += eax_22:1.b
        char temp8_1 = *(eax_22 + 0xe00402e)
        *(eax_22 + 0xe00402e) += eax_22:1.b
        bool c_7 = temp8_1 + eax_22:1.b u< temp8_1
        void* temp9_1 = ebp
        ebp += 1
        bool z_4 = temp9_1 == 0xffffffff
        *(esp - 4) = entry_ebx
        esp -= 4
        
        if (z_4)
            break
        
        int16_t temp0_10
        temp0_10, eflags = __arpl_memw_gpr16(*(entry_ebx + 0x4f), ebp.w)
        *(entry_ebx + 0x4f) = temp0_10
        void* eax_34
        
        if (z_4 || c_7)
        label_40649b:
            *eax_22 += eax_22.b
            *eax_22 += eax_22.b
            *eax_22 += eax_22.b
            *eax_22 += eax_22.b
            *eax_22 += eax_22.b
            *eax_22 += eax_22.b
            *eax_22 += eax_22.b
            *eax_22 += eax_22.b
            *eax_22 += eax_22.b
            *eax_22 += eax_22.b
            *eax_22 += eax_22.b
            *eax_22 += eax_22.b
            eax_22.b += eax_22:1.b
            eax_34 = eax_22 + 1
        else
            if (not(c_7))
                uint8_t temp0_11
                temp0_11, arg6 = __insb(arg6, arg2.w, eflags)
                *arg6 = temp0_11
                arg5 = __outsd(arg2.w, *arg5, arg5, eflags)
                
                if (not(z_4) && not(c_7))
                    eax_22 += 1
                label_4063cf:
                    char temp11_1 = *(eax_22 + 0xa00402e)
                    *(eax_22 + 0xa00402e) += eax_22:1.b
                    bool c_6 = temp11_1 + eax_22:1.b u< temp11_1
                    void* temp12_1 = ebp
                    ebp += 1
                    *(esp - 4) = eax_22
                    esp -= 4
                    
                    if (c_6)
                        *eax_22 += eax_22.b
                    else if (temp12_1 != 0xffffffff && not(c_6))
                        uint8_t temp0_9
                        temp0_9, arg6 = __insb(arg6, arg2.w, eflags)
                        *arg6 = temp0_9
                        eax_22.b -= 0x64
                        eax_15 = eax_22 + 1
                        *eax_15 += eax_15.b
                        *eax_15 += eax_15.b
                        *eax_15 += eax_15.b
                        *eax_15 += eax_15.b
                        *eax_15 += eax_15.b
                        *eax_15 += eax_15.b
                        continue
                else
                    *(eax_22 * 3) = eax_22:1.b
                    *eax_22 += eax_22.b
                    *eax_22 += eax_22.b
                
                *eax_22 += eax_22.b
                *eax_22 += eax_22.b
                *eax_22 += eax_22.b
                *eax_22 += eax_22.b
                *eax_22 += eax_22.b
                *eax_22 += eax_22.b
                *eax_22 += eax_22.b
                *eax_22 += eax_22.b
                *eax_22 += eax_22.b
                *eax_22 += eax_22.b
                *eax_22 += eax_22.b
                char temp17_1 = *eax_22
                *eax_22 += eax_22.b
                *(eax_22 * 3) = eax_22:1.b
                *eax_22 = adc.b(*eax_22, eax_22.b, temp17_1 + eax_22.b u< temp17_1)
                *eax_22 += eax_22.b
                uint16_t* esi_1 = *esp
                esp = &esp[1]
                *(eax_22 + 2 + esi_1 + 0x30c80040) += entry_ebx:1.b
                void* eax_30
                eax_30:1.b = (eax_22 + 3):1.b + arg3.b
                *eax_30 ^= eax_30.b
                *eax_30 <<= 1
                void* eax_31
                eax_31:1.b = (eax_30 + 1):1.b + (eax_30 + 1).b
                *eax_31 ^= eax_31.b
                eax_22 = eax_31
                *(esi_1 + ebp + 0x40) += eax_22:1.b
                *(eax_22 + 0x900402e) += eax_22:1.b
                ebp += 1
                uint16_t* esi_2 = __outsd(arg2.w, *esi_1, esi_1, eflags)
                uint16_t* esi_3 = __outsb(arg2.w, *esi_2, esi_2, eflags)
                
                if (entry_ebx == 0xffffffff)
                    *eax_22 += eax_22.b
                    *eax_22 += eax_22.b
                    *eax_22 += eax_22.b
                    *eax_22 += eax_22.b
                    *eax_22 += eax_22.b
                    *eax_22 += eax_22.b
                    *eax_22 += eax_22.b
                    *0xc0040 += (entry_ebx + 1):1.b
                    goto label_406516
                
                __outsd(arg2.w, *esi_3, esi_3, eflags)
                uint8_t* edi_1
                uint8_t temp0_12
                temp0_12, edi_1 = __insb(arg6, arg2.w, eflags)
                *edi_1 = temp0_12
                z_4 = entry_ebx == 0xfffffffe
            label_406494:
                arg3 -= 1
                
                if (z_4 || arg3 == 0)
                    eax_22 += 1
                    *eax_22 += eax_22.b
                    *eax_22 += eax_22.b
                    goto label_40649b
                
                *eax_22 += eax_22.b
                *eax_22 += eax_22.b
                *eax_22 += eax_22.b
                *eax_22 += eax_22.b
                *eax_22 += eax_22.b
                *eax_22 += eax_22.b
                *eax_22 += eax_22.b
                *eax_22 += eax_22.b
                *eax_22 += eax_22.b
                *eax_22 += eax_22.b
                *eax_22 += eax_22.b
                eax_22 += 1
                *(eax_22 * 2) += arg3.b
            label_406516:
                *eax_22 += eax_22.b
                *(esp - 4) = ebp
                *eax_22 ^= eax_22.b
                breakpoint
            
            *eax_22 += eax_22.b
            *eax_22 += eax_22.b
            *eax_22 += eax_22.b
            *eax_22 += eax_22.b
            *eax_22 += eax_22.b
            *eax_22 += eax_22.b
            *eax_22 += eax_22.b
            *eax_22 += eax_22.b
            *eax_22 += eax_22.b
            *eax_22 += eax_22.b
            char temp14_1 = *eax_22
            *eax_22 += eax_22.b
            arg3 -= 1
            
            if (temp14_1 != neg.b(eax_22.b) && arg3 != 0)
                *(eax_22 + 1 + arg5 + 0x30c80040) += entry_ebx:1.b
                void* eax_36
                eax_36:1.b = (eax_22 + 2):1.b + arg3.b
                *eax_36 ^= eax_36.b
                *eax_36 <<= 1
                void* eax_37
                eax_37:1.b = (eax_36 + 1):1.b + (eax_36 + 1).b
                *eax_37 ^= eax_37.b
                *(arg5 + ebp + 0x40) += eax_37:1.b
                char temp15 = *(eax_37 + 0x1000402e)
                *(eax_37 + 0x1000402e) += eax_37:1.b
                bool c_9 = temp15 + eax_37:1.b u< temp15
                bool p = unimplemented  {inc ecx}
                bool a = unimplemented  {inc ecx}
                
                if (not(c_9))
                    *eax_37 += eax_37.b
                    *eax_37 += eax_37.b
                else if (not(c_9))
                    *(arg6 + 0x6e)
                    void* ebp_5 = *(arg6 + 0x6e) * 0x6c696146
                    bool c_10 = unimplemented  {imul ebp, dword [edi+0x6e], 0x6c696146}
                    bool o = unimplemented  {imul ebp, dword [edi+0x6e], 0x6c696146}
                    bool d
                    *(esp - 4) = (o ? 1 : 0) << 0xb | (d ? 1 : 0) << 0xa
                        | (arg3 + 1 s< 0 ? 1 : 0) << 7 | (arg3 == 0xffffffff ? 1 : 0) << 6
                        | (a ? 1 : 0) << 4 | (p ? 1 : 0) << 2 | (c_10 ? 1 : 0)
                    *(eax_37 + 1) += (eax_37 + 1).b
                    *(eax_37 + 1) += (eax_37 + 1).b
                    *(eax_37 + 1) += (eax_37 + 1).b
                    *(eax_37 + 1) += (eax_37 + 1).b
                    *(eax_37 + 1) += (eax_37 + 1).b
                    *(eax_37 + 1) += (eax_37 + 1).b
                    *(eax_37 + 1) += (eax_37 + 1).b
                    *(eax_37 + 1) += (eax_37 + 1).b
                    *(eax_37 + 1) += (eax_37 + 1).b
                    *(eax_37 + 1) += (eax_37 + 1).b
                    *(eax_37 + 1) += (eax_37 + 1).b
                    *(eax_37 + 1) += (eax_37 + 1).b
                    *(eax_37 + 1) += (eax_37 + 1).b
                    *(eax_37 + 1) += (eax_37 + 1).b
                    *(ebp_5 + 0xc0040) += entry_ebx.b
                    *(eax_37 + 1) += (eax_37 + 1).b
                    *(esp - 8) = ebp_5
                    *(eax_37 + 1) ^= (eax_37 + 1).b
                    breakpoint
                
                *eax_37 += eax_37.b
                *eax_37 += eax_37.b
                *eax_37 += eax_37.b
                *eax_37 += eax_37.b
                *eax_37 += eax_37.b
                *eax_37 += eax_37.b
                *eax_37 += eax_37.b
                *eax_37 += eax_37.b
                *eax_37 += eax_37.b
                *eax_37 += eax_37.b
                *((eax_37 + 1) * 2) += arg3.b + 1
                *(eax_37 + 1) += (eax_37 + 1).b
                *(esp - 4) = ebp + 1
                *(eax_37 + 1) ^= (eax_37 + 1).b
                breakpoint
            
            eax_34 = eax_22 + 1
        
        *(eax_34 * 2) += arg3.b
        *eax_34 += eax_34.b
        *(esp - 4) = ebp
        *eax_34 ^= eax_34.b
        breakpoint
    
    goto label_406494

*(eax_9 + 1 + arg5 + 0x30c80040) += entry_ebx:1.b
void* eax_19
eax_19:1.b = (eax_9 + 2):1.b + arg3.b
*eax_19 ^= eax_19.b
*eax_19 <<= 1
void* eax_20
eax_20:1.b = (eax_19 + 1):1.b + (eax_19 + 1).b
*eax_20 ^= eax_20.b
eax_22 = eax_20
*(arg5 + ebp + 0x40) += eax_22:1.b
goto label_4063cf
