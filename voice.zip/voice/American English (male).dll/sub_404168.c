// 函数: sub_404168
// 地址: 0x404168
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

if (arg1 != 0)
    *(arg1 - 4)
