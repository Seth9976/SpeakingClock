// 函数: SafeArrayPtrOfIndex
// 地址: 0x40bffc
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

return SafeArrayPtrOfIndex(psa, rgIndices, ppvData) __tailcall
