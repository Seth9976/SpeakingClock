// 函数: sub_4010c5
// 地址: 0x4010c5
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

return sub_404ffc(&arg1[-2]) __tailcall
