// 函数: sub_4010af
// 地址: 0x4010af
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

if (sub_402f64(__return_addr - 8, arg1, arg2) == 0)
    return 0x80004002

return 0
