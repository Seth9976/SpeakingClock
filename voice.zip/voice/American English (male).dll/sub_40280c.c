// 函数: sub_40280c
// 地址: 0x40280c
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

int16_t ecx = *(arg1 + 4)
int32_t result

if (ecx == 0xd7b1)
    result = 0
else if (ecx + 0x284e u< 2)
    result = arg2()
else if (arg1 == 0x414214 || arg1 == 0x4143e0)
    result = 0
else
    result = 0x67

if (result != 0)
    sub_40273c(result)

return result
