// 函数: sub_4030bc
// 地址: 0x4030bc
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

return 0x8000ffff
