// 函数: GetLastError
// 地址: 0x405858
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

return GetLastError() __tailcall
