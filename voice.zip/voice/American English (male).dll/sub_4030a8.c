// 函数: sub_4030a8
// 地址: 0x4030a8
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

void** eax

while (true)
    if (arg1 == arg2)
        arg1.b = 1
        return arg1
    
    eax = *(arg1 - 0x24)
    
    if (eax == 0)
        break
    
    arg1 = *eax

return eax
