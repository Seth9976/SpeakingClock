// 函数: sub_404fa0
// 地址: 0x404fa0
// 来自: E:\torrent\Tools\Speaking Clock\voice\American English (male).dll

if (*(arg1 + 4) == 0)
    return 

arg1.b = 2
sub_402710(arg1)
noreturn
