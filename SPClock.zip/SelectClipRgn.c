// 函数: SelectClipRgn
// 地址: 0x4072e4
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return SelectClipRgn(hdc, hrgn) __tailcall
