// 函数: IsWindowUnicode
// 地址: 0x407714
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return IsWindowUnicode(hWnd) __tailcall
