// 函数: CreateFileA
// 地址: 0x406e54
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return CreateFileA(lpFileName, dwDesiredAccess, dwShareMode, lpSecurityAttributes, 
    dwCreationDisposition, dwFlagsAndAttributes, hTemplateFile) __tailcall
