// 函数: GetWindowOrgEx
// 地址: 0x407274
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return GetWindowOrgEx(hdc, lppoint) __tailcall
