// 函数: StrokePath
// 地址: 0x40738c
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return StrokePath(hdc) __tailcall
