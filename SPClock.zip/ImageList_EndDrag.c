// 函数: ImageList_EndDrag
// 地址: 0x4269a4
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return ImageList_EndDrag() __tailcall
