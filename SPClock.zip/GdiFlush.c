// 函数: GdiFlush
// 地址: 0x4071c4
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return GdiFlush() __tailcall
