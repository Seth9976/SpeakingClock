// 函数: sub_401187
// 地址: 0x401187
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return ?__abi_AddRef@RuntimeClassNameAttribute@Metadata@Platform@@U$AAGKXZ(arg1 - 8) __tailcall
