// 函数: EnumChildWindows
// 地址: 0x4074d4
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return EnumChildWindows(hWndParent, lpEnumFunc, lParam) __tailcall
