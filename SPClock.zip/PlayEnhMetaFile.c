// 函数: PlayEnhMetaFile
// 地址: 0x4072a4
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return PlayEnhMetaFile(hdc, hmf, lprect) __tailcall
