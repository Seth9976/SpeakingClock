// 函数: ImageList_Destroy
// 地址: 0x42693c
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return ImageList_Destroy(himl) __tailcall
