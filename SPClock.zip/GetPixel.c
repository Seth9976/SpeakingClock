// 函数: GetPixel
// 地址: 0x407234
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return GetPixel(hdc, x, y) __tailcall
