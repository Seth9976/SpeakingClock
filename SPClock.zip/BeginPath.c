// 函数: BeginPath
// 地址: 0x4070dc
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return BeginPath(hdc) __tailcall
