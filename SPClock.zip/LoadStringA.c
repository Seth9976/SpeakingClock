// 函数: LoadStringA
// 地址: 0x407754
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return LoadStringA(hInstance, uID, lpBuffer, cchBufferMax) __tailcall
