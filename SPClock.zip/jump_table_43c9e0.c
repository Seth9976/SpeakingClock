// 函数: jump_table_43c9e0
// 地址: 0x43c9e0
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

int32_t entry_ebx
*(arg1 + 0x40043ca) += arg3 | entry_ebx.b
undefined
