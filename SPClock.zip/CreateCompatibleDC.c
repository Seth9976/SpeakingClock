// 函数: CreateCompatibleDC
// 地址: 0x40710c
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return CreateCompatibleDC(hdc) __tailcall
