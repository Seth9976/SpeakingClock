// 函数: GetWindowLongA
// 地址: 0x40767c
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return GetWindowLongA(hWnd, nIndex) __tailcall
