// 函数: GetDCEx
// 地址: 0x40755c
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return GetDCEx(hWnd, hrgnClip, flags) __tailcall
