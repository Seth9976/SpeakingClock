// 函数: InflateRect
// 地址: 0x4076b4
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return InflateRect(lprc, dx, dy) __tailcall
