// 函数: GetProfileStringA
// 地址: 0x406f8c
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return GetProfileStringA(lpAppName, lpKeyName, lpDefault, lpReturnedString, nSize) __tailcall
