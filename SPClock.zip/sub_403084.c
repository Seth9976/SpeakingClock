// 函数: sub_403084
// 地址: 0x403084
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

int32_t result = *(sub_406b68() + 4)
*(sub_406b68() + 4) = 0
return result
