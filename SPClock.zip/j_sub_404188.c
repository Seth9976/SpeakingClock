// 函数: j_sub_404188
// 地址: 0x4a7f01
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return sub_404188() __tailcall
