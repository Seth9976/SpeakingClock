// 函数: SetBrushOrgEx
// 地址: 0x407314
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return SetBrushOrgEx(hdc, x, y, lppt) __tailcall
