// 函数: sub_402f4c
// 地址: 0x402f4c
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

if (*sub_406b68() == 0)
    return 0

return *(*sub_406b68() + 4)
