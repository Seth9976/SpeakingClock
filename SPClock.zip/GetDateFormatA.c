// 函数: GetDateFormatA
// 地址: 0x406f34
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return GetDateFormatA(Locale, dwFlags, lpDate, lpFormat, lpDateStr, cchDate) __tailcall
