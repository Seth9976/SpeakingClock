// 函数: RegOpenKeyExA
// 地址: 0x406e1c
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return RegOpenKeyExA(hKey, lpSubKey, ulOptions, samDesired, phkResult) __tailcall
