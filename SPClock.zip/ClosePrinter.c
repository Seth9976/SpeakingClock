// 函数: ClosePrinter
// 地址: 0x43eed4
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return ClosePrinter() __tailcall
