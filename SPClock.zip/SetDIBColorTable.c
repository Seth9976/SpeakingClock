// 函数: SetDIBColorTable
// 地址: 0x40731c
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return SetDIBColorTable(hdc, iStart, cEntries, prgbq) __tailcall
