// 函数: CharUpperBuffA
// 地址: 0x4073e4
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return CharUpperBuffA(lpsz, cchLength) __tailcall
