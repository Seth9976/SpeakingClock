// 函数: DeleteMenu
// 地址: 0x407434
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return DeleteMenu(hMenu, uPosition, uFlags) __tailcall
