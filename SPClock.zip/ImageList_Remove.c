// 函数: ImageList_Remove
// 地址: 0x42698c
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return ImageList_Remove(himl, i) __tailcall
