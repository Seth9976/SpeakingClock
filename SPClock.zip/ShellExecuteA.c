// 函数: ShellExecuteA
// 地址: 0x433d54
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return ShellExecuteA(hwnd, lpOperation, lpFile, lpParameters, lpDirectory, nShowCmd) __tailcall
