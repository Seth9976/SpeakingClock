// 函数: ImageList_Add
// 地址: 0x426954
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return ImageList_Add(himl, hbmImage, hbmMask) __tailcall
