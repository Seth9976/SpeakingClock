// 函数: CreateRoundRectRgn
// 地址: 0x407164
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return CreateRoundRectRgn(x1, y1, x2, y2, w, h) __tailcall
