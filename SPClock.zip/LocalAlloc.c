// 函数: LocalAlloc
// 地址: 0x406af8
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return LocalAlloc(uFlags, uBytes) __tailcall
