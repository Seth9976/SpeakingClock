// 函数: GetVersionExA
// 地址: 0x406fbc
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return GetVersionExA(lpVersionInformation) __tailcall
