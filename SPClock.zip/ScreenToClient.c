// 函数: ScreenToClient
// 地址: 0x40780c
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return ScreenToClient(hWnd, lpPoint) __tailcall
