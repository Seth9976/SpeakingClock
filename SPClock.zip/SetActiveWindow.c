// 函数: SetActiveWindow
// 地址: 0x407834
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return SetActiveWindow(hWnd) __tailcall
