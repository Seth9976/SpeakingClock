// 函数: sub_40119f
// 地址: 0x40119f
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

char temp1 = *(arg5 - 0x6effbfef)
*(arg5 - 0x6effbfef) += (arg3 + 1).b
*(arg3 + 1) = adc.d(*(arg3 + 1), arg3 + 1, temp1 + (arg3 + 1).b u< temp1)
*(arg3 + 1) += arg3 + 1
*(arg3 + 1) += (arg3 + 1).b
*(arg3 + 1) += (arg3 + 1).b
*(arg3 + 1) += (arg3 + 1).b
*(arg3 + 1) += (arg3 + 1).b
*(arg3 + 1) += (arg3 + 1).b
*(arg3 + 1) = rol.b(*(arg3 + 1), 0)
*(arg3 + 1) += (arg3 + 1).b
*(arg3 + 1) += (arg3 + 1).b
*(arg3 + 1) = adc.d(*(arg3 + 1), arg3 + 1, test_bit(__return_addr, 0))
*(arg3 + 1) |= (arg3 + 1).b
*(arg3 + 1) += (arg3 + 1).b
*(arg3 + 1) += (arg3 + 1).b
char temp2 = *(arg3 + 1)
*(arg3 + 1) += (arg3 + 1).b
*arg2 = sbb.b(*arg2, arg2.b, temp2 + (arg3 + 1).b u< temp2)
arg1[0x4011] += arg1:1.b
*(arg3 + 2) += (arg3 + 2).b
*(arg3 + 2) += (arg3 + 2).b
*(arg3 + 2) += (arg3 + 2).b
*(arg3 + 2) += (arg3 + 2).b
*(arg3 + 2) += (arg3 + 2).b
*(arg3 + 2) += (arg3 + 2).b
*(arg3 + 2) += (arg3 + 2).b
*(arg3 + 2) += (arg3 + 2).b
*(arg3 + 2) += (arg3 + 2).b
*(arg3 + 2) += (arg3 + 2).b
*(arg3 + 2) += (arg3 + 2).b
char temp3 = *(arg3 + 2)
void** entry_ebx
*(arg3 + 2) += entry_ebx.b
void* eax_1
eax_1.b = adc.b((arg3 + 2).b, *(arg3 + 2), temp3 + entry_ebx.b u< temp3)
eax_1.b = eax_1.b
*eax_1 += eax_1.b
arg6 f- fconvert.t(*eax_1)
*(eax_1 - 0x2fffbfc1) += arg2:1.b
void* eax_3
eax_3:1.b = (eax_1 + 2):1.b + entry_ebx.b
void* eax_4
eax_4:1.b = (eax_3 + 1):1.b + (eax_3 + 1).b
*(eax_4 - 0x13ffbfc1) += entry_ebx:1.b
HANDLE arg_4
*(&arg_4 + arg5) += entry_ebx.b
*(eax_4 + 0x3f) += entry_ebx.b
char temp4 = *arg1
*arg1 += arg2.b
int32_t eflags
char* esi_1 = __outsb(arg2.w, *(arg4 + 1), arg4 + 1, eflags)

if (arg1 == 1)
    entry_ebx:1.b s>>= 0x25
else if (temp4 + arg2.b u>= temp4)
    int16_t esi_2 = arg_4.w
    void arg_20
    int32_t eflags_1
    int16_t temp0_1
    temp0_1, eflags_1 = __arpl_memw_gpr16(*(arg7 + 0x64), &arg_20)
    *(arg7 + 0x64) = temp0_1
    __bound_gprv_mema32(arg7, *(arg9 + 0x65))
    int32_t eflags_2
    int16_t temp0_2
    temp0_2, eflags_2 = __arpl_memw_gpr16(*(arg8 + (arg10 << 2) - 0x40), esi_2)
    *(arg8 + (arg10 << 2) - 0x40) = temp0_2
    return GetStdHandle() __tailcall

void* eax_8
eax_8.b = *esi_1
*entry_ebx -= arg1 - 1
return FindClose(arg_4) __tailcall
