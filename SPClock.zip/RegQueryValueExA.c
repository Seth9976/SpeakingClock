// 函数: RegQueryValueExA
// 地址: 0x406e2c
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return RegQueryValueExA(hKey, lpValueName, lpReserved, lpType, lpData, lpcbData) __tailcall
