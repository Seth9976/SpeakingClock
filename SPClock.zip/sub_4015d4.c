// 函数: sub_4015d4
// 地址: 0x4015d4
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

uint32_t edx = (arg2 - 0xb30) u>> 8
void*** edx_4 = *(((((edx - 0x3ff) & sbb.d(arg3, arg3, edx u< 0x3ff)) + 0x3ff) << 3) + 0x4ad7a8)
*arg1 = ((((edx - 0x3ff) & sbb.d(arg3, arg3, edx u< 0x3ff)) + 0x3ff) << 3) + &data_4ad7a4
arg1[1] = edx_4
*edx_4 = arg1
*(((((edx - 0x3ff) & sbb.d(arg3, arg3, edx u< 0x3ff)) + 0x3ff) << 3) + 0x4ad7a8) = arg1

if (edx_4 != ((((edx - 0x3ff) & sbb.d(arg3, arg3, edx u< 0x3ff)) + 0x3ff) << 3) + &data_4ad7a4)
    return 

uint32_t edx_6 = zx.d(((((edx - 0x3ff) & sbb.d(arg3, arg3, edx u< 0x3ff)) + 0x3ff) << 3).w:1.b)
*((edx_6 << 2) + &data_4ad724) |=
    1 << ((((edx - 0x3ff) & sbb.d(arg3, arg3, edx u< 0x3ff)) + 0x3ff) << 3 u>> 3).b
data_4ad720 |= 1 << edx_6.b
