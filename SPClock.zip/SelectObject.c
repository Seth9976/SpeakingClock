// 函数: SelectObject
// 地址: 0x4072ec
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return SelectObject(hdc, h) __tailcall
