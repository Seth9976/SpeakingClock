// 函数: SetBkColor
// 地址: 0x407304
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return SetBkColor(hdc, color) __tailcall
