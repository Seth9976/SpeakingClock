// 函数: GetKeyNameTextA
// 地址: 0x407594
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return GetKeyNameTextA(lParam, lpString, cchSize) __tailcall
