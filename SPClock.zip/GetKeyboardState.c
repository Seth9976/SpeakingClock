// 函数: GetKeyboardState
// 地址: 0x4075bc
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return GetKeyboardState(lpKeyState) __tailcall
