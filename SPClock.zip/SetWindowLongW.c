// 函数: SetWindowLongW
// 地址: 0x4078c4
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return SetWindowLongW(hWnd, nIndex, dwNewLong) __tailcall
