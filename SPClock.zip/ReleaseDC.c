// 函数: ReleaseDC
// 地址: 0x4077f4
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return ReleaseDC(hWnd, hDC) __tailcall
