// 函数: EnterCriticalSection
// 地址: 0x406eac
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return EnterCriticalSection(lpCriticalSection) __tailcall
