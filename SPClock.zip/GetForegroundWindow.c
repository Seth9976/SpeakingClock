// 函数: GetForegroundWindow
// 地址: 0x407584
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return GetForegroundWindow() __tailcall
