// 函数: GetDIBColorTable
// 地址: 0x4071f4
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return GetDIBColorTable(hdc, iStart, cEntries, prgbq) __tailcall
