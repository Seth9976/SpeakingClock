// 函数: GetFullPathNameA
// 地址: 0x406f54
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return GetFullPathNameA(lpFileName, nBufferLength, lpBuffer, lpFilePart) __tailcall
