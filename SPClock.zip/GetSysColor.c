// 函数: GetSysColor
// 地址: 0x40763c
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return GetSysColor(nIndex) __tailcall
