// 函数: GetStdHandle
// 地址: 0x406f94
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return GetStdHandle(nStdHandle) __tailcall
