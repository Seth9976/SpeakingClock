// 函数: SetThreadLocale
// 地址: 0x407084
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return SetThreadLocale(Locale) __tailcall
