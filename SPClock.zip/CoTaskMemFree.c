// 函数: CoTaskMemFree
// 地址: 0x407c28
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return CoTaskMemFree(pv) __tailcall
