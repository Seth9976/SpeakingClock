// 函数: GetCurrentThreadId
// 地址: 0x406f2c
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return GetCurrentThreadId() __tailcall
