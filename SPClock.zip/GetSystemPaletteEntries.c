// 函数: GetSystemPaletteEntries
// 地址: 0x40724c
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return GetSystemPaletteEntries(hdc, iStart, cEntries, pPalEntries) __tailcall
