// 函数: SetClipboardData
// 地址: 0x40784c
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return SetClipboardData(uFormat, hMem) __tailcall
