// 函数: CreateRectRgn
// 地址: 0x407154
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return CreateRectRgn(x1, y1, x2, y2) __tailcall
