// 函数: SetCapture
// 地址: 0x40783c
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return SetCapture(hWnd) __tailcall
