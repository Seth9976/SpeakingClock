// 函数: GetStockObject
// 地址: 0x407244
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return GetStockObject(i) __tailcall
