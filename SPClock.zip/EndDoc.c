// 函数: EndDoc
// 地址: 0x407194
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return EndDoc(hdc) __tailcall
