// 函数: RectVisible
// 地址: 0x4072c4
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return RectVisible(hdc, lprect) __tailcall
