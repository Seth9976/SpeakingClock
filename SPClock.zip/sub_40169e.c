// 函数: sub_40169e
// 地址: 0x40169e
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return 
