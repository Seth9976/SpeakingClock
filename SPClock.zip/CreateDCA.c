// 函数: CreateDCA
// 地址: 0x407114
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return CreateDCA(pwszDriver, pwszDevice, pszPort, pdm) __tailcall
