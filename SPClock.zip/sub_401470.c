// 函数: sub_401470
// 地址: 0x401470
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

long double x87_r7 = float.t(*arg1)
long double x87_r6 = float.t(arg1[1])
long double x87_r5 = float.t(arg1[2])
arg2[4].d = arg1[4].d
arg2[3] = int.q(float.t(arg1[3]))
arg2[2] = int.q(x87_r5)
arg2[1] = int.q(x87_r6)
*arg2 = int.q(x87_r7)
