// 函数: sndPlaySoundA
// 地址: 0x486eb4
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return sndPlaySoundA(pszSound, fuSound) __tailcall
