// 函数: CreateIcon
// 地址: 0x407404
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return CreateIcon(hInstance, nWidth, nHeight, cPlanes, cBitsPixel, lpbANDbits, lpbXORbits)
    __tailcall
