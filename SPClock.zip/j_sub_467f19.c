// 函数: j_sub_467f19
// 地址: 0x467f37
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return sub_467f19(arg1) __tailcall
