// 函数: RtlUnwind
// 地址: 0x40123c
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return RtlUnwind(TargetFrame, TargetIp, ExceptionRecord, ReturnValue) __tailcall
