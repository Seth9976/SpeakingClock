// 函数: DrawFrameControl
// 地址: 0x40747c
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return DrawFrameControl(param0, param1, param2, param3) __tailcall
