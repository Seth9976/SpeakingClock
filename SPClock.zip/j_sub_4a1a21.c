// 函数: j_sub_4a1a21
// 地址: 0x4a1a37
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return sub_4a1a21(arg1) __tailcall
