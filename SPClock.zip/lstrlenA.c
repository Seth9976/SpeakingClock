// 函数: lstrlenA
// 地址: 0x4012fc
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return lstrlenA(lpString) __tailcall
