// 函数: LoadIconA
// 地址: 0x407744
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return LoadIconA(hInstance, lpIconName) __tailcall
