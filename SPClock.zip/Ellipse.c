// 函数: Ellipse
// 地址: 0x40718c
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return Ellipse(hdc, left, top, right, bottom) __tailcall
