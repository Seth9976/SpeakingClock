// 函数: DeleteEnhMetaFile
// 地址: 0x40717c
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return DeleteEnhMetaFile(hmf) __tailcall
