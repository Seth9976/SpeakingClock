// 函数: InterlockedDecrement
// 地址: 0x406efc
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return InterlockedDecrement() __tailcall
