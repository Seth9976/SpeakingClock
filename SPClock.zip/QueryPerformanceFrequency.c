// 函数: QueryPerformanceFrequency
// 地址: 0x407044
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return QueryPerformanceFrequency(lpFrequency) __tailcall
