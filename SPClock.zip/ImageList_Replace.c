// 函数: ImageList_Replace
// 地址: 0x42697c
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return ImageList_Replace(himl, i, hbmImage, hbmMask) __tailcall
