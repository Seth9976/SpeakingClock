// 函数: FindResourceA
// 地址: 0x406ee4
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return FindResourceA(hModule, lpName, lpType) __tailcall
