// 函数: DefWindowProcA
// 地址: 0x40742c
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return DefWindowProcA(hWnd, Msg, wParam, lParam) __tailcall
