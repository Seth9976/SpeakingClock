// 函数: sub_402edc
// 地址: 0x402edc
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

if (*arg1 == 0)
    if (arg2 == 0)
        return 
    
    int32_t** var_4_2 = arg1
    int32_t* eax_6 = data_4aa724(var_4_2)
    
    if (eax_6 != 0)
        *var_4_2 = eax_6
        return 
else
    if (arg2 == 0)
        *arg1 = arg2
        
        if (data_4aa728() == 0)
            return 
        
        int32_t eax_2
        eax_2.b = 2
        noreturn sub_402ff8(eax_2) __tailcall
    
    int32_t* eax_1 = data_4aa72c(arg1)
    
    if (eax_1 != 0)
        *arg1 = eax_1
        return 

arg1.b = 1
noreturn sub_402ff8(arg1) __tailcall
