// 函数: GetPropA
// 地址: 0x407614
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return GetPropA(hWnd, lpString) __tailcall
