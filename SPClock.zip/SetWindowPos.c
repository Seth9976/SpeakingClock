// 函数: SetWindowPos
// 地址: 0x4078d4
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return SetWindowPos(hWnd, hWndInsertAfter, X, Y, cx, cy, uFlags) __tailcall
