// 函数: CreateDirectoryA
// 地址: 0x401284
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return CreateDirectoryA(lpPathName, lpSecurityAttributes) __tailcall
