// 函数: RegisterClipboardFormatA
// 地址: 0x4077d4
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return RegisterClipboardFormatA(lpszFormat) __tailcall
