// 函数: LoadBitmapA
// 地址: 0x407734
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return LoadBitmapA(hInstance, lpBitmapName) __tailcall
