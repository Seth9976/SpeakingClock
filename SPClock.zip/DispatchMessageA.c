// 函数: DispatchMessageA
// 地址: 0x40745c
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return DispatchMessageA(lpMsg) __tailcall
