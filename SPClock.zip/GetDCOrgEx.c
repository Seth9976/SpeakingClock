// 函数: GetDCOrgEx
// 地址: 0x4071ec
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return GetDCOrgEx(hdc, lppt) __tailcall
