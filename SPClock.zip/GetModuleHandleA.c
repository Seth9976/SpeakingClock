// 函数: GetModuleHandleA
// 地址: 0x406f7c
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return GetModuleHandleA(lpModuleName) __tailcall
