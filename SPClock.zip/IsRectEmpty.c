// 函数: IsRectEmpty
// 地址: 0x4076fc
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return IsRectEmpty(lprc) __tailcall
