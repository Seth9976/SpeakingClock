// 函数: RegEnumKeyExA
// 地址: 0x406e0c
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return RegEnumKeyExA(hKey, dwIndex, lpName, lpcchName, lpReserved, lpClass, lpcchClass, 
    lpftLastWriteTime) __tailcall
