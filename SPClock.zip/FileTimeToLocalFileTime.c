// 函数: FileTimeToLocalFileTime
// 地址: 0x406ec4
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return FileTimeToLocalFileTime(lpFileTime, lpLocalFileTime) __tailcall
