// 函数: CLSIDFromString
// 地址: 0x408bcc
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return CLSIDFromString(lpsz, pclsid) __tailcall
