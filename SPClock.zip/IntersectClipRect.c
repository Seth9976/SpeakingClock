// 函数: IntersectClipRect
// 地址: 0x40727c
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return IntersectClipRect(hdc, left, top, right, bottom) __tailcall
