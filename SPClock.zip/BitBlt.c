// 函数: BitBlt
// 地址: 0x4070e4
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return BitBlt(hdc, x, y, cx, cy, hdcSrc, x1, y1, rop) __tailcall
