// 函数: EnumPrintersA
// 地址: 0x43eee4
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return EnumPrintersA() __tailcall
