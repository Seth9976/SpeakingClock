// 函数: OpenPrinterA
// 地址: 0x43eeec
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return OpenPrinterA() __tailcall
