// 函数: FindClose
// 地址: 0x406ecc
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return FindClose(hFindFile) __tailcall
