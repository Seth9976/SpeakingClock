// 函数: SetViewportOrgEx
// 地址: 0x40735c
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return SetViewportOrgEx(hdc, x, y, lppt) __tailcall
