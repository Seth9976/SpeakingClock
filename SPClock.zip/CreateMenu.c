// 函数: CreateMenu
// 地址: 0x40740c
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return CreateMenu() __tailcall
