// 函数: ImageList_DragLeave
// 地址: 0x4269b4
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return ImageList_DragLeave(hwndLock) __tailcall
