// 函数: sub_403080
// 地址: 0x403080
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return 
