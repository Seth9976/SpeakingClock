// 函数: sub_402fa0
// 地址: 0x402fa0
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

data_4aa004 = arg2
int32_t eax
sub_404abc(eax)
noreturn
