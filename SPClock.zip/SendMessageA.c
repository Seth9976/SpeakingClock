// 函数: SendMessageA
// 地址: 0x407824
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return SendMessageA(hWnd, Msg, wParam, lParam) __tailcall
