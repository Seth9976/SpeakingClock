// 函数: IsWindow
// 地址: 0x407704
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return IsWindow(hWnd) __tailcall
