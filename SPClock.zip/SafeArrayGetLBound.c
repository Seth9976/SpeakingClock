// 函数: SafeArrayGetLBound
// 地址: 0x40f564
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return SafeArrayGetLBound(psa, nDim, plLbound) __tailcall
