// 函数: GetCurrentPositionEx
// 地址: 0x4071e4
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return GetCurrentPositionEx(hdc, lppt) __tailcall
