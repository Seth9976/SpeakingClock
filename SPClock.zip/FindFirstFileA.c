// 函数: FindFirstFileA
// 地址: 0x406ed4
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return FindFirstFileA(lpFileName, lpFindFileData) __tailcall
