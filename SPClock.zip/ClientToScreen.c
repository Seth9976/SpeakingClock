// 函数: ClientToScreen
// 地址: 0x4073f4
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return ClientToScreen(hWnd, lpPoint) __tailcall
