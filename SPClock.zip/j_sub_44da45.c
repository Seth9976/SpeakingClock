// 函数: j_sub_44da45
// 地址: 0x44da53
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return sub_44da45(arg1) __tailcall
