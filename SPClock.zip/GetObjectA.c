// 函数: GetObjectA
// 地址: 0x407224
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return GetObjectA(h, c, pv) __tailcall
