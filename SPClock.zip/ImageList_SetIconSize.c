// 函数: ImageList_SetIconSize
// 地址: 0x4269ec
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return ImageList_SetIconSize(himl, cx, cy) __tailcall
