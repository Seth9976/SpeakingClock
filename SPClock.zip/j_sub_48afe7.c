// 函数: j_sub_48afe7
// 地址: 0x48afed
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return sub_48afe7() __tailcall
