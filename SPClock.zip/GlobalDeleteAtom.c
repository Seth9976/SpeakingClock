// 函数: GlobalDeleteAtom
// 地址: 0x406fdc
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return GlobalDeleteAtom(nAtom) __tailcall
