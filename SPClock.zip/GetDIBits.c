// 函数: GetDIBits
// 地址: 0x4071fc
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return GetDIBits(hdc, hbm, start, cLines, lpvBits, lpbmi, usage) __tailcall
