// 函数: SetROP2
// 地址: 0x40733c
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return SetROP2(hdc, rop2) __tailcall
