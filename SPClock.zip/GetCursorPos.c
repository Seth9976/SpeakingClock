// 函数: GetCursorPos
// 地址: 0x40754c
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return GetCursorPos(lpPoint) __tailcall
