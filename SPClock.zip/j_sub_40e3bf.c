// 函数: j_sub_40e3bf
// 地址: 0x40e3da
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return sub_40e3bf(arg1) __tailcall
