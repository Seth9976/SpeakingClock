// 函数: j_sub_4a8411
// 地址: 0x4a841f
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return sub_4a8411(arg1) __tailcall
