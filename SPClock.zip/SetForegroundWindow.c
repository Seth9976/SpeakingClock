// 函数: SetForegroundWindow
// 地址: 0x407864
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return SetForegroundWindow(hWnd) __tailcall
