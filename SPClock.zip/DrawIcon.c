// 函数: DrawIcon
// 地址: 0x407484
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return DrawIcon(hDC, X, Y, hIcon) __tailcall
