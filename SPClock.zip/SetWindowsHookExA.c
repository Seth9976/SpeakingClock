// 函数: SetWindowsHookExA
// 地址: 0x4078e4
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return SetWindowsHookExA(idHook, lpfn, hmod, dwThreadId) __tailcall
