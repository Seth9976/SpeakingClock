// 函数: SendMessageW
// 地址: 0x40782c
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return SendMessageW(hWnd, Msg, wParam, lParam) __tailcall
