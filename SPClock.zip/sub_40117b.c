// 函数: sub_40117b
// 地址: 0x40117b
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

if (sub_403d1c(__return_addr - 8, arg1, arg2) == 0)
    return 0x80004002

return 0
