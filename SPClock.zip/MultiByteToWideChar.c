// 函数: MultiByteToWideChar
// 地址: 0x401304
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return MultiByteToWideChar(CodePage, dwFlags, lpMultiByteStr, cbMultiByte, lpWideCharStr, 
    cchWideChar) __tailcall
