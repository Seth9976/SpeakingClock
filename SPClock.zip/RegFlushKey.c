// 函数: RegFlushKey
// 地址: 0x406e14
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return RegFlushKey(hKey) __tailcall
