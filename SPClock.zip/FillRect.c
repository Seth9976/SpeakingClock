// 函数: FillRect
// 地址: 0x4074f4
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return FillRect(hDC, lprc, hbr) __tailcall
