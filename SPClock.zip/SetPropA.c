// 函数: SetPropA
// 地址: 0x407884
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return SetPropA(hWnd, lpString, hData) __tailcall
