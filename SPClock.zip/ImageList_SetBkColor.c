// 函数: ImageList_SetBkColor
// 地址: 0x426964
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return ImageList_SetBkColor(himl, clrBk) __tailcall
