// 函数: DestroyCursor
// 地址: 0x40743c
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return DestroyCursor(hCursor) __tailcall
