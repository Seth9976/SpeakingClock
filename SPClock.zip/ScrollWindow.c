// 函数: ScrollWindow
// 地址: 0x407814
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return ScrollWindow(hWnd, XAmount, YAmount, lpRect, lpClipRect) __tailcall
