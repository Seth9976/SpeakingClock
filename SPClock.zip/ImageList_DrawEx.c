// 函数: ImageList_DrawEx
// 地址: 0x426984
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return ImageList_DrawEx(himl, i, hdcDst, x, y, dx, dy, rgbBk, rgbFg, fStyle) __tailcall
