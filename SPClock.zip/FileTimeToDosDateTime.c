// 函数: FileTimeToDosDateTime
// 地址: 0x406ebc
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return FileTimeToDosDateTime(lpFileTime, lpFatDate, lpFatTime) __tailcall
