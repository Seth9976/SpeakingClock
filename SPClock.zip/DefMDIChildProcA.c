// 函数: DefMDIChildProcA
// 地址: 0x407424
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return DefMDIChildProcA(hWnd, uMsg, wParam, lParam) __tailcall
