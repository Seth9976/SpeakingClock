// 函数: DestroyIcon
// 地址: 0x407444
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return DestroyIcon(hIcon) __tailcall
