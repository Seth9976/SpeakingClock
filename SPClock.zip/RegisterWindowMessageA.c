// 函数: RegisterWindowMessageA
// 地址: 0x4077e4
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return RegisterWindowMessageA(lpString) __tailcall
