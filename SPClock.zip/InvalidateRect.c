// 函数: InvalidateRect
// 地址: 0x4076d4
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return InvalidateRect(hWnd, lpRect, bErase) __tailcall
