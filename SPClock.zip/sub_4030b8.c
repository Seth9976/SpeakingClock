// 函数: sub_4030b8
// 地址: 0x4030b8
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

int16_t result = CreateDirectoryA(arg1, nullptr)

if (result != 0)
    return result

return sub_403034()
