// 函数: InitializeCriticalSection
// 地址: 0x407004
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return InitializeCriticalSection(lpCriticalSection) __tailcall
