// 函数: GetSubMenu
// 地址: 0x407634
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return GetSubMenu(hMenu, nPos) __tailcall
