// 函数: ImageList_ReplaceIcon
// 地址: 0x42695c
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return ImageList_ReplaceIcon(himl, i, hicon) __tailcall
