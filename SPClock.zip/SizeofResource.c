// 函数: SizeofResource
// 地址: 0x40708c
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return SizeofResource(hModule, hResInfo) __tailcall
