// 函数: GetFileAttributesA
// 地址: 0x406f4c
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return GetFileAttributesA(lpFileName) __tailcall
