// 函数: GetIconInfo
// 地址: 0x40758c
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return GetIconInfo(hIcon, piconinfo) __tailcall
