// 函数: ImageList_DragEnter
// 地址: 0x4269ac
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return ImageList_DragEnter(hwndLock, x, y) __tailcall
