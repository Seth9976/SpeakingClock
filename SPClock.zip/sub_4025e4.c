// 函数: sub_4025e4
// 地址: 0x4025e4
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

int32_t* result

if (sub_402570() == 0 || *data_4af7b8 s>= 0x3ffe)
    result = nullptr
else
    *(data_4af7b8 + (*data_4af7b8 << 2) + 4) = arg1
    result = data_4af7b8
    *result += 1
    result.b = 1

data_4af7bc = 0
return result
