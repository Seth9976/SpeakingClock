// 函数: GetProcAddress
// 地址: 0x406f84
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return GetProcAddress(hModule, lpProcName) __tailcall
