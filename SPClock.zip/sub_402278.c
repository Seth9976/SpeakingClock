// 函数: sub_402278
// 地址: 0x402278
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

int32_t result = (*(arg1 - 4) & 0xfffffff0) + arg1

if ((*(result - 4) & 0xfffffff0) != 0)
    return result

return 0
