// 函数: GetDesktopWindow
// 地址: 0x407564
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return GetDesktopWindow() __tailcall
