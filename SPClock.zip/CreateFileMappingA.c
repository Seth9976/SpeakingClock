// 函数: CreateFileMappingA
// 地址: 0x406e5c
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return CreateFileMappingA(hFile, lpFileMappingAttributes, flProtect, dwMaximumSizeHigh, 
    dwMaximumSizeLow, lpName) __tailcall
