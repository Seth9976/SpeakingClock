// 函数: GetKeyState
// 地址: 0x40759c
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return GetKeyState(nVirtKey) __tailcall
