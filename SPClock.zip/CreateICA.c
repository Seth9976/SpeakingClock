// 函数: CreateICA
// 地址: 0x40713c
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return CreateICA(pszDriver, pszDevice, pszPort, pdm) __tailcall
