// 函数: GetFileVersionInfoA
// 地址: 0x4070c4
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return GetFileVersionInfoA(lptstrFilename, dwHandle, dwLen, lpData) __tailcall
