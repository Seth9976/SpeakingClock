// 函数: PtInRect
// 地址: 0x4077bc
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return PtInRect(lprc, pt) __tailcall
