// 函数: InsertMenuItemA
// 地址: 0x4076c4
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return InsertMenuItemA(hmenu, item, fByPosition, lpmi) __tailcall
