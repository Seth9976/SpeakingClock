// 函数: DrawMenuBar
// 地址: 0x407494
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return DrawMenuBar(hWnd) __tailcall
