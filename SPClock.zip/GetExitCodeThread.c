// 函数: GetExitCodeThread
// 地址: 0x406f44
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return GetExitCodeThread(hThread, lpExitCode) __tailcall
