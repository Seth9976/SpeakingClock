// 函数: CloseHandle
// 地址: 0x406e3c
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return CloseHandle(hObject) __tailcall
