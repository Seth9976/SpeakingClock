// 函数: RegDeleteKeyA
// 地址: 0x406dfc
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return RegDeleteKeyA(hKey, lpSubKey) __tailcall
