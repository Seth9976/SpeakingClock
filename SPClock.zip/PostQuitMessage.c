// 函数: PostQuitMessage
// 地址: 0x4077b4
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return PostQuitMessage(nExitCode) __tailcall
