// 函数: GetMenuItemCount
// 地址: 0x4075d4
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return GetMenuItemCount(hMenu) __tailcall
