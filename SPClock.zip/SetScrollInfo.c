// 函数: SetScrollInfo
// 地址: 0x40789c
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return SetScrollInfo(hwnd, nBar, lpsi, redraw) __tailcall
