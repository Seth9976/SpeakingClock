// 函数: GetBitmapBits
// 地址: 0x4071cc
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return GetBitmapBits(hbit, cb, lpvBits) __tailcall
