// 函数: LoadKeyboardLayoutA
// 地址: 0x40774c
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return LoadKeyboardLayoutA(pwszKLID, Flags) __tailcall
