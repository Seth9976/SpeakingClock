// 函数: DeleteObject
// 地址: 0x407184
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return DeleteObject(ho) __tailcall
