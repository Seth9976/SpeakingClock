// 函数: SetBkMode
// 地址: 0x40730c
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return SetBkMode(hdc, mode) __tailcall
