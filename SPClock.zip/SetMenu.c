// 函数: SetMenu
// 地址: 0x40786c
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return SetMenu(hWnd, hMenu) __tailcall
