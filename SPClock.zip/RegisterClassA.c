// 函数: RegisterClassA
// 地址: 0x4077cc
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return RegisterClassA(lpWndClass) __tailcall
