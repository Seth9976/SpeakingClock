// 函数: j_sub_44c736
// 地址: 0x44c744
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return sub_44c736(arg1) __tailcall
