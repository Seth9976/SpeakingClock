// 函数: sub_401490
// 地址: 0x401490
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

long double x87_r7 = float.t(*arg1)
long double x87_r6 = float.t(arg1[1])
long double x87_r5 = float.t(arg1[2])
long double x87_r4 = float.t(arg1[3])
arg2[5].d = arg1[5].d
arg2[4] = int.q(float.t(arg1[4]))
arg2[3] = int.q(x87_r4)
arg2[2] = int.q(x87_r5)
arg2[1] = int.q(x87_r6)
*arg2 = int.q(x87_r7)
