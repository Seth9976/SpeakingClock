// 函数: RedrawWindow
// 地址: 0x4077c4
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return RedrawWindow(hWnd, lprcUpdate, hrgnUpdate, flags) __tailcall
