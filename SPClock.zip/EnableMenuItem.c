// 函数: EnableMenuItem
// 地址: 0x4074b4
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return EnableMenuItem(hMenu, uIDEnableItem, uEnable) __tailcall
