// 函数: sub_401444
// 地址: 0x401444
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

*arg2 = *arg1
arg2[1] = arg1[1]
arg2[2] = arg1[2]
arg2[3] = arg1[3]
arg2[4] = arg1[4]
int32_t result = arg1[6]
arg2[5] = arg1[5]
arg2[6] = result
return result
