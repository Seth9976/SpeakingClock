// 函数: j_sub_40443c
// 地址: 0x4a994e
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return sub_40443c(arg1, arg2) __tailcall
