// 函数: j_sub_4a1952
// 地址: 0x4a1965
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return sub_4a1952(arg1) __tailcall
