// 函数: sub_402ea8
// 地址: 0x402ea8
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

if (arg1 s<= 0)
    return 0

int32_t result = data_4aa724()

if (result != 0)
    return result

result.b = 1
noreturn sub_402ff8(result) __tailcall
