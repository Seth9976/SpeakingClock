// 函数: InterlockedIncrement
// 地址: 0x406f0c
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return InterlockedIncrement() __tailcall
