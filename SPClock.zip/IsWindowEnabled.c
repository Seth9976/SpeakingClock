// 函数: IsWindowEnabled
// 地址: 0x40770c
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return IsWindowEnabled(hWnd) __tailcall
