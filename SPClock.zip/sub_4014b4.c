// 函数: sub_4014b4
// 地址: 0x4014b4
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

long double x87_r7 = float.t(*arg1)
long double x87_r6 = float.t(arg1[1])
long double x87_r5 = float.t(arg1[2])
long double x87_r4 = float.t(arg1[3])
long double x87_r3 = float.t(arg1[4])
arg2[6].d = arg1[6].d
arg2[5] = int.q(float.t(arg1[5]))
arg2[4] = int.q(x87_r3)
arg2[3] = int.q(x87_r4)
arg2[2] = int.q(x87_r5)
arg2[1] = int.q(x87_r6)
*arg2 = int.q(x87_r7)
