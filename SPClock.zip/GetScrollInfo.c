// 函数: GetScrollInfo
// 地址: 0x40761c
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return GetScrollInfo(hwnd, nBar, lpsi) __tailcall
