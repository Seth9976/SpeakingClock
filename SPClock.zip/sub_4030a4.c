// 函数: sub_4030a4
// 地址: 0x4030a4
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return sub_4030b8(sub_405018(arg1))
