// 函数: GetSystemDirectoryA
// 地址: 0x406f9c
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return GetSystemDirectoryA(lpBuffer, uSize) __tailcall
