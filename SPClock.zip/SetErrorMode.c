// 函数: SetErrorMode
// 地址: 0x40706c
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return SetErrorMode(uMode) __tailcall
