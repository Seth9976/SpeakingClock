// 函数: RealizePalette
// 地址: 0x4072bc
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return RealizePalette(hdc) __tailcall
