// 函数: GetDiskFreeSpaceA
// 地址: 0x406f3c
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return GetDiskFreeSpaceA(lpRootPathName, lpSectorsPerCluster, lpBytesPerSector, 
    lpNumberOfFreeClusters, lpTotalNumberOfClusters) __tailcall
