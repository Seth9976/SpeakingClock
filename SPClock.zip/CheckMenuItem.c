// 函数: CheckMenuItem
// 地址: 0x4073ec
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return CheckMenuItem(hMenu, uIDCheckItem, uCheck) __tailcall
