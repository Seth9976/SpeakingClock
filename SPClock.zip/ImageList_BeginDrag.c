// 函数: ImageList_BeginDrag
// 地址: 0x42699c
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return ImageList_BeginDrag(himlTrack, iTrack, dxHotspot, dyHotspot) __tailcall
