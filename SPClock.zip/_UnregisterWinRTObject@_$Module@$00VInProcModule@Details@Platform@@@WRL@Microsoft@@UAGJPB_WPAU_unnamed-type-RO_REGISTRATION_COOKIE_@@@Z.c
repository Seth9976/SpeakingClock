// 函数: ?UnregisterWinRTObject@?$Module@$00VInProcModule@Details@Platform@@@WRL@Microsoft@@UAGJPB_WPAU<unnamed-type-RO_REGISTRATION_COOKIE>@@@Z
// 地址: 0x40f150
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return 0x80004001
