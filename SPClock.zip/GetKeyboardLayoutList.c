// 函数: GetKeyboardLayoutList
// 地址: 0x4075ac
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return GetKeyboardLayoutList(nBuff, lpList) __tailcall
