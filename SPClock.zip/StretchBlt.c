// 函数: StretchBlt
// 地址: 0x407384
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return StretchBlt(hdcDest, xDest, yDest, wDest, hDest, hdcSrc, xSrc, ySrc, wSrc, hSrc, rop)
    __tailcall
