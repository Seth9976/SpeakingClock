// 函数: GetMenuStringA
// 地址: 0x4075f4
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return GetMenuStringA(hMenu, uIDItem, lpString, cchMax, flags) __tailcall
