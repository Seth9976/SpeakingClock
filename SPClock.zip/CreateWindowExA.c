// 函数: CreateWindowExA
// 地址: 0x4079a4
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return CreateWindowExA(dwExStyle, lpClassName, lpWindowName, dwStyle, X, Y, nWidth, nHeight, 
    hWndParent, hMenu, hInstance, lpParam) __tailcall
