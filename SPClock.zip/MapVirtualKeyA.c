// 函数: MapVirtualKeyA
// 地址: 0x40775c
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return MapVirtualKeyA(uCode, uMapType) __tailcall
