// 函数: DeleteFileA
// 地址: 0x406ea4
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return DeleteFileA(lpFileName) __tailcall
