// 函数: Polyline
// 地址: 0x4072b4
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return Polyline(hdc, apt, cpt) __tailcall
