// 函数: SetWindowOrgEx
// 地址: 0x40736c
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return SetWindowOrgEx(hdc, x, y, lppt) __tailcall
