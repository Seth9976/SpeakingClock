// 函数: j_sub_403744
// 地址: 0x40373c
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return sub_403744(arg1, arg2) __tailcall
