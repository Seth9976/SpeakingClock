// 函数: _TrackMouseEvent
// 地址: 0x4269f4
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return _TrackMouseEvent(lpEventTrack) __tailcall
