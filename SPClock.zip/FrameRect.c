// 函数: FrameRect
// 地址: 0x407504
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return FrameRect(hDC, lprc, hbr) __tailcall
