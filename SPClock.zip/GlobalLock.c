// 函数: GlobalLock
// 地址: 0x406ff4
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return GlobalLock(hMem) __tailcall
