// 函数: SetWindowTextA
// 地址: 0x4078dc
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return SetWindowTextA(hWnd, lpString) __tailcall
