// 函数: GlobalFree
// 地址: 0x406fec
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return GlobalFree(hMem) __tailcall
