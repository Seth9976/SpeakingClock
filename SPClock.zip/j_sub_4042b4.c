// 函数: j_sub_4042b4
// 地址: 0x49f83d
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

int32_t esi
int32_t edi
return sub_4042b4(esi, edi) __tailcall
