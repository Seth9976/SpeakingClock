// 函数: RegCloseKey
// 地址: 0x406dec
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return RegCloseKey(hKey) __tailcall
