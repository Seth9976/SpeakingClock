// 函数: ImageList_Read
// 地址: 0x4269d4
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return ImageList_Read(pstm) __tailcall
