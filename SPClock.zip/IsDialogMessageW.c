// 函数: IsDialogMessageW
// 地址: 0x4076ec
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return IsDialogMessageW(hDlg, lpMsg) __tailcall
