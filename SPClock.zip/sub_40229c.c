// 函数: sub_40229c
// 地址: 0x40229c
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

if (data_4ad71c == 0 || data_4ad718 u< arg1 || arg1 + 0x13fff0 u< data_4ad718)
    return arg1 + 0x10

if (data_4ad71c == 0x13ffe0)
    return 0

return data_4ad718
