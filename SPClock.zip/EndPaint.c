// 函数: EndPaint
// 地址: 0x4074cc
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return EndPaint(hWnd, lpPaint) __tailcall
