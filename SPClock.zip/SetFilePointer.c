// 函数: SetFilePointer
// 地址: 0x40707c
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return SetFilePointer(hFile, lDistanceToMove, lpDistanceToMoveHigh, dwMoveMethod) __tailcall
