// 函数: EndPage
// 地址: 0x40719c
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return EndPage(hdc) __tailcall
