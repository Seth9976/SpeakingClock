// 函数: sub_402c40
// 地址: 0x402c40
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

uint32_t j = 0
int32_t i = 0
void* edx = &data_4aa046

do
    if (data_4ad702 == 0 || (*edx & 0xf) == 0)
        uint32_t j_1
        
        for (j_1 = zx.d(*edx) u>> 3; j_1 u> j; j += 1)
            *(j + 0x4ad5bc) = i.b * 4
        
        j = j_1
    
    i += 1
    edx += 0x20
while (i != 0x37)

return j
