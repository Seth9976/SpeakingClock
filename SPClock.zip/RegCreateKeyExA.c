// 函数: RegCreateKeyExA
// 地址: 0x406df4
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return RegCreateKeyExA(hKey, lpSubKey, Reserved, lpClass, dwOptions, samDesired, 
    lpSecurityAttributes, phkResult, lpdwDisposition) __tailcall
