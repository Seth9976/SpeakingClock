// 函数: GetDeviceCaps
// 地址: 0x407204
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return GetDeviceCaps(hdc, index) __tailcall
