// 函数: lstrcpyA
// 地址: 0x4070bc
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return lstrcpyA(lpString1, lpString2) __tailcall
