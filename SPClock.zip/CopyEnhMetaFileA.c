// 函数: CopyEnhMetaFileA
// 地址: 0x4070ec
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return CopyEnhMetaFileA(hEnh, lpFileName) __tailcall
