// 函数: CharNextA
// 地址: 0x4073d4
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return CharNextA(lpsz) __tailcall
