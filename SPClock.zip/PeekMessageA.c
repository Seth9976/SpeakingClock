// 函数: PeekMessageA
// 地址: 0x40779c
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return PeekMessageA(lpMsg, hWnd, wMsgFilterMin, wMsgFilterMax, wRemoveMsg) __tailcall
