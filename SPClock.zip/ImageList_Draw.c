// 函数: ImageList_Draw
// 地址: 0x426974
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return ImageList_Draw(himl, i, hdcDst, x, y, fStyle) __tailcall
