// 函数: EnumCalendarInfoA
// 地址: 0x406eb4
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return EnumCalendarInfoA(lpCalInfoEnumProc, Locale, Calendar, CalType) __tailcall
