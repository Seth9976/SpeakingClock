// 函数: GetWindowTextA
// 地址: 0x40769c
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return GetWindowTextA(hWnd, lpString, nMaxCount) __tailcall
