// 函数: CreateBrushIndirect
// 地址: 0x4070fc
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return CreateBrushIndirect(plbrush) __tailcall
