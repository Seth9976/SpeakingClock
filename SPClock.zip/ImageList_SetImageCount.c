// 函数: ImageList_SetImageCount
// 地址: 0x42694c
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return ImageList_SetImageCount(himl, uNewCount) __tailcall
