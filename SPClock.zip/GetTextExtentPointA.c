// 函数: GetTextExtentPointA
// 地址: 0x40725c
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return GetTextExtentPointA(hdc, lpString, c, lpsz) __tailcall
