// 函数: j_sub_40502c
// 地址: 0x405078
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return sub_40502c(arg1) __tailcall
