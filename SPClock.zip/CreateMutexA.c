// 函数: CreateMutexA
// 地址: 0x406e64
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return CreateMutexA(lpMutexAttributes, bInitialOwner, lpName) __tailcall
