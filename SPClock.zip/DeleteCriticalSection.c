// 函数: DeleteCriticalSection
// 地址: 0x406e9c
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return DeleteCriticalSection(lpCriticalSection) __tailcall
