// 函数: RemovePropA
// 地址: 0x407804
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return RemovePropA(hWnd, lpString) __tailcall
