// 函数: CreateThread
// 地址: 0x406e8c
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return CreateThread(lpThreadAttributes, dwStackSize, lpStartAddress, lpParameter, dwCreationFlags, 
    lpThreadId) __tailcall
