// 函数: __cfltcvt_init
// 地址: 0x4267fc
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

HMODULE result = GetModuleHandleA(sub_42685c)
data_4b1a24 = result
data_4b1a00 = 0x426208
data_4b1a04 = 0x426320
data_4b1a08 = sub_426290
__builtin_memcpy(&data_4b1a0c, 
    "\xb8\x63\x42\x00\x50\x64\x42\x00\x24\x65\x42\x00\xf8\x65\x42\x00\xcc\x66\x42\x00", 0x14)
return result
