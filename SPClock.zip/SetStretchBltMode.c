// 函数: SetStretchBltMode
// 地址: 0x407344
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return SetStretchBltMode(hdc, mode) __tailcall
