// 函数: EmptyClipboard
// 地址: 0x4074ac
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return EmptyClipboard() __tailcall
