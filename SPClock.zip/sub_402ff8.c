// 函数: sub_402ff8
// 地址: 0x402ff8
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

noreturn sub_402fac(arg1 & 0x7f, __return_addr) __tailcall
