// 函数: sub_402570
// 地址: 0x402570
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

if (data_4ad049 != 0)
    while (sub_401408(0, 1, (&data_4af7bc)).b != 0)
        if (data_4ad5b1 == 0)
            Sleep(0)
            
            if (sub_401408(0, 1, (&data_4af7bc)).b == 0)
                break
            
            Sleep(0xa)

if (data_4af7b8 == 0)
    data_4af7b8 = VirtualAlloc(nullptr, 0x10000, MEM_COMMIT, PAGE_READWRITE)

int32_t result
result.b = data_4af7b8 != 0
return result
