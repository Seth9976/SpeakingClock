// 函数: CreateHalftonePalette
// 地址: 0x407134
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return CreateHalftonePalette(hdc) __tailcall
