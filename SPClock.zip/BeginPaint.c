// 函数: BeginPaint
// 地址: 0x4073b4
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return BeginPaint(hWnd, lpPaint) __tailcall
