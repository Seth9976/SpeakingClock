// 函数: GetMenuItemInfoA
// 地址: 0x4075e4
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return GetMenuItemInfoA(hmenu, item, fByPosition, lpmii) __tailcall
