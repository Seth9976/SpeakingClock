// 函数: PlaySoundA
// 地址: 0x486eac
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return PlaySoundA(pszSound, hmod, fdwSound) __tailcall
