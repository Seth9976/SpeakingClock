// 函数: ImageList_GetBkColor
// 地址: 0x42696c
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return ImageList_GetBkColor(himl) __tailcall
