// 函数: GetSystemMetrics
// 地址: 0x407654
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return GetSystemMetrics(nIndex) __tailcall
