// 函数: DocumentPropertiesA
// 地址: 0x43eedc
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return DocumentPropertiesA() __tailcall
