// 函数: ?UnregisterCOMObject@?$Module@$00VInProcModule@Details@Platform@@@WRL@Microsoft@@UAGJPB_WPAKI@Z
// 地址: 0x40f15c
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return 0x80004001
