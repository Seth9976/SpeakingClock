// 函数: GetModuleFileNameA
// 地址: 0x406f74
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return GetModuleFileNameA(hModule, lpFilename, nSize) __tailcall
