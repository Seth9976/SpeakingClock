// 函数: SetScrollPos
// 地址: 0x4078a4
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return SetScrollPos(hWnd, nBar, nPos, bRedraw) __tailcall
