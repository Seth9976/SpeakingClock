// 函数: InterlockedExchange
// 地址: 0x406f04
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return InterlockedExchange() __tailcall
