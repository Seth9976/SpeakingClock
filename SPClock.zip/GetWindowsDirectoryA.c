// 函数: GetWindowsDirectoryA
// 地址: 0x406fc4
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return GetWindowsDirectoryA(lpBuffer, uSize) __tailcall
