// 函数: GetVersion
// 地址: 0x406fb4
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return GetVersion() __tailcall
