// 函数: DrawIconEx
// 地址: 0x40748c
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return DrawIconEx(hdc, xLeft, yTop, hIcon, cxWidth, cyWidth, istepIfAniCur, hbrFlickerFreeDraw, 
    diFlags) __tailcall
