// 函数: ImageList_GetImageCount
// 地址: 0x426944
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return ImageList_GetImageCount(himl) __tailcall
