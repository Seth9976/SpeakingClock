// 函数: InitCommonControls
// 地址: 0x426898
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return InitCommonControls() __tailcall
