// 函数: j_sub_47b63f
// 地址: 0x47b652
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return sub_47b63f(arg1) __tailcall
