// 函数: j_sub_44996c
// 地址: 0x449972
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return sub_44996c() __tailcall
