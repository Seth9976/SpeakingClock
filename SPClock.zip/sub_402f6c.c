// 函数: sub_402f6c
// 地址: 0x402f6c
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

if (*sub_406b68() == 0)
    return 0

void* esi_1 = *sub_406b68()
int32_t result = *(esi_1 + 8)
sub_406b68()
*(esi_1 + 8) = 0
return result
