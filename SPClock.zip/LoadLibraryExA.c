// 函数: LoadLibraryExA
// 地址: 0x4012e4
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return LoadLibraryExA(lpLibFileName, hFile, dwFlags) __tailcall
