// 函数: SetParent
// 地址: 0x40787c
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return SetParent(hWndChild, hWndNewParent) __tailcall
