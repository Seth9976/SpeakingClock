// 函数: EnableScrollBar
// 地址: 0x4074bc
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return EnableScrollBar(hWnd, wSBflags, wArrows) __tailcall
