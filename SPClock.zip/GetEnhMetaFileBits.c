// 函数: GetEnhMetaFileBits
// 地址: 0x40720c
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return GetEnhMetaFileBits(hEMF, nSize, lpData) __tailcall
