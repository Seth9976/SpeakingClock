// 函数: ExtTextOutA
// 地址: 0x4071bc
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return ExtTextOutA(hdc, x, y, options, lprect, lpString, c, lpDx) __tailcall
