// 函数: ?__abi_AddRef@RuntimeClassNameAttribute@Metadata@Platform@@U$AAGKXZ
// 地址: 0x406624
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return InterlockedIncrement(arg1 + 4)
