// 函数: MaskBlt
// 地址: 0x40728c
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return MaskBlt(hdcDest, xDest, yDest, width, height, hdcSrc, xSrc, ySrc, hbmMask, xMask, yMask, rop)
    __tailcall
