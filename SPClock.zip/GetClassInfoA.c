// 函数: GetClassInfoA
// 地址: 0x407524
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return GetClassInfoA(hInstance, lpClassName, lpWndClass) __tailcall
