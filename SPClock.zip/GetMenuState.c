// 函数: GetMenuState
// 地址: 0x4075ec
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return GetMenuState(hMenu, uId, uFlags) __tailcall
