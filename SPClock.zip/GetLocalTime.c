// 函数: GetLocalTime
// 地址: 0x406f64
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return GetLocalTime(lpSystemTime) __tailcall
