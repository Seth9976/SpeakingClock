// 函数: FindNextFileA
// 地址: 0x406edc
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return FindNextFileA(hFindFile, lpFindFileData) __tailcall
