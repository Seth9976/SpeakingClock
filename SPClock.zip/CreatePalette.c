// 函数: CreatePalette
// 地址: 0x407144
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return CreatePalette(plpal) __tailcall
