// 函数: Sleep
// 地址: 0x40e57c
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return Sleep(dwMilliseconds) __tailcall
