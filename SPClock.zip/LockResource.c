// 函数: LockResource
// 地址: 0x407024
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return LockResource(hResData) __tailcall
