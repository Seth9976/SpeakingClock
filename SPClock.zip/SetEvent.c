// 函数: SetEvent
// 地址: 0x407074
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return SetEvent(hEvent) __tailcall
