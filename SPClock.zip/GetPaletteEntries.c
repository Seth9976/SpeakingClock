// 函数: GetPaletteEntries
// 地址: 0x40722c
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return GetPaletteEntries(hpal, iStart, cEntries, pPalEntries) __tailcall
