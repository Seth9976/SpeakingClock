// 函数: CharToOemA
// 地址: 0x4073dc
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return CharToOemA(pSrc, pDst) __tailcall
