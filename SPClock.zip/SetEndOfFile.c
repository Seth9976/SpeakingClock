// 函数: SetEndOfFile
// 地址: 0x407064
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return SetEndOfFile(hFile) __tailcall
