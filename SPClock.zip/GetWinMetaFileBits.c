// 函数: GetWinMetaFileBits
// 地址: 0x40726c
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return GetWinMetaFileBits(hemf, cbData16, pData16, iMapMode, hdcRef) __tailcall
