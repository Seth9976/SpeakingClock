// 函数: SetClassLongA
// 地址: 0x407844
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return SetClassLongA(hWnd, nIndex, dwNewLong) __tailcall
