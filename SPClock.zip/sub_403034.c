// 函数: sub_403034
// 地址: 0x403034
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return sub_403024(GetLastError())
