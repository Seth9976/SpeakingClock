// 函数: CharLowerBuffA
// 地址: 0x4073cc
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return CharLowerBuffA(lpsz, cchLength) __tailcall
