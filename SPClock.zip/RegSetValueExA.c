// 函数: RegSetValueExA
// 地址: 0x406e34
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return RegSetValueExA(hKey, lpValueName, Reserved, dwType, lpData, cbData) __tailcall
