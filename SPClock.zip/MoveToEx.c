// 函数: MoveToEx
// 地址: 0x407294
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return MoveToEx(hdc, x, y, lppt) __tailcall
