// 函数: MulDiv
// 地址: 0x40703c
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return MulDiv(nNumber, nNumerator, nDenominator) __tailcall
