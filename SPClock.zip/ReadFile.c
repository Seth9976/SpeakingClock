// 函数: ReadFile
// 地址: 0x40704c
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return ReadFile(hFile, lpBuffer, nNumberOfBytesToRead, lpNumberOfBytesRead, lpOverlapped) __tailcall
