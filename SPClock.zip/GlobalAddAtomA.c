// 函数: GlobalAddAtomA
// 地址: 0x406fcc
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return GlobalAddAtomA(lpString) __tailcall
