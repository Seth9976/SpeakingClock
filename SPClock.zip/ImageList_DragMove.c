// 函数: ImageList_DragMove
// 地址: 0x4269bc
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return ImageList_DragMove(x, y) __tailcall
