// 函数: ShowWindow
// 地址: 0x407904
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return ShowWindow(hWnd, nCmdShow) __tailcall
