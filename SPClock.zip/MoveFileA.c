// 函数: MoveFileA
// 地址: 0x407034
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return MoveFileA(lpExistingFileName, lpNewFileName) __tailcall
