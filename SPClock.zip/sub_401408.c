// 函数: sub_401408
// 地址: 0x401408
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

if (arg1 == *arg3)
    *arg3 = arg2
else
    *arg3
