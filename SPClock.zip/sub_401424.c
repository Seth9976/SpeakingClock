// 函数: sub_401424
// 地址: 0x401424
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

*arg2 = *arg1
arg2[1] = arg1[1]
arg2[2] = arg1[2]
int32_t result = arg1[4]
arg2[3] = arg1[3]
arg2[4] = result
return result
