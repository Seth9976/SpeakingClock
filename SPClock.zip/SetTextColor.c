// 函数: SetTextColor
// 地址: 0x40734c
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return SetTextColor(hdc, color) __tailcall
