// 函数: OpenClipboard
// 地址: 0x407794
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return OpenClipboard(hWndNewOwner) __tailcall
