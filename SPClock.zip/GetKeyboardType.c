// 函数: GetKeyboardType
// 地址: 0x403a28
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return GetKeyboardType(nTypeFlag) __tailcall
