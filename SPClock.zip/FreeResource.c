// 函数: FreeResource
// 地址: 0x406f14
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return FreeResource(hResData) __tailcall
