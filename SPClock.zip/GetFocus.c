// 函数: GetFocus
// 地址: 0x40757c
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return GetFocus() __tailcall
