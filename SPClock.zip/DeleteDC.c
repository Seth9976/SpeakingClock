// 函数: DeleteDC
// 地址: 0x407174
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return DeleteDC(hdc) __tailcall
