// 函数: DispatchMessageW
// 地址: 0x407464
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return DispatchMessageW(lpMsg) __tailcall
