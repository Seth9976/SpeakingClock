// 函数: j_sub_4a183e
// 地址: 0x4a1851
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return sub_4a183e(arg1) __tailcall
