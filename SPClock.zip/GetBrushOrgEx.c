// 函数: GetBrushOrgEx
// 地址: 0x4071d4
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return GetBrushOrgEx(hdc, lppt) __tailcall
