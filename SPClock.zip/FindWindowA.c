// 函数: FindWindowA
// 地址: 0x4074fc
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return FindWindowA(lpClassName, lpWindowName) __tailcall
