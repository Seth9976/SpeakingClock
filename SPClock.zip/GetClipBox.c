// 函数: GetClipBox
// 地址: 0x4071dc
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return GetClipBox(hdc, lprect) __tailcall
