// 函数: CreateBitmap
// 地址: 0x4070f4
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return CreateBitmap(nWidth, nHeight, nPlanes, nBitCount, lpBits) __tailcall
