// 函数: GetClientRect
// 地址: 0x407534
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return GetClientRect(hWnd, lpRect) __tailcall
