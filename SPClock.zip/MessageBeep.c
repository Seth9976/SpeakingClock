// 函数: MessageBeep
// 地址: 0x40776c
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return MessageBeep(uType) __tailcall
