// 函数: GetCPInfo
// 地址: 0x406f1c
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return GetCPInfo(CodePage, lpCPInfo) __tailcall
