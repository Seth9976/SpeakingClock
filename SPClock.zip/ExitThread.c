// 函数: ExitThread
// 地址: 0x40126c
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

noreturn ExitThread(dwExitCode) __tailcall
