// 函数: sub_402e90
// 地址: 0x402e90
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

if (arg1 != 0 && data_4aa730() == 0)
    arg1.b = 1
    noreturn sub_402ff8(arg1) __tailcall
