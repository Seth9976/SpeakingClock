// 函数: GetMenuItemID
// 地址: 0x4075dc
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return GetMenuItemID(hMenu, nPos) __tailcall
