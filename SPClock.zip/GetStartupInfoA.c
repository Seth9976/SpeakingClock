// 函数: GetStartupInfoA
// 地址: 0x4012d4
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return GetStartupInfoA(lpStartupInfo) __tailcall
