// 函数: GetTickCount
// 地址: 0x406fac
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return GetTickCount() __tailcall
