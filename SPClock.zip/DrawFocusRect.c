// 函数: DrawFocusRect
// 地址: 0x407474
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return DrawFocusRect(hDC, lprc) __tailcall
