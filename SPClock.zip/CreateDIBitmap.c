// 函数: CreateDIBitmap
// 地址: 0x407124
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return CreateDIBitmap(hdc, pbmih, flInit, pjBits, pbmi, iUsage) __tailcall
