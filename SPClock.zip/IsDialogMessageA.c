// 函数: IsDialogMessageA
// 地址: 0x4076e4
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return IsDialogMessageA(hDlg, lpMsg) __tailcall
