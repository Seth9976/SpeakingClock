// 函数: StartDocA
// 地址: 0x407374
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return StartDocA(hdc, lpdi) __tailcall
