// 函数: ImageList_GetIcon
// 地址: 0x426994
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return ImageList_GetIcon(himl, i, flags) __tailcall
