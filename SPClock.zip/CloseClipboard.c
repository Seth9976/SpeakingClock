// 函数: CloseClipboard
// 地址: 0x4073fc
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return CloseClipboard() __tailcall
