// 函数: LoadResource
// 地址: 0x40701c
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return LoadResource(hModule, hResInfo) __tailcall
