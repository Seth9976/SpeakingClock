// 函数: CreatePenIndirect
// 地址: 0x40714c
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return CreatePenIndirect(plpen) __tailcall
