// 函数: GetOpenFileNameA
// 地址: 0x43ff00
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return GetOpenFileNameA(param0) __tailcall
