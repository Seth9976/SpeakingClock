// 函数: ResetEvent
// 地址: 0x407054
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return ResetEvent(hEvent) __tailcall
