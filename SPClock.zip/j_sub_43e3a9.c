// 函数: j_sub_43e3a9
// 地址: 0x43e3b7
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return sub_43e3a9(arg1) __tailcall
