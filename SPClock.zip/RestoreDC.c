// 函数: RestoreDC
// 地址: 0x4072d4
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return RestoreDC(hdc, nSavedDC) __tailcall
