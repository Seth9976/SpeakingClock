// 函数: DefFrameProcA
// 地址: 0x40741c
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return DefFrameProcA(hWnd, hWndMDIClient, uMsg, wParam, lParam) __tailcall
