// 函数: GlobalAlloc
// 地址: 0x406fd4
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return GlobalAlloc(uFlags, dwBytes) __tailcall
