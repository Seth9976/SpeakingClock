// 函数: GetLastActivePopup
// 地址: 0x4075c4
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return GetLastActivePopup(hWnd) __tailcall
