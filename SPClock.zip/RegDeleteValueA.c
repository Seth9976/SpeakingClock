// 函数: RegDeleteValueA
// 地址: 0x406e04
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return RegDeleteValueA(hKey, lpValueName) __tailcall
