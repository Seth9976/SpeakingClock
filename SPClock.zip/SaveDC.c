// 函数: SaveDC
// 地址: 0x4072dc
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return SaveDC(hdc) __tailcall
