// 函数: sub_401718
// 地址: 0x401718
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

if (data_4ad049 == 0)
    return 

while (sub_401408(0, 1, &data_4af7a4) != 0)
    if (data_4ad5b1 == 0)
        Sleep(0)
        
        if (sub_401408(0, 1, &data_4af7a4) == 0)
            break
        
        Sleep(0xa)
