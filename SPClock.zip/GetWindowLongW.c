// 函数: GetWindowLongW
// 地址: 0x407684
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return GetWindowLongW(hWnd, nIndex) __tailcall
