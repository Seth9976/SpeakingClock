// 函数: sub_4024c8
// 地址: 0x4024c8
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

if (arg2 s< 0x3e8)
    int32_t var_14_1 = arg3
    char eax_3
    void* edx
    eax_3, edx = sub_40244c(arg1 - 0x4c, arg2)
    
    if (eax_3 != 0)
        int32_t var_14_2 = arg3
        char eax_7
        void* edx_1
        eax_7, edx_1 = sub_40244c(arg1 - 0x24, edx)
        
        if (eax_7 != 0)
            int32_t* esi_1 = *(arg1 - 0x24)
            
            if (arg1 == *(arg1 - 0x4c))
                int32_t* result
                
                if (esi_1 == 0)
                    result.b = 1
                    return result
                
                int32_t var_14_3 = arg3
                
                if (sub_40244c(esi_1, edx_1) != 0)
                    *esi_1
                    
                    if (sub_4024c8(arg3).b != 0)
                        result.b = 1
                        return result

return nullptr
