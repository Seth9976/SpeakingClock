// 函数: SetWindowLongA
// 地址: 0x4078bc
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return SetWindowLongA(hWnd, nIndex, dwNewLong) __tailcall
