// 函数: KillTimer
// 地址: 0x40772c
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return KillTimer(hWnd, uIDEvent) __tailcall
