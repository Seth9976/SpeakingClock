// 函数: GetTextMetricsA
// 地址: 0x407264
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return GetTextMetricsA(hdc, lptm) __tailcall
