// 函数: j_sub_40f8d8
// 地址: 0x40f8de
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return sub_40f8d8() __tailcall
