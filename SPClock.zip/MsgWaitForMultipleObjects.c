// 函数: MsgWaitForMultipleObjects
// 地址: 0x40777c
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return MsgWaitForMultipleObjects(nCount, pHandles, fWaitAll, dwMilliseconds, dwWakeMask) __tailcall
