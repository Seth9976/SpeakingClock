// 函数: sub_402ec4
// 地址: 0x402ec4
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

if (arg1 != 0 && data_4aa728() != 0)
    arg1.b = 2
    noreturn sub_402ff8(arg1) __tailcall
