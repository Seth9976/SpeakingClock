// 函数: sub_402434
// 地址: 0x402434
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

int64_t* eax
sub_4030d0(eax, arg2, arg1)
return arg2 + arg1
