// 函数: GetScrollRange
// 地址: 0x40762c
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return GetScrollRange(hWnd, nBar, lpMinPos, lpMaxPos) __tailcall
