// 函数: GetThreadLocale
// 地址: 0x406fa4
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return GetThreadLocale() __tailcall
