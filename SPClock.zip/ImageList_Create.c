// 函数: ImageList_Create
// 地址: 0x426934
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return ImageList_Create(cx, cy, flags, cInitial, cGrow) __tailcall
