// 函数: DestroyMenu
// 地址: 0x40744c
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return DestroyMenu(hMenu) __tailcall
