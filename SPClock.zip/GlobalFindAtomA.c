// 函数: GlobalFindAtomA
// 地址: 0x406fe4
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return GlobalFindAtomA(lpString) __tailcall
