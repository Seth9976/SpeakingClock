// 函数: PostMessageA
// 地址: 0x4077ac
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return PostMessageA(hWnd, Msg, wParam, lParam) __tailcall
