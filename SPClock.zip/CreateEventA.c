// 函数: CreateEventA
// 地址: 0x406e4c
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return CreateEventA(lpEventAttributes, bManualReset, bInitialState, lpName) __tailcall
