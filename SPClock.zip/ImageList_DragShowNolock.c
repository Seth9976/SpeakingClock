// 函数: ImageList_DragShowNolock
// 地址: 0x4269c4
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return ImageList_DragShowNolock(fShow) __tailcall
