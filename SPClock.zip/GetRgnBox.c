// 函数: GetRgnBox
// 地址: 0x40723c
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return GetRgnBox(hrgn, lprc) __tailcall
