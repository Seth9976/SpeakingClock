// 函数: ActivateKeyboardLayout
// 地址: 0x40739c
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return ActivateKeyboardLayout(hkl, Flags) __tailcall
