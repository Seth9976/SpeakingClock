// 函数: GetWindowDC
// 地址: 0x407674
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return GetWindowDC(hWnd) __tailcall
