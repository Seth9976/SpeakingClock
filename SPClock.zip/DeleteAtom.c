// 函数: DeleteAtom
// 地址: 0x406e94
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return DeleteAtom(nAtom) __tailcall
