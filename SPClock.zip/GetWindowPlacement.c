// 函数: GetWindowPlacement
// 地址: 0x40768c
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return GetWindowPlacement(hWnd, lpwndpl) __tailcall
