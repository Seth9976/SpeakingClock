// 函数: CoTaskMemAlloc
// 地址: 0x407c20
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return CoTaskMemAlloc(cb) __tailcall
