// 函数: PeekMessageW
// 地址: 0x4077a4
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return PeekMessageW(lpMsg, hWnd, wMsgFilterMin, wMsgFilterMax, wRemoveMsg) __tailcall
