// 函数: GetClipboardData
// 地址: 0x40753c
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return GetClipboardData(uFormat) __tailcall
