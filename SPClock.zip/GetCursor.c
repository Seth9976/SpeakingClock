// 函数: GetCursor
// 地址: 0x407544
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return GetCursor() __tailcall
