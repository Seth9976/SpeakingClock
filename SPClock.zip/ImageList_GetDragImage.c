// 函数: ImageList_GetDragImage
// 地址: 0x4269cc
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return ImageList_GetDragImage(ppt, pptHotspot) __tailcall
