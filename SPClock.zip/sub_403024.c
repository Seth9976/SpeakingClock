// 函数: sub_403024
// 地址: 0x403024
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

void* result = sub_406b68()
*(result + 4) = arg1
return result
