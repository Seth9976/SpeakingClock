// 函数: SetWinMetaFileBits
// 地址: 0x407364
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return SetWinMetaFileBits(nSize, lpMeta16Data, hdcRef, lpMFP) __tailcall
