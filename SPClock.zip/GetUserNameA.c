// 函数: GetUserNameA
// 地址: 0x406de4
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return GetUserNameA(lpBuffer, pcbBuffer) __tailcall
