// 函数: GetCurrentProcessId
// 地址: 0x406f24
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return GetCurrentProcessId() __tailcall
