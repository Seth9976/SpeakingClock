// 函数: _start
// 地址: 0x4a9980
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

sub_406bb4(sub_4a87cc)
void* ebx = data_4ac2fc
*ebx
sub_476b94()
*(*ebx + 0x5b) = 0
sub_47664c(*ebx, "Multilingual Speaking Clock")
sub_404b88(*ebx + 0x50)
int32_t esi
sub_476ce4(*sub_476bac(*sub_476bac(*ebx, 0x4a380c, data_4ac0ac, esi), 0x4a0ad0, data_4ac000, esi))
sub_4049e0()
noreturn
