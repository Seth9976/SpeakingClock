// 函数: CreateFontIndirectA
// 地址: 0x40712c
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return CreateFontIndirectA(lplf) __tailcall
