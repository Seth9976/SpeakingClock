// 函数: j_sub_405724
// 地址: 0x405cd0
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return sub_405724(arg1, arg2, arg3) __tailcall
