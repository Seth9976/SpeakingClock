// 函数: GetCapture
// 地址: 0x40751c
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return GetCapture() __tailcall
