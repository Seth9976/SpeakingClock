// 函数: GetClassLongA
// 地址: 0x40752c
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return GetClassLongA(hWnd, nIndex) __tailcall
