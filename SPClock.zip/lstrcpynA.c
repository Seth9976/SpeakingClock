// 函数: lstrcpynA
// 地址: 0x4012f4
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return lstrcpynA(lpString1, lpString2, iMaxLength) __tailcall
