// 函数: CreateRectRgnIndirect
// 地址: 0x40715c
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return CreateRectRgnIndirect(lprect) __tailcall
