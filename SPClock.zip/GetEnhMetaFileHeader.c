// 函数: GetEnhMetaFileHeader
// 地址: 0x407214
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return GetEnhMetaFileHeader(hemf, nSize, lpEnhMetaHeader) __tailcall
