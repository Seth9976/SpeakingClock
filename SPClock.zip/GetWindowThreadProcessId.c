// 函数: GetWindowThreadProcessId
// 地址: 0x4076ac
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return GetWindowThreadProcessId(hWnd, lpdwProcessId) __tailcall
