// 函数: DestroyWindow
// 地址: 0x407454
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return DestroyWindow(hWnd) __tailcall
