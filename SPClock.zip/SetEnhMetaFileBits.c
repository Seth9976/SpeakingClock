// 函数: SetEnhMetaFileBits
// 地址: 0x407324
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return SetEnhMetaFileBits(nSize, pb) __tailcall
