// 函数: ExtSelectClipRgn
// 地址: 0x4071b4
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return ExtSelectClipRgn(hdc, hrgn, mode) __tailcall
