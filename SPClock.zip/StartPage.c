// 函数: StartPage
// 地址: 0x40737c
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return StartPage(hdc) __tailcall
