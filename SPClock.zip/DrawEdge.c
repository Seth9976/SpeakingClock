// 函数: DrawEdge
// 地址: 0x40746c
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return DrawEdge(hdc, qrc, edge, grfFlags) __tailcall
