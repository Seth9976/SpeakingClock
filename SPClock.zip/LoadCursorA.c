// 函数: LoadCursorA
// 地址: 0x40773c
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return LoadCursorA(hInstance, lpCursorName) __tailcall
