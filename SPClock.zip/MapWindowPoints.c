// 函数: MapWindowPoints
// 地址: 0x407764
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return MapWindowPoints(hWndFrom, hWndTo, lpPoints, cPoints) __tailcall
