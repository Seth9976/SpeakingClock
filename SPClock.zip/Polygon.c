// 函数: Polygon
// 地址: 0x4072ac
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return Polygon(hdc, apt, cpt) __tailcall
