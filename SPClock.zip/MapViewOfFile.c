// 函数: MapViewOfFile
// 地址: 0x40702c
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return MapViewOfFile(hFileMappingObject, dwDesiredAccess, dwFileOffsetHigh, dwFileOffsetLow, 
    dwNumberOfBytesToMap) __tailcall
