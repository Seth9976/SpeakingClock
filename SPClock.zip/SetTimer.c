// 函数: SetTimer
// 地址: 0x4078b4
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return SetTimer(hWnd, nIDEvent, uElapse, lpTimerFunc) __tailcall
