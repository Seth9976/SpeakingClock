// 函数: SetScrollRange
// 地址: 0x4078ac
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return SetScrollRange(hWnd, nBar, nMinPos, nMaxPos, bRedraw) __tailcall
