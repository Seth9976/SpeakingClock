// 函数: SetAbortProc
// 地址: 0x4072fc
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return SetAbortProc(hdc, proc) __tailcall
