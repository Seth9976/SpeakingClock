// 函数: GetDC
// 地址: 0x407554
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return GetDC(hWnd) __tailcall
