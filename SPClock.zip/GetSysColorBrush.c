// 函数: GetSysColorBrush
// 地址: 0x407644
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return GetSysColorBrush(nIndex) __tailcall
