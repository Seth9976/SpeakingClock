// 函数: GetMessagePos
// 地址: 0x4075fc
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return GetMessagePos() __tailcall
