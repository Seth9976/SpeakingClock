// 函数: GetEnhMetaFilePaletteEntries
// 地址: 0x40721c
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return GetEnhMetaFilePaletteEntries(hemf, nNumEntries, lpPaletteEntries) __tailcall
