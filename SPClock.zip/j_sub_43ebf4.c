// 函数: j_sub_43ebf4
// 地址: 0x43ec02
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return sub_43ebf4(arg1) __tailcall
