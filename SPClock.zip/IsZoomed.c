// 函数: IsZoomed
// 地址: 0x407724
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return IsZoomed(hWnd) __tailcall
