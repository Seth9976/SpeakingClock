// 函数: j_sub_49d00d
// 地址: 0x49d01b
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return sub_49d00d(arg1) __tailcall
