// 函数: j_sub_425e50
// 地址: 0x425e5e
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return sub_425e50(arg1) __tailcall
