// 函数: GetWindowRect
// 地址: 0x407694
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return GetWindowRect(hWnd, lpRect) __tailcall
