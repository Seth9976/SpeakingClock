// 函数: PatBlt
// 地址: 0x40729c
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return PatBlt(hdc, x, y, w, h, rop) __tailcall
