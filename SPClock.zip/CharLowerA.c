// 函数: CharLowerA
// 地址: 0x4073ac
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return CharLowerA(lpsz) __tailcall
