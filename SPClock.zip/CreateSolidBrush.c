// 函数: CreateSolidBrush
// 地址: 0x40716c
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return CreateSolidBrush(color) __tailcall
