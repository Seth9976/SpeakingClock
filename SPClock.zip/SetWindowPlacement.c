// 函数: SetWindowPlacement
// 地址: 0x4078cc
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return SetWindowPlacement(hWnd, lpwndpl) __tailcall
