// 函数: SetRect
// 地址: 0x40788c
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return SetRect(lprc, xLeft, yTop, xRight, yBottom) __tailcall
