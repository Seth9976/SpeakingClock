// 函数: EnumWindows
// 地址: 0x4074e4
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return EnumWindows(lpEnumFunc, lParam) __tailcall
