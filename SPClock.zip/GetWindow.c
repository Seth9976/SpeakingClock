// 函数: GetWindow
// 地址: 0x40766c
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return GetWindow(hWnd, uCmd) __tailcall
