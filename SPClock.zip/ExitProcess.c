// 函数: ExitProcess
// 地址: 0x401274
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

noreturn ExitProcess(uExitCode) __tailcall
