// 函数: SafeArrayGetUBound
// 地址: 0x40f56c
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return SafeArrayGetUBound(psa, nDim, plUbound) __tailcall
