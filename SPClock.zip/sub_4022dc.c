// 函数: sub_4022dc
// 地址: 0x4022dc
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

*arg2 = &arg1[8]
void* edx = *arg1

if (arg1 == *(edx + 0x10) && *(edx + 8) u<= *(edx + 0xc))
    void* eax_2 = *(edx + 8) - 1
    *arg3 = eax_2
    return eax_2

uint32_t eax = zx.d(*(edx + 2))
*arg3 = (*(arg1 - 4) & 0xfffffff0) + arg1 - eax
return eax
