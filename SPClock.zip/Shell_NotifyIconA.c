// 函数: Shell_NotifyIconA
// 地址: 0x433d5c
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return Shell_NotifyIconA(dwMessage, lpData) __tailcall
