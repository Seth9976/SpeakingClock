// 函数: SafeArrayPtrOfIndex
// 地址: 0x40f574
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return SafeArrayPtrOfIndex(psa, rgIndices, ppvData) __tailcall
