// 函数: CreateCompatibleBitmap
// 地址: 0x407104
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return CreateCompatibleBitmap(hdc, cx, cy) __tailcall
