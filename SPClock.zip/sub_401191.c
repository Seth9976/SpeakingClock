// 函数: sub_401191
// 地址: 0x401191
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return sub_406638(&arg1[-2]) __tailcall
