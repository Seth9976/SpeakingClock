// 函数: OffsetRect
// 地址: 0x40778c
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return OffsetRect(lprc, dx, dy) __tailcall
