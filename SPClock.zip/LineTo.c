// 函数: LineTo
// 地址: 0x407284
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return LineTo(hdc, x, y) __tailcall
