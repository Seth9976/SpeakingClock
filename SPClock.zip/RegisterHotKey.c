// 函数: RegisterHotKey
// 地址: 0x4077dc
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return RegisterHotKey(hWnd, id, fsModifiers, vk) __tailcall
