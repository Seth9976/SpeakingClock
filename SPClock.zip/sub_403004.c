// 函数: sub_403004
// 地址: 0x403004
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

if (*(sub_406b68() + 4) != 0)
    noreturn sub_402ff8(0) __tailcall

return arg1
