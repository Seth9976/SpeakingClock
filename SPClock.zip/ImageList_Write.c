// 函数: ImageList_Write
// 地址: 0x4269dc
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return ImageList_Write(himl, pstm) __tailcall
