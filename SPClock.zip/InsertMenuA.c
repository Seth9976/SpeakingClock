// 函数: InsertMenuA
// 地址: 0x4076bc
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return InsertMenuA(hMenu, uPosition, uFlags, uIDNewItem, lpNewItem) __tailcall
