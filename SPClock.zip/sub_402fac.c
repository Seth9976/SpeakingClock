// 函数: sub_402fac
// 地址: 0x402fac
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

uint32_t ebx
ebx.b = arg1.b & 0x7f
int32_t ecx

if (data_4ad008 != 0)
    ecx = data_4ad008()

if (ebx.b == 0)
    void* eax_1
    eax_1, ecx = sub_406b68()
    *(eax_1 + 4)
else if (ebx.b u<= 0x18)
    *(zx.d(ebx.b) + 0x4aa73c)

sub_402fa0(ecx, arg2)
noreturn
