// 函数: SetWindowRgn
// 地址: 0x4078ec
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return SetWindowRgn(hWnd, hRgn, bRedraw) __tailcall
