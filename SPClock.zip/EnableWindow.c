// 函数: EnableWindow
// 地址: 0x4074c4
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return EnableWindow(hWnd, bEnable) __tailcall
