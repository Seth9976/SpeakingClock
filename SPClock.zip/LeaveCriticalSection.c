// 函数: LeaveCriticalSection
// 地址: 0x40700c
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return LeaveCriticalSection(lpCriticalSection) __tailcall
