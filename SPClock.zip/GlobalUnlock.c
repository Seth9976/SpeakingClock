// 函数: GlobalUnlock
// 地址: 0x406ffc
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return GlobalUnlock(hMem) __tailcall
