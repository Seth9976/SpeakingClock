// 函数: FreeLibrary
// 地址: 0x406ef4
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return FreeLibrary(hLibModule) __tailcall
