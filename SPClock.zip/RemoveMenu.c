// 函数: RemoveMenu
// 地址: 0x4077fc
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return RemoveMenu(hMenu, uPosition, uFlags) __tailcall
