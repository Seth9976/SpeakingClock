// 函数: GetDoubleClickTime
// 地址: 0x407574
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return GetDoubleClickTime() __tailcall
