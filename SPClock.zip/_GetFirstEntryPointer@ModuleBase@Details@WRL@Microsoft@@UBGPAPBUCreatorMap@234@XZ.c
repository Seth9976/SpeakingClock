// 函数: ?GetFirstEntryPointer@ModuleBase@Details@WRL@Microsoft@@UBGPAPBUCreatorMap@234@XZ
// 地址: 0x4242a0
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return 0x80030102
