// 函数: SelectPalette
// 地址: 0x4072f4
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return SelectPalette(hdc, hPal, bForceBkgd) __tailcall
