// 函数: sub_401410
// 地址: 0x401410
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

*arg2 = *arg1
int32_t result = arg1[2]
arg2[1] = arg1[1]
arg2[2] = result
return result
