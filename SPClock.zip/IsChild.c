// 函数: IsChild
// 地址: 0x4076dc
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return IsChild(hWndParent, hWnd) __tailcall
