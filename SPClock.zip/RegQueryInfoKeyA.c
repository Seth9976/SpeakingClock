// 函数: RegQueryInfoKeyA
// 地址: 0x406e24
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return RegQueryInfoKeyA(hKey, lpClass, lpcchClass, lpReserved, lpcSubKeys, lpcbMaxSubKeyLen, 
    lpcbMaxClassLen, lpcValues, lpcbMaxValueNameLen, lpcbMaxValueLen, lpcbSecurityDescriptor, 
    lpftLastWriteTime) __tailcall
