// 函数: ExcludeClipRect
// 地址: 0x4071ac
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return ExcludeClipRect(hdc, left, top, right, bottom) __tailcall
