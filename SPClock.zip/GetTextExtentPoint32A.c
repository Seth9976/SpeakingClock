// 函数: GetTextExtentPoint32A
// 地址: 0x407254
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return GetTextExtentPoint32A(hdc, lpString, c, psizl) __tailcall
