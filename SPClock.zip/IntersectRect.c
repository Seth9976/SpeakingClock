// 函数: IntersectRect
// 地址: 0x4076cc
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return IntersectRect(lprcDst, lprcSrc1, lprcSrc2) __tailcall
