// 函数: DrawTextExA
// 地址: 0x4074a4
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return DrawTextExA(hdc, lpchText, cchText, lprc, format, lpdtp) __tailcall
