// 函数: LoadLibraryA
// 地址: 0x407014
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return LoadLibraryA(lpLibFileName) __tailcall
