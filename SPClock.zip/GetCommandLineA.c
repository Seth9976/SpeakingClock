// 函数: GetCommandLineA
// 地址: 0x4012a4
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return GetCommandLineA() __tailcall
