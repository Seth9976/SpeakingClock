// 函数: RaiseException
// 地址: 0x401234
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

noreturn RaiseException(dwExceptionCode, dwExceptionFlags, nNumberOfArguments, lpArguments)
    __tailcall
