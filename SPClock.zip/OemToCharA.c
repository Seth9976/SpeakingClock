// 函数: OemToCharA
// 地址: 0x407784
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return OemToCharA(pSrc, pDst) __tailcall
