// 函数: GetDlgItem
// 地址: 0x40756c
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return GetDlgItem(hDlg, nIDDlgItem) __tailcall
