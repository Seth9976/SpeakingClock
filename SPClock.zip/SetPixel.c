// 函数: SetPixel
// 地址: 0x407334
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return SetPixel(hdc, x, y, color) __tailcall
