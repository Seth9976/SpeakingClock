// 函数: SetTextCharacterExtra
// 地址: 0x407354
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return SetTextCharacterExtra(hdc, extra) __tailcall
