// 函数: ShowScrollBar
// 地址: 0x4078fc
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return ShowScrollBar(hWnd, wBar, bShow) __tailcall
