// 函数: GetActiveWindow
// 地址: 0x40750c
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return GetActiveWindow() __tailcall
