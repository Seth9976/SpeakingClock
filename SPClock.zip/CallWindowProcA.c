// 函数: CallWindowProcA
// 地址: 0x4073c4
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return CallWindowProcA(lpPrevWndFunc, hWnd, Msg, wParam, lParam) __tailcall
