// 函数: SafeArrayCreate
// 地址: 0x40f55c
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return SafeArrayCreate(vt, cDims, rgsabound) __tailcall
