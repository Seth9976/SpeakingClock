// 函数: sub_402548
// 地址: 0x402548
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

void* const result = *arg1
int32_t var_14 = 0
int32_t __saved_ebp
int32_t* var_28 = &__saved_ebp
int32_t ecx

if (sub_4024c8(result, nullptr, ecx) != 0)
    return result

return nullptr
