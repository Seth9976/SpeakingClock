// 函数: EndPath
// 地址: 0x4071a4
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return EndPath(hdc) __tailcall
