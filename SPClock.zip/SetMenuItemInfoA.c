// 函数: SetMenuItemInfoA
// 地址: 0x407874
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return SetMenuItemInfoA(hmenu, item, fByPositon, lpmii) __tailcall
