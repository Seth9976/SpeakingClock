// 函数: GetTopWindow
// 地址: 0x40765c
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return GetTopWindow(hWnd) __tailcall
