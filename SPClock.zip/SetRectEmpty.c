// 函数: SetRectEmpty
// 地址: 0x407894
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return SetRectEmpty(lprc) __tailcall
