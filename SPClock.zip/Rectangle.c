// 函数: Rectangle
// 地址: 0x4072cc
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return Rectangle(hdc, left, top, right, bottom) __tailcall
