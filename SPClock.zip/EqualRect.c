// 函数: EqualRect
// 地址: 0x4074ec
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return EqualRect(lprc1, lprc2) __tailcall
