// 函数: CompareStringA
// 地址: 0x406e44
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return CompareStringA(Locale, dwCmpFlags, lpString1, cchCount1, lpString2, cchCount2) __tailcall
