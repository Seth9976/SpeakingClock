// 函数: DrawTextA
// 地址: 0x40749c
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return DrawTextA(hdc, lpchText, cchText, lprc, format) __tailcall
