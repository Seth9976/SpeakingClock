// 函数: GetAsyncKeyState
// 地址: 0x407514
// 来自: E:/torrent/Tools/Speaking Clock/spclock.exe.bndb

return GetAsyncKeyState(vKey) __tailcall
